# RAM Automation Backup — Sanitized Templates

A publication-review draft of selected automation source files from the local workspace. Prepared 30 October 2026. Original files were not modified. Nothing has been pushed to GitHub.

## Included

| Folder | Purpose |
| --- | --- |
| `database/` | Online and NOARCHIVELOG Oracle PDB-clone workflow templates |
| `reporting/` | Vulnerability workbook inspection, comparison, verification and rendering |
| `schema_tools/` | Schema-name extraction and workbook formatting utilities |
| `documentation/` | Python generators for technical runbooks and WebLogic references |

See `manifest.json` for the initial 21 prepared script files. An additional 67 source/configuration templates from `D:\codex` are under `from_d_codex/`, with their own manifest. These are sanitized copies, NOT working backups of your complete original environment. Keep original scripts securely outside GitHub.

## Placeholder convention

- IP addresses → `IP_ADDRESS`
- Private hostnames → `HOSTNAME`
- Private domain/URL → `hostname.invalid` / `https://hostname.invalid`
- Environment-specific paths → `/PATH_TO_CONFIGURE`
- Database identifiers → `DATABASE_NAME`
- Account/person identifiers → `USERNAME`
- Email addresses → `EMAIL_ADDRESS`
- Obvious literal credentials, if detected → `SECRET_REMOVED`

Some independent host/database values have intentionally been collapsed into the same placeholder. Configure distinct source and target values before use. Public technical product names, package imports, version examples and generic example domains are not credentials and may remain.

## Critical safety warning

**Do not run these templates as downloaded.** Copied shell scripts exit with status 99 immediately. They contain operations that can close/drop PDBs, delete datafiles, change source availability and perform month-end cleanup. Removing that guard is not approval to execute them. Review every command, configure real source/target locations securely, obtain approval, back up data and validate a rollback/recovery plan first.

Document generators may embed destructive SQL or shell instructions as text. Generating a document does not validate those instructions. Historical dates, counts, row selections, assertions, version examples and context-specific technical advice remain illustrative and must be independently reviewed; they are not generic operational defaults.

Python and JavaScript scripts are also configuration templates. They can read workbook data, write files and print potentially sensitive data to logs. Only test with synthetic inputs. Never publish their real outputs.

## Requirements

- Database templates: Linux Bash, Oracle SQL*Plus, configured Oracle environment; optional local `mail` command for notifications. SYSDBA actions require separate authorization.
- Python report tools: Python, `pandas` and an appropriate Excel reader such as `openpyxl` where used.
- Python Word generators: `python-docx`.
- JavaScript workbook scripts: Node.js plus `@oai/artifact-tool` in the originating runtime. This package/runtime is not bundled and availability outside that runtime is not guaranteed; these scripts are not advertised as standalone npm projects.
- Source spreadsheets, scan exports, images, certificates and other input data are not included.

## Deliberately excluded

Personal resume generators; resumes, payslips and certificates; customer websites/order data; private keys and certificates; passwords/schema-password mapping utilities; environment-specific SQL grant dumps; host-specific patch-status updates containing operational history; raw logs, source workbooks and generated documents; dependencies, temporary caches and Git history. Files outside the specified workspace were not collected.

## Before any GitHub upload

1. Review every file, including comments, dates, sample findings and output names. Automated substitution cannot guarantee that all confidential content has been identified.
2. Confirm your employer permits disclosure of the underlying logic. Removing IPs/passwords does not remove intellectual-property or confidentiality obligations.
3. Keep the repository private until that review is complete. Upload ONLY this folder, not its parent workspace.
4. Do not commit `.env`, database exports, logs, real spreadsheets or private keys. The `.gitignore` is defense in depth, not a secret scanner.
5. Rotate any credential previously exposed elsewhere; deleting text from a copy does not invalidate it.

## Verification performed

Original selected-file hashes were compared before and after copying. Python parsing and Node.js syntax checks were run on prepared sources. Pattern scans checked for known private hosts, local paths, IP/email formats and obvious credential patterns. No operational script was executed and no database/SSH/mail access was attempted. Bash syntax validation was not available in this Windows environment; run `bash -n` on the templates in Linux before any authorized adaptation. No claims of runtime correctness, complete redaction or production readiness are made.
