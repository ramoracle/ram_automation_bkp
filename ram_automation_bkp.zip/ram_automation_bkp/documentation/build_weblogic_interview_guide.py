# SANITIZED TEMPLATE: configure placeholders and review before use.
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.section import WD_SECTION
from docx.enum.text import WD_BREAK
from pathlib import Path

OUT = Path('outputs') / 'WebLogic_Apache_JDBC_Interview_Preparation_Guide.docx'
OUT.parent.mkdir(exist_ok=True)

doc = Document()
sec = doc.sections[0]
sec.top_margin = Inches(0.65)
sec.bottom_margin = Inches(0.65)
sec.left_margin = Inches(0.75)
sec.right_margin = Inches(0.75)

styles = doc.styles
styles['Normal'].font.name = 'Aptos'
styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), 'Aptos')
styles['Normal'].font.size = Pt(10.5)
styles['Normal'].paragraph_format.space_after = Pt(5)
styles['Normal'].paragraph_format.line_spacing = 1.1
for name, size in [('Title', 24), ('Heading 1', 16), ('Heading 2', 12)]:
    s = styles[name]
    s.font.name = 'Aptos Display' if name == 'Title' else 'Aptos'
    s._element.rPr.rFonts.set(qn('w:eastAsia'), s.font.name)
    s.font.size = Pt(size)
    s.font.color.rgb = RGBColor(0,0,0)
    s.font.bold = True
    s.paragraph_format.space_before = Pt(14 if name != 'Title' else 0)
    s.paragraph_format.space_after = Pt(6)

def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), fill)
    tcPr.append(shd)

def border_table(table):
    tblPr = table._tbl.tblPr
    borders = OxmlElement('w:tblBorders')
    for edge in ('top','left','bottom','right','insideH','insideV'):
        el = OxmlElement(f'w:{edge}')
        el.set(qn('w:val'),'single'); el.set(qn('w:sz'),'4'); el.set(qn('w:color'),'D9D9D9')
        borders.append(el)
    tblPr.append(borders)

def set_cell_text(cell, text, bold=False, color=None):
    cell.text = ''
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(1)
    r = p.add_run(text)
    r.bold = bold
    r.font.size = Pt(9.3)
    if color: r.font.color.rgb = RGBColor(*color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER

def table(headers, rows, widths=None):
    t = doc.add_table(rows=1, cols=len(headers))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    border_table(t)
    for i,h in enumerate(headers):
        c=t.rows[0].cells[i]; shade(c,'163A5F'); set_cell_text(c,h,True,(255,255,255))
        if widths: c.width=Inches(widths[i])
    for n,row in enumerate(rows):
        cells=t.add_row().cells
        for i,v in enumerate(row):
            if n%2==1: shade(cells[i],'F3F7FA')
            set_cell_text(cells[i],v)
            if widths: cells[i].width=Inches(widths[i])
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t

def heading(text, level=1): doc.add_heading(text, level=level)
def para(text, boldlead=None):
    p=doc.add_paragraph()
    if boldlead:
        r=p.add_run(boldlead); r.bold=True
    p.add_run(text)
    return p
def bullets(items):
    for item in items:
        p=doc.add_paragraph(style='List Bullet'); p.paragraph_format.space_after=Pt(2); p.add_run(item)
def code(lines):
    p=doc.add_paragraph()
    p.paragraph_format.left_indent=Inches(.2); p.paragraph_format.space_after=Pt(6)
    r=p.add_run(lines); r.font.name='Consolas'; r._element.rPr.rFonts.set(qn('w:eastAsia'),'Consolas'); r.font.size=Pt(8.6)

p=doc.add_paragraph(style='Title'); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.add_run('WebLogic Apache and JDBC Interview Preparation Guide')
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; r=p.add_run('Practical questions, troubleshooting checks, and production safe answers'); r.italic=True; r.font.size=Pt(11)
doc.add_paragraph('This guide is for preparing WebLogic middleware interviews. It covers the topics most often discussed in operations roles: Apache integration, WebLogic plugins, JDBC data sources, deployments, clustering, patches, logs, heap and thread dumps, and service recovery. Always explain the diagnostic approach first, make changes under approved change control, and protect credentials and private keys.')

heading('1 Apache HTTP Server Integration with WebLogic')
para('Apache HTTP Server normally acts as a reverse proxy in front of WebLogic. Clients connect to Apache over HTTP or HTTPS. Apache forwards selected URLs to a WebLogic managed server or cluster through the WebLogic proxy plugin. This separates internet facing TLS and routing from application server processing.')
table(['Component','Purpose','Typical location or setting'],[
('Apache HTTP Server','Receives client requests; terminates HTTPS or forwards it.','Apache httpd.conf and virtual host configuration'),
('WebLogic Proxy Plugin','Routes requests from Apache to WebLogic cluster members.','mod_wl_ohs or mod_wl plugin module'),
('WebLogic cluster','Provides application availability and load balancing.','WebLogic Administration Console'),
('WebLogic managed server','Runs applications.','Domain servers directory and Admin Console'),
], [1.45,2.35,2.8])
heading('Plugin configuration',2)
bullets([
'For Oracle HTTP Server, the WebLogic plugin module is commonly managed with the Oracle HTTP Server installation. For Apache HTTP Server, use the WebLogic Server proxy plugin that matches the WebLogic version and platform.',
'Typical plugin directives are WebLogicHost and WebLogicPort for one server, or WebLogicCluster for multiple members. Use a WebLogicCluster value for production high availability.',
'For SSL, set SecureProxy ON when Apache communicates to a WebLogic SSL port. Confirm certificates, trusted CAs, hostname resolution, and firewall rules.',
'Validate with Apache error/access logs and WebLogic server logs. A 503 can mean all backend members are unavailable.'
])
code('Example onl/PATH_TO_CONFIGURE')

heading('2 WebLogic Installation Types')
table(['Type','When used','Key point'],[
('WebLogic Server standalone','Core WebLogic applications and domains.','Contains wlserver, OPatch, Oracle common components.'),
('Fusion Middleware Infrastructure','WebLogic plus common Oracle infrastructure components.','Common for Oracle banking and enterprise middleware.'),
('Developer installation','Local development and testing.','Not appropriate as a production standard.'),
('Production installation','Controlled servers with domains, Node Manager and patching.','Use approved JDK, backups and change management.'),
], [1.65,2.5,2.45])

heading('3 WebLogic Clustering Concept')
para('A WebLogic cluster is a group of managed servers that work together to provide scalability and high availability. Applications can be targeted to the cluster. The proxy plugin, load balancer, or WebLogic client distributes traffic between members.')
bullets(['Cluster members should use compatible WebLogic, JDK, patch, application and configuration levels.', 'Use session replication or an external session store when applications require session continuity.', 'A cluster is not a replacement for database high availability. The application data source still needs a resilient database service or RAC configuration.', 'Verify cluster health using Admin Console, server state, listen ports, logs and application health checks.'])

heading('4 JDBC Data Sources')
heading('JDBC data source types',2)
table(['Type','Use','Notes'],[
('Generic data source','One database connection pool.','Can use non XA or XA driver.'),
('GridLink data source','Oracle RAC aware pool.','Uses ONS/FAN for RAC failover where configured.'),
('Multi data source','Groups member data sources.','Supports failover or load balancing strategy.'),
('Active GridLink','Modern RAC aware Oracle data source.','Preferred when RAC and ONS are available.'),
], [1.5,2.3,2.8])
heading('JDBC URL examples',2)
code('Non-XA Oracle thin UR/PATH_TO_CONFIGURE')
para('Database details are commonly written as user/password@host:1521/service_name. In real environments, do not put passwords in shell history, tickets, scripts, screenshots, or interview examples. A PDB service is normally supplied as the service name after the slash.')
heading('Increasing the connection pool',2)
bullets(['In Admin Console: Services > Data Sources > select data source > Configuration > Connection Pool.', 'Review Current Capacity, Maximum Capacity, Minimum Capacity, connection reserve timeout, and test frequency.', 'Increase Maximum Capacity only after checking database session limits, application concurrency, slow SQL, and connection leaks.', 'Activate changes. A restart may be required depending on configuration and target scope; follow the approved change procedure.'])
heading('If a data source does not connect',2)
table(['Check','Possible issue','Action'],[
('Network','DB host, port 1521, firewall or DNS unavailable.','Test name resolution and TCP reachability from the managed server host.'),
('URL/service','Wrong host, listener port, PDB service name or SCAN.','Compare with approved DB connect descriptor.'),
('Credentials','Expired, locked or wrong database account.','Ask DBA to validate securely; do not expose the password.'),
('Driver/XA','Wrong driver, unsupported JDK, XA configuration mismatch.','Verify driver class and data source type.'),
('Capacity','Pool exhausted or database session limit reached.','Review datasource runtime counters and DB sessions.'),
('TLS/wallet','Trust chain or wallet configuration error.','Review PKIX/SSL errors and certificate expiry.'),
], [1.2,2.6,2.8])

heading('5 Deployments and Deployment Order')
para('Deployment order controls the order in which targeted applications start. Lower deployment order values start earlier; higher values start later. Use it when one application depends on another service, shared library, adapter, or startup component.')
bullets(['In the console: Deployments > select deployment > Configuration > Deployment Order.', 'Do not rely only on deployment order for database or remote service readiness; use application health checks and retry logic.', 'Before deploying, validate the archive, target, deployment plan, JDK compatibility, required libraries, datasource/JNDI names, and disk space.'])
heading('If deployment fails',2)
bullets(['Check the target server log first, then the AdminServer log. Search for DeploymentException, ModuleException, Caused by, ClassNotFoundException, JNDI, and datasource errors.', 'Confirm the application is targeted to the correct managed server or cluster.', 'Confirm deployment plan paths, file ownership, shared libraries, Java version, and available disk space.', 'Do not repeatedly redeploy without reading the first real exception. Remove a failed deployment only through the approved procedure.'])

heading('6 Logs That Matter')
table(['Log','Why it matters','Usual path pattern'],[
('AdminServer log','Domain configuration, deployment and server startup.','DOMAIN/servers/AdminServer/logs/AdminServer.log'),
('Managed server log','Application, datasource, deployment and runtime errors.','DOMAIN/servers/server_name/logs/server_name.log'),
('Node Manager log','Remote start and stop, Java home, SSL and machine issues.','DOMAIN/nodemanager/nodemanager.log'),
('Apache access/error logs','Client requests and proxy-plugin backend errors.','Apache logs/access_log and error_log'),
('JVM stdout','JVM arguments and application standard output.','DOMAIN/servers/server_name/logs/*.out'),
('OPatch logs','Patch application detail and failures.','ORACLE_HOME/cfgtoollogs/opatch'),
], [1.45,2.55,2.55])

heading('7 Server Startup Failure')
para('State the current status clearly: RUNNING, ADMIN, FAILED, or not confirmed. Then identify the first meaningful error in the actual server .log file rather than treating the last line as the root cause.')
table(['Possible cause','Typical evidence','First response'],[
('Wrong JAVA HOME','JDK not found, unsupported class version.','Verify startup scripts and the domain configured JDK.'),
('Port conflict','Address already in use.','Identify listening process; do not kill without approval.'),
('Keystore issue','Invalid keystore format, missing file, SSL handshake error.','Verify path, type JKS/PKCS12, permissions and trust chain.'),
('Boot identity issue','Authentication failure.','Check presence/permissions; do not display password.'),
('Datasource/app failure','Server reaches ADMIN but not RUNNING.','Read preceding deployment/datasource exception.'),
('Disk/full filesystem','Cannot write log, temp, stage or transaction file.','Check filesystem capacity and inode usage.'),
], [1.55,2.55,2.45])

heading('8 Heap Dump and Thread Dump')
heading('Thread dump',2)
para('A thread dump is a point in time view of JVM threads. Take three dumps approximately 30 to 60 seconds apart during the problem. This shows whether the same threads remain blocked or consume CPU.')
code('Example on Linux using the JDK for the proces/PATH_TO_CONFIGURE')
heading('Thread dump analysis',2)
bullets(['Find RUNNABLE threads with high CPU and look for the same stack across all dumps.', 'Review BLOCKED threads and the lock owner. Look for deadlock detection output.', 'Look for WAITING or TIMED_WAITING pools where all worker threads are waiting on database, HTTP, JMS, or a common lock.', 'Check WebLogic execute threads, JDBC connection waiters, stuck threads, and external call stacks.', 'Correlate timestamps with server logs, database waits, CPU, memory, GC and network metrics.'])
heading('Heap dump',2)
para('A heap dump captures objects in the JVM heap and is used for memory leak or OutOfMemoryError investigation. Heap dumps can be large and can contain sensitive application data. Take them only during an approved incident and store them securely.')
code('Example with an approved JDK too/PATH_TO_CONFIGURE')
bullets(['Analyze with Eclipse MAT, Java Mission Control, or another approved analyzer.', 'Look for largest retained objects, duplicate caches, session growth, classloader leaks, unclosed result sets, and unexpectedly retained request objects.', 'Compare heap usage and full GC behavior before and after the incident.'])

heading('9 Application Slowness Checklist')
table(['Layer','What to check'],[
('Client and Apache','Response time, HTTP status, access/error logs, proxy backend availability.'),
('WebLogic','Execute thread utilization, stuck threads, heap/GC, datasource waiters, JMS queues, server logs.'),
('JDBC and DB','Connection pool availability, slow SQL, blocking locks, sessions, CPU, storage waits, DB alert log.'),
('Host OS','CPU, memory, swap, disk capacity and latency, network errors, file descriptors.'),
('External dependencies','REST/SOAP endpoints, DNS, certificate expiry, load balancer and firewall timeouts.'),
], [1.55,5.0])
para('Interview answer: start with the user impact and time range, identify the slow transaction or URL, then trace it across Apache, WebLogic, JDBC/database, and OS metrics. Do not tune heap or connection pools blindly before identifying the bottleneck.')

heading('10 HTTP Error Codes')
table(['Code','Meaning','Common WebLogic or Apache interpretation'],[
('404 Not Found','Requested resource does not exist at that path.','Wrong context root, URL, virtual host, rewrite or application not deployed.'),
('500 Internal Server Error','Server side application error.','Unhandled application exception, configuration failure, backend error.'),
('503 Service Unavailable','Service temporarily cannot process request.','All cluster backends unavailable, server overloaded, maintenance mode, proxy cannot connect.'),
], [1.45,1.8,3.3])

heading('11 OPatch Patching Basics')
para('Use OPatch only in an approved maintenance window. Confirm the correct Oracle Home, JDK, patch directory, release, readme instructions, backup/rollback plan and service outage scope. Stop relevant WebLogic, Node Manager, Coherence and OHS processes before patching when the patch readme requires it.')
code('Read-only check/PATH_TO_CONFIGURE')
bullets(['Read the patch readme before every patch. It may require a particular OPatch version, a specific patch sequence, post patch scripts, or component specific steps.', 'After applying, run lspatches, restart services according to the approved plan, review logs, validate application health, and retain rollback evidence.', 'A superseding patch can mark an older patch inactive; verify the intended latest patch ID rather than assuming older IDs remain active.'])

heading('12 Quick Interview Answer Framework')
table(['Question','Strong answer pattern'],[
('A server will not start','Check process, port, real server log, Java Home, keystore, boot identity, deployment/datasource exception, disk; report exact first error.'),
('Application is slow','Trace one transaction across Apache, WebLogic threads/GC, JDBC pool and database waits before changing capacity.'),
('Datasource fails','Check network, URL/service, account state, driver/XA type, capacity and TLS/wallet; test connection safely.'),
('Patch is required','Confirm home/JDK/readme, stop required services, take backup, conflict prereq, apply, verify lspatches and restart/validate.'),
('SSL fails','Check certificate expiry, SAN hostname, complete server/intermediate/root chain, keystore type/path, and truststore on the caller.'),
], [2.0,4.55])

heading('13 Useful Safe Commands')
code('Process statu/PATH_TO_CONFIGURE"weblogic.Server|NodeManager|httpd|ohs" | grep -v grep\n\nPort/PATH_TO_CONFIGURE"7001|7002|9001|9002|5556|5558"\n\nRecent WebLogic states and error/PATH_TO_CONFIGURE"Server state changed|RUNNING|ADMIN|FAILED|DeploymentException|ModuleException|Caused by|Exception" \\\n  "$DOMAIN"/servers/*/logs/*.log | tail -120\n\nDatasource connectivity diagnosi/PATH_TO_CONFIGURE')

heading('Interview Reminders')
bullets(['Never say you would expose a password, private key, or production certificate in a ticket or command history.', 'Mention change approval, backup, rollback, and service validation for configuration changes, patches, restarts, and keystore updates.', 'Use evidence: exact log file, timestamp, error, process state and port. Avoid guessing root cause from only a console screen.', 'For clustered environments, validate every managed server, proxy routing, session behavior, data source, and backend dependency.'])

# Footer page number
for section in doc.sections:
    footer=section.footer.paragraphs[0]
    footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run('WebLogic Interview Preparation Guide | ')
    fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE'); footer._p.append(fld)

doc.core_properties.title='WebLogic Apache and JDBC Interview Preparation Guide'
doc.core_properties.author='USERNAME'
doc.save(OUT)
print(OUT.resolve())
