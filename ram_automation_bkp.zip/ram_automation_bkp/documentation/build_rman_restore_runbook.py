# SANITIZED TEMPLATE: configure placeholders and review before use.
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

OUT = "DATABASE_NAME_RMAN_Restore_Runbook.docx"

def font(run, name="Calibri", size=11, bold=None, color=None):
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:ascii"), name)
    run._element.rPr.rFonts.set(qn("w:hAnsi"), name)
    run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)

def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tcPr.append(shd)

def set_cell_text(cell, label, value=None):
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    r = p.add_run(label)
    font(r, bold=True)
    if value:
        r = p.add_run(value)
        font(r)

def code(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(.18)
    p.paragraph_format.right_indent = Inches(.12)
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after = Pt(7)
    p.paragraph_format.line_spacing = 1.0
    pPr = p._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), "F2F4F7")
    pPr.append(shd)
    r = p.add_run(text)
    font(r, name="Consolas", size=9)
    return p

def heading(doc, text, level=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(18 if level == 1 else 12)
    p.paragraph_format.space_after = Pt(7 if level == 1 else 5)
    r = p.add_run(text)
    font(r, size=16 if level == 1 else 13, bold=True,
         color=(46,116,181) if level == 1 else (31,77,120))
    return p

def para(doc, text, bold_lead=None):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = 1.25
    if bold_lead and text.startswith(bold_lead):
        r = p.add_run(bold_lead)
        font(r, bold=True)
        r = p.add_run(text[len(bold_lead):])
        font(r)
    else:
        r = p.add_run(text)
        font(r)
    return p

doc = Document()
section = doc.sections[0]
section.top_margin = Inches(1)
section.bottom_margin = Inches(1)
section.left_margin = Inches(1)
section.right_margin = Inches(1)
section.header_distance = Inches(.492)
section.footer_distance = Inches(.492)

styles = doc.styles
styles['Normal'].font.name = 'Calibri'
styles['Normal']._element.rPr.rFonts.set(qn('w:ascii'), 'Calibri')
styles['Normal']._element.rPr.rFonts.set(qn('w:hAnsi'), 'Calibri')
styles['Normal'].font.size = Pt(11)

title = doc.add_paragraph()
title.paragraph_format.space_after = Pt(4)
r = title.add_run('RMAN Restore Runbook')
font(r, size=24, bold=True, color=(11,37,69))
sub = doc.add_paragraph()
sub.paragraph_format.space_after = Pt(14)
r = sub.add_run('DATABASE_NAME backup to DATABASE_NAME / DATABASE_NAME target')
font(r, size=12, color=(85,85,85))

table = doc.add_table(rows=5, cols=2)
table.style = 'Table Grid'
data = [
    ('Target host', 'HOSTNAME'),
    ('Target Oracle Home', '/PATH_TO_CONFIGURE'),
    ('Target ORACLE_SID', 'DATABASE_NAME'),
    ('Target data location', '/PATH_TO_CONFIGURE'),
    ('Backup location', '/PATH_TO_CONFIGURE'),
]
for row, (a,b) in zip(table.rows, data):
    set_cell_text(row.cells[0], a)
    shade(row.cells[0], 'E8EEF5')
    set_cell_text(row.cells[1], b)

heading(doc, 'Current status')
para(doc, 'The 09-Jun-2026 source backup is confirmed as a consistent/cold backup. Archive logs are not required because the RMAN duplicate uses NOREDO.')
para(doc, 'The first duplicate attempt restored the controlfiles, then stopped. The DB_FILES issue was corrected by setting db_files=1000. The current blocking error is RMAN-05001: RMAN is attempting to use source datafile paths under /PATH_TO_CONFIGURE')

heading(doc, 'Important safety note')
para(doc, 'Do not use NOFILENAMECHECK. It could allow RMAN to write to the old source paths. Do not delete the restored control01.ctl or control02.ctl. The next attempt must use Oracle Managed Files under the target location.')

heading(doc, 'Step 1 - Add Oracle Managed File destinations to the restore PFILE')
para(doc, 'Run these commands at the Linux prompt as USERNAME.')
code(doc, "export ORACLE_HOME=/PATH_TO_CONFIGURE\nexport ORACLE_SID=DATABASE_NAME\nunset TWO_TASK\nPFILE=/PATH_TO_CONFIGURE\nprintf \"\\n*.db_create_file_dest='/PATH_TO_CONFIGURE'\\n*.db_create_online_log_dest_1='/PATH_TO_CONFIGURE'\\n\" >> \"$PFILE\"\ngrep -inE 'db_create_file_dest|db_create_online_log_dest|db_files|db_name' \"$PFILE\"")
para(doc, 'Expected PFILE entries:', bold_lead='Expected PFILE entries:')
code(doc, "db_name='DATABASE_NAME'\n*.db_files=1000\n*.db_create_file_dest='/PATH_TO_CONFIGURE'\n*.db_create_online_log_dest_1='/PATH_TO_CONFIGURE'")

heading(doc, 'Step 2 - Restart auxiliary database in NOMOUNT')
code(doc, '"$ORACLE_HOME/bin/sqlplus" / as sysdba')
para(doc, 'At the SQL> prompt, run:')
code(doc, "SHUTDOWN ABORT;\nSTARTUP NOMOUNT PFILE='/PATH_TO_CONFIGURE';\nSHOW PARAMETER db_create_file_dest\nSHOW PARAMETER db_create_online_log_dest\nSHOW PARAMETER db_files\nEXIT;")
para(doc, 'Proceed only when db_create_file_dest shows /PATH_TO_CONFIGURE and db_files shows 1000.', bold_lead='Proceed only when ')

heading(doc, 'Step 3 - Run the RMAN duplicate')
code(doc, '"$ORACLE_HOME/bin/rman" auxiliary /')
para(doc, 'At the RMAN> prompt, run exactly:')
code(doc, "DUPLICATE DATABASE TO DATABASE_NAME\n  BACKUP LOCATION '/PATH_TO_CONFIGURE'\n  NOREDO;")
para(doc, 'Do not interrupt this command. It may take a long time because it restores the complete CDB and all PDB datafiles.')

heading(doc, 'Step 4 - Validate after RMAN reports success')
code(doc, '"$ORACLE_HOME/bin/sqlplus" / as sysdba')
code(doc, "SELECT name, open_mode FROM v$database;\nSHOW PDBS;\nSELECT con_id, name, open_mode FROM v$pdbs ORDER BY con_id;\nEXIT;")

heading(doc, 'If RMAN fails again')
para(doc, 'Do not rerun with NOFILENAMECHECK and do not manually run RECOVER DATABASE. Copy the full RMAN error output for review.')

footer = section.footer.paragraphs[0]
footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
r = footer.add_run('RMAN Restore Runbook | 28-Aug-2026')
font(r, size=8, color=(85,85,85))

doc.save(OUT)
print(OUT)
