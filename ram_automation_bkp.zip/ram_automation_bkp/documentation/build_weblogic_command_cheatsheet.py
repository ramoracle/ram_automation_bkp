# SANITIZED TEMPLATE: configure placeholders and review before use.
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from pathlib import Path

out=Path('outputs')/'WebLogic_Interview_Command_Cheat_Sheet.docx'
doc=Document(); s=doc.sections[0]
s.top_margin=Inches(.6);s.bottom_margin=Inches(.6);s.left_margin=Inches(.62);s.right_margin=Inches(.62)
st=doc.styles; st['Normal'].font.name='Aptos'; st['Normal'].font.size=Pt(10);st['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'),'Aptos');st['Normal'].paragraph_format.space_after=Pt(4)
for n,z in [('Title',22),('Heading 1',15),('Heading 2',11)]:
    x=st[n];x.font.name='Aptos';x.font.size=Pt(z);x.font.bold=True;x.font.color.rgb=RGBColor(0,0,0);x.paragraph_format.space_before=Pt(12);x.paragraph_format.space_after=Pt(5)
def shade(c,v):
    q=c._tc.get_or_add_tcPr();x=OxmlElement('w:shd');x.set(qn('w:fill'),v);q.append(x)
def put(c,t,b=False,w=False,mono=False):
    c.text='';p=c.paragraphs[0];p.paragraph_format.space_after=Pt(1);r=p.add_run(t);r.bold=b;r.font.size=Pt(8.7 if mono else 9.1)
    if mono:r.font.name='Consolas';r._element.rPr.rFonts.set(qn('w:eastAsia'),'Consolas')
    if w:r.font.color.rgb=RGBColor(255,255,255)
    c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
def tbl(rows):
    t=doc.add_table(rows=1,cols=3);t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
    for i,h in enumerate(['Say in interview','Run this command','Understand the result']): shade(t.rows[0].cells[i],'163A5F');put(t.rows[0].cells[i],h,True,True)
    for n,(a,b,c) in enumerate(rows):
        cells=t.add_row().cells
        if n%2:
            for x in cells:shade(x,'F3F7FA')
        put(cells[0],a);put(cells[1],b,mono=True);put(cells[2],c)
    doc.add_paragraph()
def h(t):doc.add_heading(t,1)

p=doc.add_paragraph(style='Title');p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.add_run('WebLogic Interview Command Cheat Sheet')
p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.add_run('Say it, run it, understand it')
doc.add_paragraph('Use the first column as your spoken interview answer. Use commands only after replacing the exact domain, server, user and path. Production changes, restarts, patches, keystore updates and database changes need approval and a rollback plan. Never show passwords or private keys.')

h('1 First Health Check')
tbl([
('I first check process, port and logs before changing anything.','hostname -f\nwhoami\nps -ef | egrep "weblogic.Server|NodeManager|httpd|ohs" | grep -v grep','Shows host, login user, and whether WebLogic, Node Manager or Apache/OHS are running.'),
('I check WebLogic ports.','netstat -tulnp 2>/dev/null | egrep "7001|7002|9001|9002|5556|5558"','A listening port normally means a process is accepting connections. No port can mean server is down or port is disabled.'),
('I check server state in the real log.','DOMAIN=/absolute/domain/path\ngrep -iE "Server state changed|RUNNING|ADMIN|FAILED" "$DOMAIN"/servers/*/logs/*.log | tail -80','RUNNING means server started. ADMIN can mean applications did not start correctly. FAILED means inspect earlier error.'),
])
h('2 Apache Integration and Errors')
tbl([
('Apache is the front door; it sends client requests to WebLogic using the WebLogic proxy plugin.','grep -RIn "WebLogicHost|WebLogicPort|WebLogicCluster" /path/to/apache/conf 2>/dev/null','Shows backend WebLogic host, port, or cluster used by Apache.'),
('For a cluster, I configure WebLogicCluster, not only one backend server.','grep -RIn "WebLogicCluster" /path/to/apache/conf 2>/dev/null','Lists the managed-server host:port values Apache can use.'),
('For 503, I check Apache error log and backend WebLogic ports.','tail -100 /path/to/apache/logs/error_log\nnetstat -tulnp 2>/dev/null | egrep "7001|7002"','503 normally means Apache cannot use any WebLogic backend.'),
('404 means path not found; 500 means application error; 503 means service unavailable.','tail -100 /path/to/apache/logs/access_log\ntail -100 /path/to/apache/logs/error_log','Use access log for status/URL, error log for proxy or SSL reason.'),
])
h('3 JDBC Data Source')
tbl([
('A data source is WebLogic database connection pool configuration.','grep -iE "JDBC|SQLException|ORA-[0-9]+|Connection" "$DOMAIN"/servers/*/logs/*.log | tail -100','Shows datasource, Oracle, or connection errors in server logs.'),
('Normal Oracle JDBC URL uses host, port 1521 and service name.','Example: jdbc:oracle:thin:@//dbhost.example.com:1521/service_name','Use a PDB service name after the slash. Do not put user password in commands or tickets.'),
('XA uses an XA data source/driver; the Oracle thin URL format is usually the same.','Example: jdbc:oracle:thin:@//dbhost.example.com:1521/service_name','XA is chosen in WebLogic data source settings, not by adding XA to the URL text.'),
('If datasource fails, I check network, URL, user status, listener, pool and DB sessions.','nc -vz dbhost.example.com 1521\n# if nc is unavailable\ntelnet dbhost.example.com 1521','Success means TCP port reachable. Failure may be DNS, firewall, listener or route.'),
('Before increasing pool capacity, I check whether the pool is exhausted or SQL is slow.','grep -iE "wait.*connection|pool|reserve|stuck|SQLException" "$DOMAIN"/servers/*/logs/*.log | tail -100','If all connections are busy, investigate slow SQL, leaks and DB session limit before increasing Maximum Capacity.'),
])
h('4 Deployment')
tbl([
('Deployment order decides startup order. Low number starts first.','grep -n "deployment-order" "$DOMAIN"/config/config.xml 2>/dev/null','Shows deployment-order entries if defined in domain config.'),
('If deployment fails, I read the first exception in managed server and AdminServer logs.','grep -iE "DeploymentException|ModuleException|ClassNotFoundException|Caused by|JNDI" "$DOMAIN"/servers/*/logs/*.log | tail -150','The earliest relevant exception usually gives the real cause: missing library, JNDI, datasource or class issue.'),
('I validate archive, target, plan, JNDI, data source and JDK before redeploying.','ls -lh /path/to/application.war\ngrep -iE "RUNNING|FAILED|Deployment" "$DOMAIN"/servers/*/logs/*.log | tail -100','Confirms artifact exists and shows target deployment result.'),
])
h('5 Server Not Starting')
tbl([
('For startup, I verify JAVA_HOME, port, keystore, boot identity, disk and first error.','grep -RIn "JAVA_HOME" "$DOMAIN"/bin 2>/dev/null\ndf -h\ndf -i','Wrong Java path or full filesystem can stop startup. Never print credentials.'),
('I check the server log before restarting again.','tail -200 "$DOMAIN"/servers/AdminServer/logs/AdminServer.log\ngrep -iE "FAILED|Exception|Caused by|keystore|Address already in use" "$DOMAIN"/servers/AdminServer/logs/AdminServer.log | tail -100','Read lines just before failure. Typical issues: port conflict, keystore, Java or deployment failure.'),
('I start Node Manager from the domain bin directory when approved.','cd "$DOMAIN/bin"\n./startNodeManager.sh','Success normally shows Node Manager listener started. Read nodemanager.log on failure.'),
('I start AdminServer from domain bin directory when approved.','cd "$DOMAIN/bin"\n./startWebLogic.sh','Success: Server state changed to RUNNING. If it stops at ADMIN, inspect the server log.'),
])
h('6 Thread Dump and Heap Dump')
tbl([
('Thread dump tells what Java threads are doing right now. I take three during issue.','$JAVA_HOME/bin/jstack -l <pid> > /tmp/thread1.txt\n# repeat after 30-60 seconds: thread2.txt, thread3.txt','Compare all dumps. Same blocked/runnable stack in all files indicates continuing issue.'),
('For thread dump, I check high CPU, BLOCKED, deadlock, stuck threads and JDBC waits.','grep -nE "BLOCKED|RUNNABLE|deadlock|weblogic.work|jdbc|socketRead" /tmp/thread*.txt | head -200','BLOCKED can show lock wait. JDBC/socket stack can show database or external call wait.'),
('Heap dump is for memory leak or OutOfMemoryError. Take only with approval.','$JAVA_HOME/bin/jcmd <pid> GC.heap_dump /secure/path/server.hprof','Creates memory snapshot. Analyze securely with Eclipse MAT or approved tool; heap may contain sensitive data.'),
])
h('7 Application Slow')
tbl([
('For slow application, I trace one request: Apache -> WebLogic -> JDBC -> database -> OS.','top -b -n 1 | head -30\nfree -m\ndf -h','Checks CPU, memory and filesystem at issue time.'),
('I check WebLogic stuck execute threads and errors.','grep -iE "stuck|hogging|BEA-[0-9]+|SQLException|timeout" "$DOMAIN"/servers/*/logs/*.log | tail -150','Stuck thread, timeout or database error can explain slow response.'),
('I correlate the exact timestamp across Apache, WebLogic and database.','tail -100 /path/to/apache/logs/access_log\ntail -100 "$DOMAIN"/servers/server_name/logs/server_name.log','Start with the same URL/user action and time range, not random logs.'),
])
h('8 OPatch')
tbl([
('I patch only after patch readme, approval, backup and shutdown requirement are confirmed.','export ORACLE_HOME=/absolute/middleware/PATH_TO_CONFIGURE\nexport JAVA_HOME=/absolute/jdk\n$ORACLE_HOME/OPatch/opatch version -jdk $JAVA_HOME','Confirms OPatch can run with correct home and JDK.'),
('I list installed patches before and after patching.','$ORACLE_HOME/OPatch/opatch lspatches -jdk $JAVA_HOME','Shows current patch IDs. Keep this output as patch evidence.'),
('I run conflict prereq before apply.','$ORACLE_HOME/OPatch/opatch prereq CheckConflictAgainstOHWithDetail -phBaseDir /absolute/patch_dir -jdk $JAVA_HOME','Must pass before applying. Read patch readme for sequence and component requirements.'),
('I apply only in approved maintenance after required services are stopped.','$ORACLE_HOME/OPatch/opatch apply /absolute/patch_dir -jdk $JAVA_HOME','OPatch success alone is not final. Verify lspatches, start services and test application.'),
])
h('9 SSL and Certificate Checks')
tbl([
('For SSL, I check expiry, hostname SAN, chain, keystore type and truststore.','$JAVA_HOME/bin/keytool -list -v -keystore /path/to/keystore.jks','Shows aliases, validity dates and SAN names. It asks for password; do not share it.'),
('I check certificate chain from a client server.','openssl s_client -connect hostname:7002 -showcerts </dev/null','Shows server certificate and intermediates received. Check verify return code and hostname separately.'),
])
h('10 Short Final Answers')
tbl([
('What is a cluster?','More than one managed server running same application for load balancing and high availability.','Cluster = capacity + availability.'),
('What are important logs?','AdminServer.log, ManagedServer.log, nodemanager.log, Apache access_log/error_log and OPatch logs.','Always start with real .log before changing config.'),
('How do you fix datasource issue?','Network -> URL -> user status -> listener -> pool -> DB sessions.','Do not change password or pool blindly.'),
('How do you fix slow app?','Trace one transaction from Apache to WebLogic to JDBC to database.','Find bottleneck before tuning.'),
])
for sec in doc.sections:
    p=sec.footer.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.add_run('WebLogic Command Cheat Sheet | ');fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');p._p.append(fld)
doc.core_properties.title='WebLogic Interview Command Cheat Sheet';doc.core_properties.author='USERNAME'
doc.save(out);print(out.resolve())
