# SANITIZED TEMPLATE: configure placeholders and review before use.
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from pathlib import Path

out = Path('outputs') / 'WebLogic_Interview_Easy_Notes.docx'
doc = Document()
sec = doc.sections[0]
sec.top_margin=Inches(.65); sec.bottom_margin=Inches(.65); sec.left_margin=Inches(.7); sec.right_margin=Inches(.7)
styles=doc.styles
styles['Normal'].font.name='Aptos'; styles['Normal'].font.size=Pt(11)
styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'),'Aptos')
styles['Normal'].paragraph_format.space_after=Pt(5)
for name,size in [('Title',24),('Heading 1',16),('Heading 2',12)]:
    s=styles[name]; s.font.name='Aptos'; s.font.size=Pt(size); s.font.bold=True; s.font.color.rgb=RGBColor(0,0,0)
    s.paragraph_format.space_before=Pt(14); s.paragraph_format.space_after=Pt(6)

def shade(c, fill):
    p=c._tc.get_or_add_tcPr(); e=OxmlElement('w:shd'); e.set(qn('w:fill'),fill); p.append(e)
def settext(c, txt, bold=False, white=False):
    c.text=''; p=c.paragraphs[0]; p.paragraph_format.space_after=Pt(1); r=p.add_run(txt); r.bold=bold; r.font.size=Pt(9.5)
    if white:r.font.color.rgb=RGBColor(255,255,255)
    c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
def grid(headers, rows, widths):
    t=doc.add_table(rows=1,cols=len(headers)); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.autofit=False
    for i,h in enumerate(headers): shade(t.rows[0].cells[i],'163A5F'); settext(t.rows[0].cells[i],h,True,True); t.rows[0].cells[i].width=Inches(widths[i])
    for n,row in enumerate(rows):
        cells=t.add_row().cells
        for i,x in enumerate(row):
            if n%2: shade(cells[i],'F2F6FA')
            settext(cells[i],x); cells[i].width=Inches(widths[i])
    doc.add_paragraph()
def bullet(x):
    p=doc.add_paragraph(style='List Bullet'); p.paragraph_format.space_after=Pt(2); p.add_run(x)
def answer(q, a, remember):
    doc.add_heading(q,2)
    p=doc.add_paragraph(); r=p.add_run('Simple answer: '); r.bold=True; p.add_run(a)
    p=doc.add_paragraph(); r=p.add_run('Remember: '); r.bold=True; p.add_run(remember)
def cmd(text):
    p=doc.add_paragraph(); p.paragraph_format.left_indent=Inches(.25); r=p.add_run(text); r.font.name='Consolas'; r.font.size=Pt(9)

p=doc.add_paragraph(style='Title'); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.add_run('WebLogic Interview Easy Notes')
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; r=p.add_run('Short answers you can understand and remember'); r.italic=True
doc.add_paragraph('Use this as a speaking guide. In an interview, first give the simple answer. Then say what you check in real time: process, port, log, configuration, database and network. Never say you will expose passwords or restart production without approval.')

doc.add_heading('Easy Memory Flow',1)
grid(['Problem','First checks'],[
('Server not starting','Process -> port -> server log -> Java -> keystore -> datasource'),
('Application slow','Apache -> WebLogic threads -> JDBC pool -> database -> OS'),
('Database not connecting','Network -> URL -> user lock -> pool -> database listener'),
('Patch work','Readme -> backup -> stop -> prereq -> apply -> verify -> start'),
('SSL error','Certificate expiry -> hostname -> chain -> keystore -> truststore'),
], [2.0,4.6])

doc.add_heading('Apache and WebLogic',1)
answer('How do you integrate Apache with WebLogic?', 'Apache stays in front. Users open the Apache URL. Apache sends the request to WebLogic using the WebLogic proxy plugin. WebLogic runs the application.', 'Apache = front door. WebLogic = application engine.')
answer('Where is the Apache WebLogic plugin?', 'It is installed with Oracle HTTP Server or separately with WebLogic proxy plugin software. In Apache configuration, we use directives like WebLogicHost, WebLogicPort, or WebLogicCluster.', 'One server: WebLogicHost. Many servers: WebLogicCluster.')
answer('What do you check if Apache gives 503?', 'Check Apache error log, then check whether WebLogic managed servers are running and their ports are listening. A 503 usually means Apache cannot use any backend server.', '503 = service is not available.')

doc.add_heading('WebLogic Cluster',1)
answer('What is a WebLogic cluster?', 'A cluster is more than one managed server working together. It gives load balancing and high availability. If one member fails, another member can serve requests.', 'Cluster = more servers, same application, better availability.')
answer('Why use a cluster?', 'For high availability, more capacity, and load balancing. Apache or a load balancer sends traffic to available members.', 'Cluster does not replace database backup or database high availability.')

doc.add_heading('JDBC Data Sources',1)
answer('What is a data source?', 'It is WebLogic database configuration. It contains database URL, driver, user, password and connection pool settings. Applications use JNDI name instead of creating database connections directly.', 'Data source = WebLogic connection pool for database.')
grid(['Type','Easy explanation'],[
('Generic data source','One database connection pool.'),
('XA data source','Used when one transaction needs more than one resource, for example database plus JMS.'),
('GridLink / Active GridLink','Used with Oracle RAC. It understands RAC events and failover.'),
('Multi data source','A group of data sources. It can fail over to another data source.'),
], [2.0,4.6])
answer('What is JDBC URL syntax?', 'For normal Oracle thin connection: jdbc:oracle:thin:@//host:1521/service_name. XA normally uses the same URL; the XA part is selected in WebLogic by using an XA driver/data source.', 'host : port 1521 / service name.')
cmd('jdbc:oracle:thin:@//dbhost.example.com:1521/service_name')
answer('How do you increase data source connection pool?', 'Open Admin Console: Services > Data Sources > select data source > Configuration > Connection Pool. Increase Maximum Capacity only after checking database session limit, slow SQL, and connection leaks.', 'Do not increase pool only because application is slow.')
answer('If data source is not connecting, what do you check?', 'Check database host and port, JDBC URL, service name/PDB service, user status, password, driver, database listener, firewall, pool capacity and SSL wallet if used.', 'Network -> URL -> user -> DB listener -> pool.')

doc.add_heading('Deployment',1)
answer('What is deployment order?', 'It decides which application starts first. Lower number starts first. Use it when one application depends on a library or another application.', 'Small number = starts first.')
answer('What do you do if deployment fails?', 'Read the real error in managed server log and AdminServer log. Check target server/cluster, application archive, deployment plan, JNDI name, data source, library dependency and Java version.', 'Do not redeploy again and again. Read the first real error.')

doc.add_heading('Logs You Must Know',1)
grid(['Log file','Why you check it'],[
('AdminServer.log','Admin Console, deployment, domain configuration and AdminServer startup.'),
('ManagedServer.log','Application errors, data source errors and managed server startup.'),
('nodemanager.log','Node Manager start/stop, Java Home and SSL errors.'),
('Apache access_log','Client request details and status codes.'),
('Apache error_log','Plugin, proxy, SSL and backend errors.'),
('OPatch logs','Patch apply and patch failure details.'),
], [2.0,4.6])
cmd('DOMAIN=/absolute/domain/path\ngrep -iE "RUNNING|ADMIN|FAILED|DeploymentException|Caused by|Exception" "$DOMAIN"/servers/*/logs/*.log | tail -120')

doc.add_heading('Server Not Starting',1)
answer('What are common reasons for a server not starting?', 'Wrong Java Home, port already in use, bad boot identity, wrong keystore type or missing certificate, disk full, data source failure, application deployment failure, or configuration error.', 'Process -> port -> log -> Java -> SSL -> DB -> disk.')
cmd('ps -ef | egrep "weblogic.Server|NodeManager" | grep -v grep\nnetstat -tulnp 2>/dev/null | egrep "7001|7002|9001|9002|5556|5558"')

doc.add_heading('Heap Dump and Thread Dump',1)
answer('What is a thread dump?', 'It shows what all Java threads are doing at one time. We use it for slowness, stuck threads, high CPU, deadlock and waiting database calls.', 'Thread dump = what threads are doing now.')
answer('How do you take and analyze thread dumps?', 'Take three thread dumps 30 to 60 seconds apart. Compare them. Check RUNNABLE high CPU threads, BLOCKED threads, deadlock, JDBC wait, stuck execute threads and repeated same stack trace.', 'Three dumps show whether the problem is continuing.')
cmd('$JAVA_HOME/bin/jstack -l <pid> > /tmp/thread_dump_1.txt')
answer('What is a heap dump?', 'It is a memory snapshot of the JVM. Use it for OutOfMemoryError or memory leak. It can be large and may contain sensitive data, so take it only with approval.', 'Heap dump = what is using memory.')
answer('How do you analyze a heap dump?', 'Open it in Eclipse MAT or another approved tool. Check largest retained objects, caches, sessions, classloader leaks and objects that keep growing.', 'Look for the object that keeps memory alive.')

doc.add_heading('Application Is Slow',1)
answer('What will you check if application is slow?', 'First identify which URL, user action and time is slow. Then check Apache access/error log, WebLogic execute threads, stuck threads, heap and GC, JDBC pool, slow SQL/database waits, CPU, memory, disk and network.', 'Follow one request from browser to Apache to WebLogic to DB.')

doc.add_heading('HTTP Error Codes',1)
grid(['Code','Easy meaning','What to check'],[
('404','Page not found.','Wrong URL, context root, rewrite rule or application not deployed.'),
('500','Application/server error.','Application exception, configuration or database error in server log.'),
('503','Service unavailable.','Backend server down, busy, maintenance, or Apache cannot connect to WebLogic.'),
], [1.0,1.65,3.95])

doc.add_heading('Patching with OPatch',1)
answer('How do you apply WebLogic patches using OPatch?', 'Read patch readme. Check Oracle Home, Java Home, OPatch version and conflict prereq. Take approved backup. Stop services if readme says so. Apply patch. Verify lspatches. Start services and validate application.', 'Readme -> backup -> stop -> prereq -> apply -> verify -> start.')
cmd('export ORACLE_HOME=/absolute/middleware/PATH_TO_CONFIGURE\nexport JAVA_HOME=/absolute/jdk\n$ORACLE_HOME/OPatch/opatch lspatches -jdk $JAVA_HOME\n$ORACLE_HOME/OPatch/opatch prereq CheckConflictAgainstOHWithDetail -phBaseDir /absolute/patch_dir -jdk $JAVA_HOME\n# Apply only in approved maintenance window\n$ORACLE_HOME/OPatch/opatch apply /absolute/patch_dir -jdk $JAVA_HOME')

doc.add_heading('Database Connection Details',1)
answer('How do you explain normal database details?', 'A normal connect descriptor has database user, host, listener port and service name. For Oracle, the common listener port is 1521. A PDB is normally accessed using its service name.', 'user/password@host:1521/service_name. Do not expose the real password.')

doc.add_heading('Best Final Interview Lines',1)
bullet('I first check process, listening port and the actual server log. Then I fix only after finding the real error.')
bullet('For slowness, I trace the request from Apache to WebLogic to JDBC to database instead of guessing.')
bullet('For patches and restarts, I follow the patch readme, take backup, get approval, verify after change and keep rollback plan.')
bullet('For SSL, I check certificate expiry, hostname SAN, complete certificate chain, keystore type and truststore.')
bullet('I never expose passwords, private keys or production secrets in logs, screenshots or commands.')

for s in doc.sections:
    f=s.footer.paragraphs[0]; f.alignment=WD_ALIGN_PARAGRAPH.CENTER; f.add_run('WebLogic Interview Easy Notes | ')
    fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE'); f._p.append(fld)
doc.core_properties.title='WebLogic Interview Easy Notes'
doc.core_properties.author='USERNAME'
doc.save(out)
print(out.resolve())
