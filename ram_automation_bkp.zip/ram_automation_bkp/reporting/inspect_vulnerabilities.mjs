// SANITIZED TEMPLATE: configure placeholders and review before use.
import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const source = "/PATH_TO_CONFIGURE";
const blob = await FileBlob.load(source);
const workbook = await SpreadsheetFile.importXlsx(blob);

const overview = await workbook.inspect({
  kind: "workbook,sheet,table",
  maxChars: 12000,
  tableMaxRows: 15,
  tableMaxCols: 20,
  tableMaxCellChars: 160,
});
await fs.writeFile("work/vulnerability_overview.txt", overview.ndjson, "utf8");

const sheets = await workbook.inspect({ kind: "sheet", include: "id,name", maxChars: 4000 });
await fs.writeFile("work/vulnerability_sheets.txt", sheets.ndjson, "utf8");

for (const sheetName of [...workbook.worksheets.items].map((s) => s.name)) {
  const table = await workbook.inspect({
    kind: "table",
    sheetId: sheetName,
    range: "A1:Z200",
    maxChars: 30000,
    tableMaxRows: 200,
    tableMaxCols: 26,
    tableMaxCellChars: 250,
  });
  await fs.writeFile(`work/vulnerability_${sheetName.replace(/[^a-zA-Z0-9_-]/g, "_")}.txt`, table.ndjson, "utf8");
}
