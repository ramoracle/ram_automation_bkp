// SANITIZED TEMPLATE: configure placeholders and review before use.
import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const table5Path = "/PATH_TO_CONFIGURE";
const priorRemediationPath = "outputs/final-remediation/USER_TABLE_5_final_remediation_report.xlsx";
const table6Path = "/PATH_TO_CONFIGURE";
const outputDir = "outputs/user-table-6-updates";
const allOutputPath = `${outputDir}/USER_TABLE_6_All_Findings_Update.xlsx`;
const criticalOutputPath = `${outputDir}/USER_TABLE_6_Critical_Findings_Update.xlsx`;

const baselineBook = await SpreadsheetFile.importXlsx(await FileBlob.load(table5Path));
const priorBook = await SpreadsheetFile.importXlsx(await FileBlob.load(priorRemediationPath));
const currentBook = await SpreadsheetFile.importXlsx(await FileBlob.load(table6Path));

const baselineRows = baselineBook.worksheets.getItem("USER TABLE").getUsedRange().values.slice(1);
const priorRows = priorBook.worksheets.getItem("USER TABLE").getUsedRange().values.slice(1);
const currentSheet = currentBook.worksheets.getItem("USER TABLE");
const currentValues = currentSheet.getUsedRange().values;
const headers = currentValues[0];
const currentRows = currentValues.slice(1);

function text(value) {
  return String(value ?? "").trim();
}

function qid(row) {
  const value = text(row[6]);
  const match = value.match(/QID-(\d+)/i);
  return match ? `QID-${match[1]}` : value.toLowerCase();
}

function directKey(row) {
  return [qid(row), text(row[1]).toLowerCase(), text(row[2]).toLowerCase(), text(row[8]), text(row[9])].join("|");
}

function logicalKey(row) {
  return [qid(row), text(row[2]).toLowerCase(), text(row[8]), text(row[9])].join("|");
}

function addToMap(map, key, row) {
  if (!map.has(key)) map.set(key, []);
  map.get(key).push(row);
}

const baselineDirect = new Map();
const baselineLogical = new Map();
for (const row of baselineRows) {
  addToMap(baselineDirect, directKey(row), row);
  addToMap(baselineLogical, logicalKey(row), row);
}

const fixedDirect = new Map();
const fixedLogical = new Map();
let priorFixedCount = 0;
for (const row of priorRows) {
  const status = text(row[15]);
  if (!status.startsWith("Fixed")) continue;
  priorFixedCount += 1;
  addToMap(fixedDirect, directKey(row), row);
  addToMap(fixedLogical, logicalKey(row), row);
}

function severityCountTemplate() {
  return { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0 };
}

const totals = severityCountTemplate();
const newlyAdded = severityCountTemplate();
const carriedForward = severityCountTemplate();
const reappearedFixed = severityCountTemplate();
const matchedFixedKeys = new Set();

const tracking = [];
for (const row of currentRows) {
  const severity = text(row[3]).toUpperCase();
  if (totals[severity] !== undefined) totals[severity] += 1;

  const direct = directKey(row);
  const logical = logicalKey(row);
  const priorFixed = fixedDirect.get(direct)?.[0] ?? fixedLogical.get(logical)?.[0] ?? null;
  const baselineMatch = baselineDirect.get(direct)?.[0] ?? baselineLogical.get(logical)?.[0] ?? null;

  if (priorFixed) {
    if (reappearedFixed[severity] !== undefined) reappearedFixed[severity] += 1;
    matchedFixedKeys.add(directKey(priorFixed));
    const previousStatus = text(priorFixed[15]) || "Fixed - rescan pending";
    const priorNote = text(priorFixed[16]);
    tracking.push([
      previousStatus,
      "Still listed in USER TABLE (6)",
      `Investigation needed: prior remediation was recorded, but this finding is still present in the latest report. ${priorNote}`,
    ]);
  } else if (baselineMatch) {
    if (carriedForward[severity] !== undefined) carriedForward[severity] += 1;
    tracking.push([
      "No remediation recorded",
      "Carried forward from USER TABLE (5)",
      "Pending remediation and validation.",
    ]);
  } else {
    if (newlyAdded[severity] !== undefined) newlyAdded[severity] += 1;
    tracking.push([
      "No previous finding",
      "Newly added in USER TABLE (6)",
      "Pending assessment and remediation.",
    ]);
  }
}

const severityOrder = ["CRITICAL", "HIGH", "MEDIUM", "LOW"];
const totalCurrent = currentRows.length;
const totalNew = severityOrder.reduce((sum, severity) => sum + newlyAdded[severity], 0);
const totalCarried = severityOrder.reduce((sum, severity) => sum + carriedForward[severity], 0);
const totalReappearedFixed = severityOrder.reduce((sum, severity) => sum + reappearedFixed[severity], 0);
const priorFixedNotPresent = priorFixedCount - totalReappearedFixed;

function statusFill(rowNumber, isCriticalOnly = false) {
  const comparison = tracking[rowNumber - 2][1];
  if (comparison === "Still listed in USER TABLE (6)") return { fill: "#FCE4D6", font: { color: "#9C0006" } };
  if (comparison.startsWith("Newly")) return { fill: "#FFF2CC", font: { color: "#7F6000" } };
  return { fill: "#EAF2F8", font: { color: "#1F4E78" } };
}

function writeSummary(sheet, title, filteredRows = null) {
  const total = filteredRows ? filteredRows.length : totalCurrent;
  const severitySet = filteredRows
    ? new Set(["CRITICAL"])
    : new Set(severityOrder);

  sheet.mergeCells("A1:F1");
  sheet.getRange("A1").values = [[title]];
  sheet.getRange("A1:F1").format = {
    fill: "#1F4E78",
    font: { bold: true, color: "#FFFFFF", size: 14 },
    horizontalAlignment: "center",
    verticalAlignment: "center",
  };
  sheet.mergeCells("A2:F2");
  sheet.getRange("A2").values = [["Comparison: USER TABLE (6), dated 2026-09-20, against USER TABLE (5) and the prior remediation tracking file."]];
  sheet.getRange("A2:F2").format = { font: { italic: true, color: "#595959" }, wrapText: true };

  sheet.getRange("A4:B4").values = [["Metric", "Count"]];
  sheet.getRange("A5:B11").values = [
    [filteredRows ? "Current Critical findings" : "Current findings", total],
    ["Prior remediation records", priorFixedCount],
    ["Prior remediations still listed in current report", totalReappearedFixed],
    ["Prior remediations not present by same finding/host/QID", priorFixedNotPresent],
    [filteredRows ? "Newly added Critical findings" : "Newly added findings", filteredRows ? newlyAdded.CRITICAL : totalNew],
    [filteredRows ? "Carried forward Critical findings" : "Carried forward findings", filteredRows ? carriedForward.CRITICAL : totalCarried],
    ["Current findings needing action", total],
  ];
  sheet.getRange("A4:B4").format = { fill: "#5B9BD5", font: { bold: true, color: "#FFFFFF" }, horizontalAlignment: "center" };
  sheet.getRange("A5:B11").format = { fill: "#EAF2F8" };

  sheet.getRange("D4:F4").values = [["Severity", "Current", "New / Carried / Still listed after remediation"]];
  const summaryRows = severityOrder
    .filter((severity) => severitySet.has(severity))
    .map((severity) => [
      severity,
      totals[severity],
      `${newlyAdded[severity]} / ${carriedForward[severity]} / ${reappearedFixed[severity]}`,
    ]);
  sheet.getRange(`D5:F${4 + summaryRows.length}`).values = summaryRows;
  sheet.getRange("D4:F4").format = { fill: "#5B9BD5", font: { bold: true, color: "#FFFFFF" }, horizontalAlignment: "center", wrapText: true };
  sheet.getRange(`D5:F${4 + summaryRows.length}`).format = { fill: "#EAF2F8", wrapText: true };

  sheet.mergeCells("A13:F14");
  sheet.getRange("A13").values = [["Important: A finding still listed in USER TABLE (6) is not treated as closed, even if remediation was recorded earlier. Verify the active version/path, complete any required restart, and obtain a fresh Qualys rescan before closing it."]];
  sheet.getRange("A13:F14").format = { fill: "#FFF2CC", font: { color: "#7F6000", italic: true }, wrapText: true, verticalAlignment: "center" };
  sheet.getRange("A:A").format.columnWidth = 48;
  sheet.getRange("B:B").format.columnWidth = 18;
  sheet.getRange("C:C").format.columnWidth = 4;
  sheet.getRange("D:D").format.columnWidth = 15;
  sheet.getRange("E:E").format.columnWidth = 12;
  sheet.getRange("F:F").format.columnWidth = 42;
  sheet.showGridLines = false;
}

// All findings workbook: retain the USER TABLE (6) source and append comparison columns.
currentSheet.getRange("P1:R1").values = [["Previous Remediation Status", "Comparison with USER TABLE (5)", "Required Action / Previous Notes"]];
currentSheet.getRange(`P2:R${currentRows.length + 1}`).values = tracking;
currentSheet.getRange("P1:R1").format = {
  fill: "#1F4E78",
  font: { bold: true, color: "#FFFFFF" },
  horizontalAlignment: "center",
  verticalAlignment: "center",
  wrapText: true,
};
currentSheet.getRange(`P2:R${currentRows.length + 1}`).format = { verticalAlignment: "top", wrapText: true };
currentSheet.getRange("P:P").format.columnWidth = 30;
currentSheet.getRange("Q:Q").format.columnWidth = 34;
currentSheet.getRange("R:R").format.columnWidth = 88;
for (let rowNumber = 2; rowNumber <= currentRows.length + 1; rowNumber += 1) {
  currentSheet.getRange(`P${rowNumber}:R${rowNumber}`).format = { ...statusFill(rowNumber), verticalAlignment: "top", wrapText: true };
}
currentSheet.freezePanes.freezeRows(1);

const allSummary = currentBook.worksheets.add("Comparison Summary");
writeSummary(allSummary, "All Findings Update", null);

// Critical-only workbook: use a compact tracking view with only current CRITICAL rows.
const criticalBook = Workbook.create();
const criticalSummary = criticalBook.worksheets.add("Summary");
const criticalSheet = criticalBook.worksheets.add("Critical Findings");
writeSummary(criticalSummary, "Critical Findings Update", currentRows.filter((row) => text(row[3]).toUpperCase() === "CRITICAL"));

const criticalHeaders = [...headers, "Previous Remediation Status", "Comparison with USER TABLE (5)", "Required Action / Previous Notes"];
const criticalData = [];
for (let i = 0; i < currentRows.length; i += 1) {
  if (text(currentRows[i][3]).toUpperCase() !== "CRITICAL") continue;
  criticalData.push([...currentRows[i], ...tracking[i]]);
}
criticalSheet.getRangeByIndexes(0, 0, 1, criticalHeaders.length).values = [criticalHeaders];
criticalSheet.getRangeByIndexes(1, 0, criticalData.length, criticalHeaders.length).values = criticalData;
criticalSheet.getRange(`A1:R1`).format = {
  fill: "#1F4E78",
  font: { bold: true, color: "#FFFFFF" },
  horizontalAlignment: "center",
  verticalAlignment: "center",
  wrapText: true,
};
criticalSheet.getRange(`A2:R${criticalData.length + 1}`).format = { verticalAlignment: "top", wrapText: true };
for (let r = 0; r < criticalData.length; r += 1) {
  const currentIndex = currentRows.findIndex((row) => directKey(row) === directKey(criticalData[r]));
  if (currentIndex >= 0) {
    const style = statusFill(currentIndex + 2, true);
    criticalSheet.getRange(`P${r + 2}:R${r + 2}`).format = { ...style, verticalAlignment: "top", wrapText: true };
  }
}
criticalSheet.getRange("A:A").format.columnWidth = 20;
criticalSheet.getRange("B:B").format.columnWidth = 58;
criticalSheet.getRange("C:C").format.columnWidth = 18;
criticalSheet.getRange("D:D").format.columnWidth = 13;
criticalSheet.getRange("E:F").format.columnWidth = 15;
criticalSheet.getRange("G:G").format.columnWidth = 55;
criticalSheet.getRange("H:H").format.columnWidth = 32;
criticalSheet.getRange("I:I").format.columnWidth = 18;
criticalSheet.getRange("J:J").format.columnWidth = 10;
criticalSheet.getRange("K:L").format.columnWidth = 16;
criticalSheet.getRange("M:M").format.columnWidth = 85;
criticalSheet.getRange("N:O").format.columnWidth = 28;
criticalSheet.getRange("P:P").format.columnWidth = 30;
criticalSheet.getRange("Q:Q").format.columnWidth = 34;
criticalSheet.getRange("R:R").format.columnWidth = 88;
criticalSheet.freezePanes.freezeRows(1);
criticalSheet.showGridLines = false;
criticalSheet.tables.add(`A1:R${criticalData.length + 1}`, true, "CriticalFindingsTable");

const verification = {
  totalCurrent,
  priorFixedCount,
  totalNew,
  totalCarried,
  totalReappearedFixed,
  priorFixedNotPresent,
  totals,
  newlyAdded,
  carriedForward,
  reappearedFixed,
  criticalRows: criticalData.length,
};

console.log(JSON.stringify({ phase: "counts", verification }, null, 2));

const allSummaryCheck = await currentBook.inspect({
  kind: "table",
  sheetId: "Comparison Summary",
  range: "A1:F14",
  include: "values,formulas",
  tableMaxRows: 14,
  tableMaxCols: 6,
});
console.log(allSummaryCheck.ndjson);
const criticalSummaryCheck = await criticalBook.inspect({
  kind: "table",
  sheetId: "Summary",
  range: "A1:F14",
  include: "values,formulas",
  tableMaxRows: 14,
  tableMaxCols: 6,
});
console.log(criticalSummaryCheck.ndjson);
for (const [label, workbook] of [["all", currentBook], ["critical", criticalBook]]) {
  const errors = await workbook.inspect({
    kind: "match",
    searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!",
    options: { useRegex: true, maxResults: 300 },
    summary: `${label} formula error scan`,
  });
  console.log(errors.ndjson);
}

await fs.mkdir(outputDir, { recursive: true });
for (const [workbook, sheetName, fileName] of [
  [currentBook, "Comparison Summary", "all_summary_preview.png"],
  [criticalBook, "Summary", "critical_summary_preview.png"],
  [criticalBook, "Critical Findings", "critical_findings_preview.png"],
]) {
  const preview = await workbook.render({ sheetName, autoCrop: "all", scale: 1, format: "png" });
  await fs.writeFile(`${outputDir}/${fileName}`, new Uint8Array(await preview.arrayBuffer()));
}

const allFile = await SpreadsheetFile.exportXlsx(currentBook);
await allFile.save(allOutputPath);
const criticalFile = await SpreadsheetFile.exportXlsx(criticalBook);
await criticalFile.save(criticalOutputPath);

console.log(JSON.stringify({ allOutputPath, criticalOutputPath, verification }, null, 2));
