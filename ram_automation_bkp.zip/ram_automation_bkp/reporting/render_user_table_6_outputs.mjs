// SANITIZED TEMPLATE: configure placeholders and review before use.
import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const outputDir = "outputs/user-table-6-updates";
const criticalPath = `${outputDir}/USER_TABLE_6_Critical_Findings_Update.xlsx`;
const allPath = `${outputDir}/USER_TABLE_6_All_Findings_Update.xlsx`;

for (const [path, sheetName, imageName, range] of [
  [criticalPath, "Critical Findings", "critical_findings_top_preview.png", "A1:R8"],
  [allPath, "USER TABLE", "all_findings_top_preview.png", "A1:R8"],
]) {
  const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(path));
  const preview = await workbook.render({ sheetName, range, scale: 0.8, format: "png" });
  await fs.writeFile(`${outputDir}/${imageName}`, new Uint8Array(await preview.arrayBuffer()));
}
