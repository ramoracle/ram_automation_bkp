// SANITIZED TEMPLATE: configure placeholders and review before use.
import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const inputPath = "outputs/final-remediation/USER_TABLE_5_final_remediation_updated.xlsx";
const outputPath = "outputs/final-remediation/remediation_summary_before_update.png";

const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(inputPath));
const summary = await workbook.inspect({
  kind: "table",
  sheetId: "Remediation Summary",
  range: "A1:F18",
  include: "values,formulas",
  tableMaxRows: 18,
  tableMaxCols: 6,
});
console.log(summary.ndjson);

const preview = await workbook.render({
  sheetName: "Remediation Summary",
  range: "A1:F18",
  scale: 1.5,
  format: "png",
});
await fs.writeFile(outputPath, new Uint8Array(await preview.arrayBuffer()));
