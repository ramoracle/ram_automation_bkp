// SANITIZED TEMPLATE: configure placeholders and review before use.
import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const outputPath = "outputs/HOSTNAME/USER_TABLE_5_HOSTNAME_updated.xlsx";
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(outputPath));

const values = workbook.worksheets.getItem("USER TABLE").getUsedRange().values;
const hostRows = values
  .map((row, index) => ({ row: index + 1, finding: row[1], host: row[2], status: row[15], notes: row[16] }))
  .filter((row) => row.host === "HOSTNAME");

const checks = {
  hostRows,
  summary: await workbook.inspect({ kind: "table", range: "Remediation Summary!A1:D13", maxChars: 6000 }),
  formulaErrors: await workbook.inspect({
    kind: "match",
    searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
    options: { useRegex: true, maxResults: 100 },
  }),
};
console.log(JSON.stringify(checks, null, 2));

const preview = await workbook.render({
  sheetName: "Remediation Summary",
  range: "A1:D13",
  scale: 2,
  format: "png",
});
await fs.writeFile("outputs/HOSTNAME/remediation_summary_preview.png", new Uint8Array(await preview.arrayBuffer()));
