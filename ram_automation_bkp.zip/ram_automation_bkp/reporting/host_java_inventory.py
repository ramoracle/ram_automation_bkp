# SANITIZED TEMPLATE: configure placeholders and review before use.
import json
import re
import pandas as pd

source = r"/PATH_TO_CONFIGURE"
hosts = [
    "HOSTNAME", "HOSTNAME", "HOSTNAME", "HOSTNAME",
    "HOSTNAME", "HOSTNAME", "HOSTNAME", "HOSTNAME",
    "HOSTNAME", "HOSTNAME", "HOSTNAME", "HOSTNAME",
    "HOSTNAME", "HOSTNAME", "HOSTNAME", "HOSTNAME",
    "HOSTNAME",
]

df = pd.read_excel(source)
df["Display Name"] = df["Display Name"].astype(str).str.strip()
records = []

for host in hosts:
    rows = df[(df["Display Name"] == host) & df["Finding Summary"].astype(str).str.contains("Java", case=False, na=False)]
    versions = set()
    findings = set()
    last_seen = set()
    for _, row in rows.iterrows():
        finding = str(row["Finding Summary"])
        findings.add(finding)
        if pd.notna(row.get("Last Seen Timestamp")):
            last_seen.add(str(pd.to_datetime(row["Last Seen Timestamp"]).date()))
        m = re.search(r"Java\s+(\d+)\s+is installed on host", finding, re.I)
        if m:
            versions.add(f"Java {m.group(1)} (major version only)")
        output = str(row.get("Plugin Output", ""))
        versions.update(re.findall(r'"version"\s*:\s*"([^"]+)"', output))
        versions.update(re.findall(r"\b(?:1\.8\.0_\d+(?:-b\d+)?|(?:11|17|21|25)\.\d+(?:\.\d+)?(?:\+[^\s,\"]+)?)", output))
    records.append({
        "host": host,
        "reported_java_versions": sorted(versions),
        "java_finding_count": len(rows),
        "last_seen": sorted(last_seen),
        "status": "Java detected by report" if len(rows) else "No Java finding in report",
    })

print(json.dumps(records, indent=2))
