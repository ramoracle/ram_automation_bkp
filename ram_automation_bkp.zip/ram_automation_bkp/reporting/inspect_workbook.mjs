// SANITIZED TEMPLATE: configure placeholders and review before use.
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const inputPath = "/PATH_TO_CONFIGURE";
const input = await FileBlob.load(inputPath);
const workbook = await SpreadsheetFile.importXlsx(input);

const summary = await workbook.inspect({
  kind: "workbook,sheet,table",
  maxChars: 12000,
  tableMaxRows: 12,
  tableMaxCols: 20,
  tableMaxCellChars: 160,
});
console.log(summary.ndjson);

for (const sheet of workbook.worksheets.items) {
  const used = sheet.getUsedRange();
  console.log(`--- ${sheet.name} ${used.address} ---`);
  const sample = await workbook.inspect({
    kind: "table",
    sheetId: sheet.name,
    range: used.address,
    maxChars: 16000,
    tableMaxRows: 30,
    tableMaxCols: 24,
    tableMaxCellChars: 160,
  });
  console.log(sample.ndjson);

  const values = sheet.getUsedRange().values;
  console.log("--- candidates ---");
  values.forEach((row, index) => {
    const finding = String(row[1] ?? "");
    const host = String(row[2] ?? "");
    if (
      host === "HOSTNAME" ||
      (host === "HOSTNAME" && /(WebLogic|Coherence)/i.test(finding)) ||
      (host === "HOSTNAME" && /(WebLogic|Coherence)/i.test(finding)) ||
      (host === "HOSTNAME" && /(Spring Cloud Function|Oracle Java.*(April 2025|July 2025))/i.test(finding)) ||
      (host === "HOSTNAME" && /Oracle Java.*(April 2025|July 2025)/i.test(finding)) ||
      (host === "HOSTNAME" && /Tomcat/i.test(finding)) ||
      (host === "HOSTNAME" && /Oracle Java/i.test(finding))
    ) {
      console.log(JSON.stringify({ row: index + 1, finding, host, severity: row[3], plugin: row[12] }));
    }
  });
  console.log("--- all 5940/639 findings ---");
  values.forEach((row, index) => {
    const host = String(row[2] ?? "");
    if (host === "HOSTNAME" || host === "HOSTNAME") {
      console.log(JSON.stringify({ row: index + 1, finding: row[1], host, severity: row[3] }));
    }
  });
}
