// SANITIZED TEMPLATE: configure placeholders and review before use.
import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const outputPath = "outputs/user-table-5-remediation/USER_TABLE_5_remediation_updated.xlsx";
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(outputPath));

const checks = {
  sheets: await workbook.inspect({ kind: "sheet", include: "id,name" }),
  statusHeaders: await workbook.inspect({
    kind: "table",
    range: "USER TABLE!P1:Q12",
    maxChars: 4000,
  }),
  summary: await workbook.inspect({
    kind: "table",
    range: "Remediation Summary!A1:D11",
    maxChars: 4000,
  }),
  formulaErrors: await workbook.inspect({
    kind: "match",
    searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
    options: { useRegex: true, maxResults: 100 },
  }),
};

console.log(JSON.stringify(checks, null, 2));

const preview = await workbook.render({
  sheetName: "Remediation Summary",
  range: "A1:D11",
  scale: 2,
  format: "png",
});
await fs.writeFile(
  "outputs/user-table-5-remediation/remediation_summary_preview.png",
  new Uint8Array(await preview.arrayBuffer())
);
