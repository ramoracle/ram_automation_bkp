# SANITIZED TEMPLATE: configure placeholders and review before use.
import json
import pandas as pd

source = r"/PATH_TO_CONFIGURE"
df = pd.read_excel(source)
df.columns = [str(c).strip() for c in df.columns]
df["Severity"] = df["Severity"].astype(str).str.upper().str.strip()
for c in ["First Seen Timestamp", "Last Seen Timestamp", "Report Generated Timestamp"]:
    df[c] = pd.to_datetime(df[c], errors="coerce")

order = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]
severity = df["Severity"].value_counts().reindex(order, fill_value=0).to_dict()
by_host = (df.groupby(["Display Name", "Ip Address"], dropna=False)
    .agg(findings=("Finding Summary", "size"),
         critical=("Severity", lambda x: (x == "CRITICAL").sum()),
         high=("Severity", lambda x: (x == "HIGH").sum()),
         medium=("Severity", lambda x: (x == "MEDIUM").sum()),
         low=("Severity", lambda x: (x == "LOW").sum()),
         oldest_first_seen=("First Seen Timestamp", "min"),
         last_seen=("Last Seen Timestamp", "max"))
    .reset_index()
    .sort_values(["critical", "high", "findings"], ascending=False))
by_finding = (df.groupby(["Finding Summary", "Severity"], dropna=False)
    .agg(affected_servers=("Display Name", "nunique"),
         instances=("Display Name", "size"),
         hosts=("Display Name", lambda x: ", ".join(sorted(set(x.astype(str))))))
    .reset_index()
    .sort_values(["Severity", "affected_servers", "instances"], key=lambda c: c.map({"CRITICAL":0,"HIGH":1,"MEDIUM":2,"LOW":3}).fillna(9) if c.name == "Severity" else c, ascending=[True, False, False]))
priority = df[df["Severity"].isin(["CRITICAL", "HIGH"])].copy()
priority["age_days"] = (priority["Report Generated Timestamp"] - priority["First Seen Timestamp"]).dt.days
priority = priority.sort_values(["Severity", "age_days"], key=lambda c: c.map({"CRITICAL":0,"HIGH":1}) if c.name == "Severity" else c, ascending=[True, False])
java = df[df["Finding Summary"].str.contains("Java", case=False, na=False)].copy()
java_summary = (java.groupby(["Finding Summary", "Severity"], dropna=False)
    .agg(affected_servers=("Display Name", "nunique"),
         instances=("Display Name", "size"),
         hosts=("Display Name", lambda x: ", ".join(sorted(set(x.astype(str))))))
    .reset_index()
    .sort_values(["Severity", "affected_servers"], key=lambda c: c.map({"CRITICAL":0,"HIGH":1,"MEDIUM":2,"LOW":3}).fillna(9) if c.name == "Severity" else c, ascending=[True, False]))

result = {
  "rows": len(df),
  "servers": int(df["Display Name"].nunique()),
  "severity": severity,
  "critical_or_high": int(len(priority)),
  "host_summary": json.loads(by_host.head(20).to_json(orient="records", date_format="iso")),
  "finding_summary": json.loads(by_finding.head(30).to_json(orient="records")),
  "priority_records": json.loads(priority[["Severity","Display Name","Ip Address","Operating System","Finding Summary","First Seen Timestamp","Last Seen Timestamp","age_days","Instancecontact"]].head(40).to_json(orient="records", date_format="iso")),
  "java_summary": json.loads(java_summary.to_json(orient="records")),
}
print(json.dumps(result, indent=2))
