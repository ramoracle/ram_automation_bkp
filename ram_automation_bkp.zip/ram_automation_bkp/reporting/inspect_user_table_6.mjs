// SANITIZED TEMPLATE: configure placeholders and review before use.
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const inputPath = "/PATH_TO_CONFIGURE";
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(inputPath));

console.log((await workbook.inspect({
  kind: "workbook,sheet,table",
  maxChars: 12000,
  tableMaxRows: 12,
  tableMaxCols: 20,
  tableMaxCellChars: 160,
})).ndjson);

for (const sheet of workbook.worksheets.items) {
  const values = sheet.getUsedRange().values;
  const counts = {};
  for (const row of values.slice(1)) {
    const severity = String(row[3] ?? "").trim().toUpperCase() || "BLANK";
    counts[severity] = (counts[severity] ?? 0) + 1;
  }
  console.log(JSON.stringify({ sheet: sheet.name, usedRange: sheet.getUsedRange().address, rows: values.length - 1, severityCounts: counts }));
}
