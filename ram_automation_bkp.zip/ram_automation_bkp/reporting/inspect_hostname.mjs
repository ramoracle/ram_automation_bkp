// SANITIZED TEMPLATE: configure placeholders and review before use.
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const inputPath = "outputs/final-remediation/USER_TABLE_5_final_remediation.xlsx";
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(inputPath));
const sheet = workbook.worksheets.getItem("USER TABLE");
const values = sheet.getUsedRange().values;

console.log(JSON.stringify({ headers: values[0] }, null, 2));
values.forEach((row, index) => {
  if (String(row[2] ?? "") === "HOSTNAME") {
    console.log(JSON.stringify({ row: index + 1, values: row }, null, 2));
  }
});

const preview = await workbook.render({
  sheetName: "USER TABLE",
  range: "A1:Q12",
  scale: 1,
  format: "png",
});
console.log(JSON.stringify({ previewBytes: (await preview.arrayBuffer()).byteLength }));
