#!/bin/bash
# SANITIZED PUBLICATION TEMPLATE. Review all placeholders and destructive operations.
# Execution intentionally blocked. Remove the following exit only after review.
echo "Disabled template: configure and review before use." >&2
exit 99

# Weekly online PDB clone for DATABASE_NAME.
# Run from cron each Sunday. Set FORCE_RUN=Y only for an approved manual run.

set -u

ORACLE_SID="${ORACLE_SID:-DATABASE_NAME}"
ORACLE_BASE="${ORACLE_BASE:-/PATH_TO_CONFIGURE}"
ORACLE_HOME="${ORACLE_HOME:-}"
SOURCE_PDB="${SOURCE_PDB:-DATABASE_NAME}"
CLONE_PREFIX="${CLONE_PREFIX:-DATABASE_NAME}"
DATE_TAG="$(date +%Y%m%d)"
TARGET_PDB="${CLONE_PREFIX}_${DATE_TAG}"
TARGET_ROOT="${TARGET_ROOT:-/PATH_TO_CONFIGURE}"
TARGET_DIR="${TARGET_ROOT}/${TARGET_PDB}"
LOG_DIR="${LOG_DIR:-/PATH_TO_CONFIGURE}"
LOG_FILE="${LOG_DIR}/${TARGET_PDB}_$(date +%Y%m%d_%H%M%S).log"
EMAIL_TO="${EMAIL_TO:-EMAIL_ADDRESS}"
FORCE_RUN="${FORCE_RUN:-N}"

export ORACLE_SID ORACLE_BASE

mkdir -p "$LOG_DIR"

log_msg() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"
}

send_mail() {
  local subject="$1"
  if command -v mail >/dev/null 2>&1; then
    mail -s "$subject" $EMAIL_TO < "$LOG_FILE"
  else
    log_msg "mail command not found; skipping email notification."
  fi
}

# Safety guard: run only on Sunday unless an approved manual run uses FORCE_RUN=Y.
if [ "$(date +%u)" != "7" ] && [ "$FORCE_RUN" != "Y" ]; then
  log_msg "Today is not Sunday. Clone skipped. Set FORCE_RUN=Y to run manually."
  exit 0
fi

mkdir -p "$TARGET_DIR"

export ORAENV_ASK=NO
PATH=/usr/local/bi/PATH_TO_CONFIGURE
export PATH

if [ -x /usr/local/bin/oraenv ]; then
  . /usr/local/bin/oraenv >>"$LOG_FILE" 2>&1
elif [ -x /usr/bin/oraenv ]; then
  . /usr/bin/oraenv >>"$LOG_FILE" 2>&1
elif command -v oraenv >/dev/null 2>&1; then
  . oraenv >>"$LOG_FILE" 2>&1
else
  log_msg "oraenv not found. Set ORACLE_HOME or confirm the oraenv path."
  send_mail "PDB Clone FAILED - ${TARGET_PDB}"
  exit 1
fi

if [ -n "${ORACLE_HOME:-}" ] && [ -x "${ORACLE_HOME}/bin/sqlplus" ]; then
  SQLPLUS="${ORACLE_HOME}/bin/sqlplus"
elif command -v sqlplus >/dev/null 2>&1; then
  SQLPLUS="$(command -v sqlplus)"
else
  log_msg "sqlplus not found after oraenv. ORACLE_HOME=${ORACLE_HOME:-not_set}"
  send_mail "PDB Clone FAILED - ${TARGET_PDB}"
  exit 1
fi

log_msg "Oracle environment loaded. ORACLE_HOME=${ORACLE_HOME}, SQLPLUS=${SQLPLUS}"

IS_MONTH_END="N"
if [ "$(date +%m)" != "$(date -d tomorrow +%m)" ]; then
  IS_MONTH_END="Y"
fi

log_msg "Starting PDB clone. ORACLE_SID=${ORACLE_SID}, SOURCE_PDB=${SOURCE_PDB}, TARGET_PDB=${TARGET_PDB}"
log_msg "Target directory: ${TARGET_DIR}"
log_msg "Month-end cleanup enabled: ${IS_MONTH_END}"

"$SQLPLUS" -s / as sysdba >>"$LOG_FILE" 2>&1 <<SQLEND
whenever oserror exit failure
whenever sqlerror exit failure
set echo on
set serveroutput on size unlimited
set feedback on
set timing on

alter session set container = CDB\$ROOT;

prompt Current PDB status before clone
select name, open_mode from v\$pdbs order by con_id;

prompt Validate source PDB and ARCHIVELOG mode
declare
  v_source_mode varchar2(20);
  v_log_mode    varchar2(20);
begin
  begin
    select open_mode
      into v_source_mode
      from v\$pdbs
     where name = upper('${SOURCE_PDB}');
  exception
    when no_data_found then
      raise_application_error(-20002, 'Source PDB ${SOURCE_PDB} not found.');
  end;

  if v_source_mode <> 'READ WRITE' then
    raise_application_error(-20001,
      'Source PDB ${SOURCE_PDB} is not READ WRITE. Current state: ' || v_source_mode);
  end if;

  select log_mode into v_log_mode from v\$database;
  if v_log_mode <> 'ARCHIVELOG' then
    raise_application_error(-20003,
      'Database must be in ARCHIVELOG mode for an online PDB clone. Current mode: ' || v_log_mode);
  end if;
end;
/

prompt Archive current redo before online clone
alter system archive log current;

prompt Drop same-day target if it already exists
begin
  for r in (
    select pdb_name
      from dba_pdbs
     where pdb_name = upper('${TARGET_PDB}')
  ) loop
    execute immediate 'alter pluggable database ${TARGET_PDB} close immediate instances=all';
    execute immediate 'drop pluggable database ${TARGET_PDB} including datafiles';
  end loop;
end;
/

prompt Create weekly dated clone
create pluggable database ${TARGET_PDB}
from ${SOURCE_PDB}
create_file_dest = '${TARGET_DIR}/';

alter pluggable database ${TARGET_PDB} open read write;
alter pluggable database ${TARGET_PDB} save state;

prompt Month-end cleanup of old cloned PDBs
begin
  if '${IS_MONTH_END}' = 'Y' then
    for r in (
      select pdb_name
        from dba_pdbs
       where substr(pdb_name, 1, length('${CLONE_PREFIX}') + 1) =
             upper('${CLONE_PREFIX}') || '_'
         and pdb_name <> upper('${TARGET_PDB}')
       order by pdb_name
    ) loop
      dbms_output.put_line('Dropping old cloned PDB: ' || r.pdb_name);
      execute immediate 'alter pluggable database ' || r.pdb_name || ' close immediate instances=all';
      execute immediate 'drop pluggable database ' || r.pdb_name || ' including datafiles';
    end loop;
  else
    dbms_output.put_line('Not month-end; old cloned PDB cleanup skipped.');
  end if;
end;
/

prompt Current PDB status after clone/cleanup
select name, open_mode from v\$pdbs order by con_id;

exit;
SQLEND

STATUS=$?

if [ "$STATUS" -eq 0 ]; then
  log_msg "Clone completed successfully. TARGET_PDB=${TARGET_PDB}"
  send_mail "PDB Clone SUCCESS - ${TARGET_PDB}"
else
  log_msg "Clone failed. A partial PDB may remain mounted: ${TARGET_PDB}. Do not delete .dbf files manually. Check log: ${LOG_FILE}"
  send_mail "PDB Clone FAILED - ${TARGET_PDB}"
fi

exit "$STATUS"
