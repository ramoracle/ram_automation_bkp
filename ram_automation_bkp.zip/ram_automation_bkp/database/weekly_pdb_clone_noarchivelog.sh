#!/bin/bash
# SANITIZED PUBLICATION TEMPLATE. Review all placeholders and destructive operations.
# Execution intentionally blocked. Remove the following exit only after review.
echo "Disabled template: configure and review before use." >&2
exit 99

# Weekly PDB clone for a CDB that remains in NOARCHIVELOG mode.
# The source PDB is temporarily switched to READ ONLY for the clone.
#
# Author: USERNAME
# Support: If there are any issues, contact USERNAME.
#
# IMPORTANT: Applications using SOURCE_PDB are disconnected while the PDB is
# switched from READ WRITE to READ ONLY, and again when it returns to READ WRITE.

set -u

ORACLE_SID="${ORACLE_SID:-DATABASE_NAME}"
ORACLE_BASE="${ORACLE_BASE:-/PATH_TO_CONFIGURE}"
ORACLE_HOME="${ORACLE_HOME:-}"
SOURCE_PDB="${SOURCE_PDB:-DATABASE_NAME}"
CLONE_PREFIX="${CLONE_PREFIX:-DATABASE_NAME}"
DATE_TAG="$(date +%Y%m%d)"
TARGET_PDB="${CLONE_PREFIX}_${DATE_TAG}"
TARGET_ROOT="${TARGET_ROOT:-/PATH_TO_CONFIGURE}"
TARGET_DIR="${TARGET_ROOT}/${TARGET_PDB}"
LOG_DIR="${LOG_DIR:-/PATH_TO_CONFIGURE}"
LOG_FILE="${LOG_DIR}/${TARGET_PDB}_$(date +%Y%m%d_%H%M%S).log"
EMAIL_TO="${EMAIL_TO:-EMAIL_ADDRESS}"
FORCE_RUN="${FORCE_RUN:-N}"
DRY_RUN="${DRY_RUN:-N}"

export ORACLE_SID ORACLE_BASE

mkdir -p "$LOG_DIR"

log_msg() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"
}

send_mail() {
  local subject="$1"
  if command -v mail >/dev/null 2>&1; then
    mail -s "$subject" $EMAIL_TO < "$LOG_FILE"
  else
    log_msg "mail command not found; skipping email notification."
  fi
}

# Run only on Sunday unless an approved manual run uses FORCE_RUN=Y.
if [ "$(date +%u)" != "7" ] && [ "$FORCE_RUN" != "Y" ]; then
  log_msg "Today is not Sunday. Clone skipped. Set FORCE_RUN=Y to run manually."
  exit 0
fi

if [ "$DRY_RUN" != "Y" ]; then
  mkdir -p "$TARGET_DIR"
fi

export ORAENV_ASK=NO
PATH=/usr/local/bi/PATH_TO_CONFIGURE
export PATH

if [ -x /usr/local/bin/oraenv ]; then
  . /usr/local/bin/oraenv >>"$LOG_FILE" 2>&1
elif [ -x /usr/bin/oraenv ]; then
  . /usr/bin/oraenv >>"$LOG_FILE" 2>&1
elif command -v oraenv >/dev/null 2>&1; then
  . oraenv >>"$LOG_FILE" 2>&1
else
  log_msg "oraenv not found. Set ORACLE_HOME or confirm the oraenv path."
  send_mail "PDB Clone FAILED - ${TARGET_PDB}"
  exit 1
fi

if [ -n "${ORACLE_HOME:-}" ] && [ -x "${ORACLE_HOME}/bin/sqlplus" ]; then
  SQLPLUS="${ORACLE_HOME}/bin/sqlplus"
elif command -v sqlplus >/dev/null 2>&1; then
  SQLPLUS="$(command -v sqlplus)"
else
  log_msg "sqlplus not found after oraenv. ORACLE_HOME=${ORACLE_HOME:-not_set}"
  send_mail "PDB Clone FAILED - ${TARGET_PDB}"
  exit 1
fi

restore_source_read_write() {
  log_msg "Ensuring source PDB ${SOURCE_PDB} is READ WRITE."
  "$SQLPLUS" -s / as sysdba >>"$LOG_FILE" 2>&1 <<SQLEND
whenever sqlerror continue
set serveroutput on
alter session set container = CDB\$ROOT;
declare
  v_mode varchar2(20);
begin
  select open_mode into v_mode from v\$pdbs where name = upper('${SOURCE_PDB}');
  if v_mode = 'READ ONLY' then
    execute immediate 'alter pluggable database ${SOURCE_PDB} close immediate';
    execute immediate 'alter pluggable database ${SOURCE_PDB} open read write';
  elsif v_mode = 'MOUNTED' then
    execute immediate 'alter pluggable database ${SOURCE_PDB} open read write';
  elsif v_mode <> 'READ WRITE' then
    raise_application_error(-20004, 'Unexpected source PDB state: ' || v_mode);
  end if;
end;
/
select name, open_mode from v\$pdbs where name = upper('${SOURCE_PDB}');
exit;
SQLEND
}

trap 'log_msg "Script interrupted. Restoring source PDB to READ WRITE."; restore_source_read_write; send_mail "PDB Clone INTERRUPTED - ${TARGET_PDB}"; exit 130' INT TERM

log_msg "Author: USERNAME. For support, contact USERNAME."
log_msg "Oracle environment loaded. ORACLE_HOME=${ORACLE_HOME}, SQLPLUS=${SQLPLUS}"
log_msg "Starting NOARCHIVELOG PDB clone. SOURCE_PDB=${SOURCE_PDB}, TARGET_PDB=${TARGET_PDB}"
log_msg "Target directory: ${TARGET_DIR}"

if [ "$DRY_RUN" = "Y" ]; then
  log_msg "DRY RUN enabled. No PDB will be closed, opened, cloned, or dropped."
  "$SQLPLUS" -s / as sysdba >>"$LOG_FILE" 2>&1 <<SQLEND
whenever oserror exit failure
whenever sqlerror exit failure
set lines 200 pages 100
set feedback on
alter session set container = CDB\$ROOT;

prompt Dry-run validation: database mode and source PDB state
select log_mode from v\$database;
select name, open_mode from v\$pdbs where name = upper('${SOURCE_PDB}');

prompt Dry-run validation: current target name
select pdb_name, status from dba_pdbs where pdb_name = upper('${TARGET_PDB}');
exit;
SQLEND
  STATUS=$?
  if [ "$STATUS" -eq 0 ]; then
    log_msg "Dry run completed successfully. No database changes were made."
    send_mail "PDB Clone DRY RUN SUCCESS - ${TARGET_PDB}"
  else
    log_msg "Dry run failed. No database changes were made. Check log: ${LOG_FILE}"
    send_mail "PDB Clone DRY RUN FAILED - ${TARGET_PDB}"
  fi
  exit "$STATUS"
fi

IS_MONTH_END="N"
if [ "$(date +%m)" != "$(date -d tomorrow +%m)" ]; then
  IS_MONTH_END="Y"
fi

"$SQLPLUS" -s / as sysdba >>"$LOG_FILE" 2>&1 <<SQLEND
whenever oserror exit failure
whenever sqlerror exit failure
set echo on
set serveroutput on size unlimited
set feedback on
set timing on

alter session set container = CDB\$ROOT;

prompt Validate source PDB and NOARCHIVELOG mode
declare
  v_source_mode varchar2(20);
  v_log_mode    varchar2(20);
begin
  begin
    select open_mode into v_source_mode
    from v\$pdbs
    where name = upper('${SOURCE_PDB}');
  exception
    when no_data_found then
      raise_application_error(-20002, 'Source PDB ${SOURCE_PDB} not found.');
  end;

  if v_source_mode <> 'READ WRITE' then
    raise_application_error(-20001,
      'Source PDB ${SOURCE_PDB} must begin in READ WRITE mode. Current state: ' || v_source_mode);
  end if;

  select log_mode into v_log_mode from v\$database;
  if v_log_mode <> 'NOARCHIVELOG' then
    raise_application_error(-20003,
      'This script is for NOARCHIVELOG only. Current database mode: ' || v_log_mode);
  end if;
end;
/

prompt Drop same-day target if it already exists
begin
  for r in (
    select pdb_name from dba_pdbs where pdb_name = upper('${TARGET_PDB}')
  ) loop
    execute immediate 'alter pluggable database ${TARGET_PDB} close immediate instances=all';
    execute immediate 'drop pluggable database ${TARGET_PDB} including datafiles';
  end loop;
end;
/

prompt Switch source PDB to READ ONLY for the clone
alter pluggable database ${SOURCE_PDB} close immediate;
alter pluggable database ${SOURCE_PDB} open read only;

prompt Create weekly dated clone
create pluggable database ${TARGET_PDB}
from ${SOURCE_PDB}
create_file_dest = '${TARGET_DIR}/';

alter pluggable database ${TARGET_PDB} open read write;
alter pluggable database ${TARGET_PDB} save state;

prompt Restore source PDB to READ WRITE
alter pluggable database ${SOURCE_PDB} close immediate;
alter pluggable database ${SOURCE_PDB} open read write;

prompt Month-end cleanup of old cloned PDBs
begin
  if '${IS_MONTH_END}' = 'Y' then
    for r in (
      select pdb_name
      from dba_pdbs
      where substr(pdb_name, 1, length('${CLONE_PREFIX}') + 1) =
            upper('${CLONE_PREFIX}') || '_'
        and pdb_name <> upper('${TARGET_PDB}')
      order by pdb_name
    ) loop
      dbms_output.put_line('Dropping old cloned PDB: ' || r.pdb_name);
      execute immediate 'alter pluggable database ' || r.pdb_name || ' close immediate instances=all';
      execute immediate 'drop pluggable database ' || r.pdb_name || ' including datafiles';
    end loop;
  else
    dbms_output.put_line('Not month-end; old cloned PDB cleanup skipped.');
  end if;
end;
/

prompt Current PDB status after clone/cleanup
select name, open_mode from v\$pdbs order by con_id;
exit;
SQLEND

STATUS=$?

if [ "$STATUS" -ne 0 ]; then
  log_msg "Clone failed. Attempting to restore source PDB to READ WRITE."
  restore_source_read_write
  log_msg "Clone failed. Do not delete .dbf files manually. Check log: ${LOG_FILE}"
  send_mail "PDB Clone FAILED - ${TARGET_PDB}"
  exit "$STATUS"
fi

log_msg "Clone completed successfully. TARGET_PDB=${TARGET_PDB}"
send_mail "PDB Clone SUCCESS - ${TARGET_PDB}"
exit 0
