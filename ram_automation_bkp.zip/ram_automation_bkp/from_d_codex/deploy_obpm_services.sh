#!/bin/bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99


export CLASSPATH=/PATH_TO_CONFIGURE

ADMIN_URL="${ADMIN_URL:-t3/PATH_TO_CONFIGURE"
WL_USER="${WL_USER:-weblogic}"
WL_PASSWORD="SECRET_REMOVED"
APP_DIR="${APP_DIR:-/PATH_TO_CONFIGURE}"
LOG_FILE="${LOG_FILE:-/PATH_TO_CONFIGURE}"

mkdir -p "$(dirname "$LOG_FILE")"

echo " STARTED deployments of OBPM Services " > "$LOG_FILE"

deploy_app() {
  war_file="$1"
  target="$2"
  app_path="$APP_DIR/$war_file"
  app_name="${war_file%.war}"

  if [ ! -f "$app_path" ]; then
    echo "MISSING: $app_path" | tee -a "$LOG_FILE"
    return 1
  fi

  echo "Deploying $app_name to $target" | tee -a "$LOG_FILE"

  java \
    -Dweblogic.security.SSL.ignoreHostnameVerification=true \
    -Dweblogic.security.TrustKeyStore=CustomTrust \
    -Dweblogic.security.CustomTrustKeyStoreFileName=/PATH_TO_CONFIGURE \
    weblogic.Deployer \
    -adminurl "$ADMIN_URL" \
    -user "$WL_USER" \
    -password "$WL_PASSWORD" \
    -name "$app_name" \
    -targets "$target" \
    -deploy "$app_path" \
    -remote \
    -upload >> "$LOG_FILE" 2>&1

  rc=$?
  if [ $rc -eq 0 ]; then
    echo "SUCCESS: $app_name deployed to $target" | tee -a "$LOG_FILE"
  else
    echo "FAILED : $app_name deployment to $target failed, rc=$rc" | tee -a "$LOG_FILE"
  fi

  return $rc
}

failures=0

deploy_app "obpm-china-service-10.2.0.war" "cl1" || failures=$((failures + 1))
deploy_app "obpm-crossborder-service-10.2.0.war" "cl1" || failures=$((failures + 1))
deploy_app "obpm-europe-instant-service-10.2.0.war" "cl1" || failures=$((failures + 1))
deploy_app "obpm-europe-service-10.2.0.war" "cl1" || failures=$((failures + 1))
deploy_app "obpm-foundation-service-10.2.0.war" "cl1" || failures=$((failures + 1))
deploy_app "obpm-generic-services-10.2.0.war" "cl1" || failures=$((failures + 1))
deploy_app "obpm-india-imps-service-10.2.0.war" "cl1" || failures=$((failures + 1))
deploy_app "obpm-india-service-10.2.0.war" "cl1" || failures=$((failures + 1))
deploy_app "obpm-india-upi-fin-service-10.2.0.war" "cl1" || failures=$((failures + 1))
deploy_app "obpm-india-upi-nonfin-service-10.2.0.war" "cl1" || failures=$((failures + 1))
deploy_app "obpm-india-upi-psp-fin-service-10.2.0.war" "cl1" || failures=$((failures + 1))
deploy_app "obpm-india-upi-psp-nonfin-service-10.2.0.war" "cl1" || failures=$((failures + 1))
deploy_app "obpm-interface-service-10.2.0.war" "cl1" || failures=$((failures + 1))
deploy_app "obpm-us-instant-service-10.2.0.war" "cl1" || failures=$((failures + 1))
deploy_app "obpm-us-service-10.2.0.war" "cl1" || failures=$((failures + 1))

echo " COMPLETED deployments of OBPM Services. failures=$failures " | tee -a "$LOG_FILE"

exit $failures
