#!/usr/bin/env bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99

# FCINT-3 ODT9 application deployment script.
# Libraries are intentionally excluded; run deploy_odt9_libraries_fcint3.sh first.

set -uo pipefail

DOMAIN_HOME="${DOMAIN_HOME:-/PATH_TO_CONFIGURE}"
JAVA_HOME="${JAVA_HOME:-/PATH_TO_CONFIGURE}"
WL_HOME="${WL_HOME:-/PATH_TO_CONFIGURE}"
ADMIN_URL="${ADMIN_URL:-t3://hostname:PORT}"
APP_DIR="${APP_DIR:-${DOMAIN_HOME}/deployment-services/odt9}"
WL_USER="${WL_USER:-weblogic}"
WL_PASSWORD="SECRET_REMOVED"
DEPLOY_MODE="${DEPLOY_MODE:-deploy}"
SLEEP_SECONDS="${SLEEP_SECONDS:-15}"
LOG_FILE="${LOG_FILE:-${DOMAIN_HOME}/deployment-services/logs/odt9-services-$(date +%Y%m%d-%H%M%S).log}"
WEBLOGIC_JAR="${WL_HOME}/server/lib/weblogic.jar"

if [[ ! -x "${JAVA_HOME}/bin/java" ]]; then echo "ERROR: Java not found: ${JAVA_HOME}/bin/java" >&2; exit 2; fi
if [[ ! -r "${WEBLOGIC_JAR}" ]]; then echo "ERROR: WebLogic jar not found: ${WEBLOGIC_JAR}" >&2; exit 2; fi
if [[ ! -d "${APP_DIR}" ]]; then echo "ERROR: Artifact directory not found: ${APP_DIR}" >&2; exit 2; fi
if [[ "${DEPLOY_MODE}" != deploy && "${DEPLOY_MODE}" != redeploy ]]; then echo "ERROR: DEPLOY_MODE must be deploy or redeploy" >&2; exit 2; fi

export JAVA_HOME
export PATH="${JAVA_HOME}/bin:${PATH}"
export CLASSPATH="${WEBLOGIC_JAR}${CLASSPATH:+:${CLASSPATH}}"
mkdir -p "$(dirname "${LOG_FILE}")"; touch "${LOG_FILE}"; chmod 600 "${LOG_FILE}"

if [[ -z "${WL_PASSWORD}" ]]; then read -r -s -p "WebLogic password for ${WL_USER}: " WL_PASSWORD; printf '\n'; fi
AUTH_ARGS=(-user "${WL_USER}" -password "${WL_PASSWORD}")

log() { printf '%s | %s\n' "$(date '+%F %T')" "$*" | tee -a "${LOG_FILE}"; }

resolve_artifact() {
  local name="$1" type="$2" path
  for path in "${APP_DIR}/${name}" "${APP_DIR}/${name}.${type}"; do
    [[ -f "${path}" || -d "${path}" ]] && { printf '%s\n' "${path}"; return 0; }
  done
  return 1
}

deploy_app() {
  local name="$1" type="$2" target="$3" artifact app_name cmdlog rc
  artifact="$(resolve_artifact "${name}" "${type}")" || { log "MISSING: ${name} under ${APP_DIR}"; return 1; }
  app_name="$(basename "${artifact}")"; app_name="${app_name%.war}"; app_name="${app_name%.ear}"
  cmdlog="$(mktemp /tmp/odt9_service.XXXXXX)"
  log "Deploying ${app_name} to ${target}"
  if [[ "${DEPLOY_MODE}" == redeploy ]]; then
    "${JAVA_HOME}/bin/java" weblogic.Deployer -adminurl "${ADMIN_URL}" "${AUTH_ARGS[@]}" -name "${app_name}" -targets "${target}" -redeploy -source "${artifact}" -remote -upload >"${cmdlog}" 2>&1
  else
    "${JAVA_HOME}/bin/java" weblogic.Deployer -adminurl "${ADMIN_URL}" "${AUTH_ARGS[@]}" -name "${app_name}" -targets "${target}" -deploy "${artifact}" -remote -upload >"${cmdlog}" 2>&1
  fi
  rc=$?; sed 's/-password [^ ]*/-password ********/g' "${cmdlog}" >> "${LOG_FILE}"; rm -f "${cmdlog}"
  [[ ${rc} -eq 0 ]] && log "SUCCESS: ${app_name}" || log "FAILED: ${app_name}; rc=${rc}"
  sleep "${SLEEP_SECONDS}"; return ${rc}
}

failures=0
log "STARTED ODT9 application deployment; mode=${DEPLOY_MODE}; app_dir=${APP_DIR}"
while IFS='|' read -r name type target; do
  [[ -z "${name}" || "${name}" == \#* ]] && continue
  deploy_app "${name}" "${type}" "${target}" || failures=$((failures + 1))
done <<'SERVICES'
ELCMExtPricing.ear|ear|FCServer_1
ELCMRest.war|war|FCServer_1
ELCMWeb.war|war|FCServer_1
FCJNeoWeb|war|FCServer_1
FCJPlatoReST.war|war|FCServer_1
FCUBSCalcEngine.war|war|FCServer_1
GWHTTP.war|war|FCServer_1
GWMDB.war|war|FCServer_1
GWWS-Rest.war|war|FCServer_1
MAINWeb.war|war|FCServer_1
OBCLCalcEngine.war|war|FCServer_1
OBTFCalcEngine.war|war|FCServer_1
OBTFWeb.war|war|FCServer_1
OBTRCalcEngine.war|war|FCServer_1
OBTRWeb.war|war|FCServer_1
OFCLWeb.war|war|FCServer_1
PaymentStubs|ear|FCServer_1
ROFCWeb.war|war|FCServer_1
SMWeb.war|war|FCServer_1
fcubs-charge-calc-services-10.2.0.war|war|Plato_1
fcubs-co-batch-services-10.2.0.war|war|Plato_1
fcubs-customer-acc-service-10.2.0.war|war|Plato_1
fcubs-intchg-accting-services-10.2.0.war|war|Plato_1
fcubs-interest-accrual-services-10.2.0.war|war|Plato_1
fcubs-interest-allocate-services-10.2.0.war|war|Plato_1
fcubs-interest-batch-services-10.2.0.war|war|Plato_1
fcubs-interest-calc-services-10.2.0.war|war|Plato_1
fcubs-interest-extrp-service-10.2.0.war|war|Plato_1
fcubs-td-mo-dashboard-service-10.2.0|war|Plato_1
obbrn-casacustomeraccount-services-10.2.0.war|war|Plato_1
fcubs-co-mo-lov-service-10.2.0|war|Plato
fcubs-eca-services-10.2.0.war|war|Plato
fcubs-ext-accounting-services-10.2.0.war|war|Plato
fcubs-interest-input-services-10.2.0|war|Plato
fcubs-interest-liquidation-services-10.2.0.war|war|Plato
fcubs-interest-resolve-services-10.2.0.war|war|Plato
fcubs-ln-mo-dashboard-service-10.2.0.war|war|Plato
fcubs-online-liquidation-services-10.2.0.war|war|Plato
fcubs-signature-service-10.2.0.war|war|Plato
fcubs-td-alloc-services-10.2.0.war|war|Plato
fcubs-td-deposit-services-10.2.0.war|war|Plato
fcubs-td-maturity-services-10.2.0.war|war|Plato
fcubs-td-mo-adapter-service-10.2.0.war|war|Plato
fcubs-td-mo-operations-services-10.2.0.war|war|Plato
obpy-customer-services-10.2.0|war|Plato
obremo-srv-acc-credit-card-details-service-10.2.0.war|war|Plato
obremo-srv-acc-safe-Banking-details-service-10.2.0|war|Plato
obremo-srv-acc-signature-details-service-10.2.0|war|Plato
obremo-srv-customer-query-service-10.2.0|war|Plato
plato-config-service-10.2.0.war|war|Plato
plato-discovery-service-10.2.0.war|war|Plato
obpm-api-gateway-10.2.0|war|OBPM
obpm-china-service-10.2.0.war|war|OBPM
obpm-crossborder-service-10.2.0.war|war|OBPM
obpm-europe-instant-service-10.2.0.war|war|OBPM
obpm-europe-service-10.2.0.war|war|OBPM
obpm-foundation-service-10.2.0|war|OBPM
obpm-generic-services-10.2.0|war|OBPM
obpm-india-imps-service-10.2.0.war|war|OBPM
obpm-india-service-10.2.0.war|war|OBPM
obpm-india-upi-fin-service-10.2.0.war|war|OBPM
obpm-india-upi-psp-fin-service-10.2.0|war|OBPM
obpm-interface-service-10.2.0|war|OBPM
obpm-us-instant-service-10.2.0.war|war|OBPM
obpm-us-service-10.2.0.war|war|OBPM
SERVICES

log "COMPLETED ODT9 application deployment; failures=${failures}"
exit "${failures}"
