#!/bin/bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99

set -euo pipefail

# Creates OBCR JDBC generic datasources in WebLogic using WLST.
# Run from the WebLogic host, or copy this file there first.
#
# Required at runtime:
#   DB_URL       example: https://hostname.invalid
#   DB_USER      database user for the datasources
#   DB_PASSWORD  database password for the datasources
#
# Optional overrides:
#   ADMIN_URL, ADMIN_USER, ADMIN_PASSWORD, DOMAIN_HOME, ORACLE_COMMON, WLST_SH
#   DB_DRIVER, TEST_TABLE_NAME, UPDATE_EXISTING, INITIAL_CAPACITY, MAX_CAPACITY

ADMIN_HOST="${ADMIN_HOST:-hostname}"
ADMIN_URL="${ADMIN_URL:-t3/PATH_TO_CONFIGURE"
ADMIN_USER="${ADMIN_USER:-weblogic}"

DOMAIN_HOME="${DOMAIN_HOME:-/PATH_TO_CONFIGURE}"
DOMAIN_BIN="${DOMAIN_BIN:-${DOMAIN_HOME}/bin}"
ORACLE_COMMON="${ORACLE_COMMON:-/PATH_TO_CONFIGURE}"
WLST_SH="${WLST_SH:-${ORACLE_COMMON}/bin/wlst.sh}"

DB_DRIVER="${DB_DRIVER:-oracle.jdbc.OracleDriver}"
TEST_TABLE_NAME="${TEST_TABLE_NAME:-SQL SELECT 1 FROM DUAL}"
UPDATE_EXISTING="${UPDATE_EXISTING:-false}"
INITIAL_CAPACITY="${INITIAL_CAPACITY:-1}"
MAX_CAPACITY="${MAX_CAPACITY:-15}"

DB_URL="${DB_URL:-}"
DB_USER="${DB_USER:-}"
DB_PASSWORD="SECRET_REMOVED"
ADMIN_PASSWORD="SECRET_REMOVED"

prompt_value() {
  var_name="$1"
  prompt="$2"
  current="${!var_name:-}"
  if [ -z "$current" ]; then
    if [ -t 0 ]; then
      printf "%s: " "$prompt" >&2
      IFS= read -r value
    else
      echo "ERROR: ${var_name} is required; export it before running non-interactively." >&2
      exit 1
    fi
    printf -v "$var_name" "%s" "$value"
  fi
}

prompt_secret() {
  var_name="$1"
  prompt="$2"
  current="${!var_name:-}"
  if [ -z "$current" ]; then
    if [ -t 0 ]; then
      printf "%s: " "$prompt" >&2
      stty -echo
      IFS= read -r value
      stty echo
      printf "\n" >&2
    else
      echo "ERROR: ${var_name} is required; export it before running non-interactively." >&2
      exit 1
    fi
    printf -v "$var_name" "%s" "$value"
  fi
}

prompt_secret ADMIN_PASSWORD "WebLogic admin password"
prompt_value DB_URL "Database JDBC URL"
prompt_value DB_USER "Database user"
prompt_secret DB_PASSWORD "Database password"

if [ ! -x "$WLST_SH" ]; then
  echo "ERROR: WLST not found or not executable: $WLST_SH" >&2
  exit 1
fi

if [ -f "${DOMAIN_BIN}/setDomainEnv.sh" ]; then
  set +u
  . "${DOMAIN_BIN}/setDomainEnv.sh" >/dev/null 2>&1
  set -u
fi

export ADMIN_URL ADMIN_USER ADMIN_PASSWORD
export DB_URL DB_USER DB_PASSWORD DB_DRIVER TEST_TABLE_NAME UPDATE_EXISTING
export INITIAL_CAPACITY MAX_CAPACITY

WLST_SCRIPT="${TMPDIR:-/tmp}/create_obcr_datasources_$$.py"
trap 'rm -f "$WLST_SCRIPT"' EXIT

cat > "$WLST_SCRIPT" <<'PY'
from java.lang import System, String
from javax.management import ObjectName
from jarray import array

def env(name, default=''):
    value = System.getenv(name)
    if value is None or value == '':
        return default
    return value

admin_url = env('ADMIN_URL')
admin_user = env('ADMIN_USER')
admin_password = env('ADMIN_PASSWORD')
db_url = env('DB_URL')
db_user = env('DB_USER')
db_password = env('DB_PASSWORD')
db_driver = env('DB_DRIVER', 'oracle.jdbc.OracleDriver')
test_table_name = env('TEST_TABLE_NAME', 'SQL SELECT 1 FROM DUAL')
update_existing = env('UPDATE_EXISTING', 'false').lower() in ('1', 'true', 'yes', 'y')
initial_capacity = int(env('INITIAL_CAPACITY', '1'))
max_capacity = int(env('MAX_CAPACITY', '15'))

datasources = [
    ('CMNCORE', 'jdbc/CMNCORE', ['obcr_cluster1', 'obcr_cluster2']),
    ('CR_ACCTNG', 'jdbc/CR_ACCTNG', ['obcr_cluster1', 'obcr_cluster2']),
    ('CR_ACTION', 'jdbc/CR_ACTION', ['obcr_cluster1']),
    ('CR_ACTIVITY', 'jdbc/CR_ACTIVITY', ['obcr_cluster1', 'obcr_cluster2']),
    ('CR_CMN', 'jdbc/CR_CMN', ['obcr_cluster1']),
    ('CR_CORR', 'jdbc/CR_CORR', ['obcr_cluster1']),
    ('CR_DASHBOARD', 'jdbc/CR_DASHBOARD', ['obcr_cluster1', 'obcr_cluster2']),
    ('CR_DATAEXCHNG', 'jdbc/CR_DATAEXCHNG', ['obcr_cluster1', 'obcr_cluster2']),
    ('CR_ENTITY', 'jdbc/CR_ENTITY', ['obcr_cluster1']),
    ('CR_FEECHRG', 'jdbc/CR_FEECHRG', ['obcr_cluster1', 'obcr_cluster2']),
    ('CR_NOTES', 'jdbc/CR_NOTES', ['obcr_cluster2']),
    ('CR_PTP', 'jdbc/CR_PTP', ['obcr_cluster1', 'obcr_cluster2']),
    ('CR_SEG', 'jdbc/CR_SEG', ['obcr_cluster1', 'obcr_cluster2']),
    ('CR_SEGMAINT', 'jdbc/CR_SEGMAINT', ['obcr_cluster2']),
    ('CR_SETLMNT', 'jdbc/CR_SETLMNT', ['obcr_cluster1', 'obcr_cluster2']),
    ('CR_STRTGY', 'jdbc/CR_STRTGY', ['obcr_cluster2']),
    ('CR_STRTGYMAINT', 'jdbc/CR_STRTGYMAINT', ['obcr_cluster2']),
    ('CR_TASK', 'jdbc/CR_TASK', ['obcr_cluster2']),
    ('CR_TASKMAINT', 'jdbc/CR_TASKMAINT', ['obcr_cluster2']),
    ('CR_USERMGMT', 'jdbc/CR_USERMGMT', ['obcr_cluster2']),
    ('CR_VNDRMGMT', 'jdbc/CR_VNDRMGMT', ['obcr_cluster1', 'obcr_cluster2']),
    ('PLATO', 'jdbc/PLATO', ['obcr_cluster1', 'obcr_cluster2']),
    ('PLATOBATCH', 'jdbc/PLATOBATCH', ['obcr_cluster1', 'obcr_cluster2']),
    ('PLATOFDT', 'jdbc/PLATOFDT', ['obcr_cluster1', 'obcr_cluster2']),
    ('PLATOFEED', 'jdbc/PLATOFEED', ['obcr_cluster1', 'obcr_cluster2']),
    ('PLATORULE', 'jdbc/PLATORULE', ['obcr_cluster1', 'obcr_cluster2']),
    ('PLATOSEC', 'jdbc/PLATO_SECURITY', ['obcr_cluster1', 'obcr_cluster2']),
    ('PLATO_UI', 'jdbc/PLATOUI', ['obcr_cluster1', 'obcr_cluster2']),
    ('SMS', 'jdbc/sms', ['obcr_cluster1', 'obcr_cluster2']),
]

def target_object(target_name):
    if getMBean('/Clusters/%s' % target_name) is not None:
        return ObjectName('com.bea:Name=%s,Type=Cluster' % target_name)
    if getMBean('/Servers/%s' % target_name) is not None:
        return ObjectName('com.bea:Name=%s,Type=Server' % target_name)
    raise Exception('Target not found as Cluster or Server: %s' % target_name)

def set_targets(ds_name, target_names):
    cd('/JDBCSystemResources/%s' % ds_name)
    objects = []
    for target_name in target_names:
        objects.append(target_object(target_name))
    set('Targets', array(objects, ObjectName))

def ensure_property(property_path, property_name, property_value):
    cd(property_path)
    if getMBean('%s/Properties/%s' % (property_path, property_name)) is None:
        cmo.createProperty(property_name)
    cd('%s/Properties/%s' % (property_path, property_name))
    cmo.setValue(property_value)

def create_or_update_datasource(ds_name, jndi_name, target_names):
    resource_path = '/JDBCSystemResources/%s' % ds_name
    exists = getMBean(resource_path) is not None

    if exists and not update_existing:
        print('SKIP existing datasource: %s' % ds_name)
        return

    if not exists:
        cd('/')
        cmo.createJDBCSystemResource(ds_name)
        print('CREATE datasource: %s' % ds_name)
    else:
        print('UPDATE datasource: %s' % ds_name)

    jdbc_resource_path = '%s/JDBCResource/%s' % (resource_path, ds_name)
    cd(jdbc_resource_path)
    cmo.setName(ds_name)

    cd('%s/JDBCDataSourceParams/%s' % (jdbc_resource_path, ds_name))
    set('JNDINames', array([jndi_name], String))
    set('GlobalTransactionsProtocol', 'OnePhaseCommit')

    cd('%s/JDBCDriverParams/%s' % (jdbc_resource_path, ds_name))
    set('DriverName', db_driver)
    set('Url', db_url)
    set('PasswordEncrypted', db_password)
    set('UseXaDataSourceInterface', 'false')

    ensure_property(
        '%s/JDBCDriverParams/%s/Properties/%s' % (jdbc_resource_path, ds_name, ds_name),
        'user',
        db_user
    )

    cd('%s/JDBCConnectionPoolParams/%s' % (jdbc_resource_path, ds_name))
    set('TestTableName', test_table_name)
    set('InitialCapacity', initial_capacity)
    set('MaxCapacity', max_capacity)
    set('TestConnectionsOnReserve', 'true')

    set_targets(ds_name, target_names)

connect(admin_user, admin_password, admin_url)
edit()
startEdit()

try:
    for ds_name, jndi_name, target_names in datasources:
        create_or_update_datasource(ds_name, jndi_name, target_names)
    save()
    activate(block='true')
    print('Completed datasource creation/update.')
except:
    print('ERROR: Rolling back current edit session.')
    try:
        undo('true', 'y')
        cancelEdit('y')
    except:
        pass
    raise
finally:
    disconnect()
PY

echo "Creating OBCR datasources on ${ADMIN_URL}"
echo "WLST: ${WLST_SH}"
echo "Domain: ${DOMAIN_HOME}"
"$WLST_SH" "$WLST_SCRIPT"
