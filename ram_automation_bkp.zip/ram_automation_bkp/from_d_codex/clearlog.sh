#!/bin/bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99

set -u

###############################################################################
# RAM/SBAT clear log utility
# Place this file in:
#   /PATH_TO_CONFIGURE
#
# Default target log location:
#   /PATH_TO_CONFIGURE
#
# Examples:
#   ./clearlog.sh --dry-run
#   ./clearlog.sh
#   ./clearlog.sh --age 2
#   ./clearlog.sh --to EMAIL_ADDRESS
###############################################################################

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG_DIR="${SCRIPT_DIR}/logs"
TARGET_DIR="/PATH_TO_CONFIGURE"
TO_MAIL="${TO_MAIL:-EMAIL_ADDRESS}"
CC_MAIL="${CC_MAIL:-EMAIL_ADDRESS,EMAIL_ADDRESS}"
FROM_NAME="${FROM_NAME:-SBAT-CLEARLOGS}"
DRY_RUN="NO"
MIN_AGE_DAYS=""

usage() {
  cat <<EOF
Usage: $0 [options]

Options:
  --target <path>   Log directory to clean. Default: /PATH_TO_CONFIGURE
  --age <days>      Delete only files older than N days.
  --to <email>      Notification recipient. Default: $TO_MAIL
  --cc <emails>     Comma separated CC list.
  --dry-run         Show what will be deleted without deleting.
  -h, --help        Show this help.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --target)
      TARGET_DIR="${2:-}"
      shift 2
      ;;
    --age)
      MIN_AGE_DAYS="${2:-}"
      shift 2
      ;;
    --to)
      TO_MAIL="${2:-}"
      shift 2
      ;;
    --cc)
      CC_MAIL="${2:-}"
      shift 2
      ;;
    --dry-run)
      DRY_RUN="YES"
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1"
      usage
      exit 2
      ;;
  esac
done

if [[ -n "$MIN_AGE_DAYS" && ! "$MIN_AGE_DAYS" =~ ^[0-9]+$ ]]; then
  echo "ERROR: --age must be a number."
  exit 2
fi

if [[ ! -d "$TARGET_DIR" ]]; then
  echo "ERROR: Target directory not found: $TARGET_DIR"
  exit 2
fi

mkdir -p "$LOG_DIR"

RUN_TS="$(date +%Y%m%d_%H%M%S)"
REPORT="${LOG_DIR}/clear_logs_${RUN_TS}.log"
SERVER="$(hostname -f 2>/dev/null || hostname)"
TARGET_ABS="$(cd "$TARGET_DIR" && pwd -P)"
SCRATCH_AVAIL_BEFORE="$(df -Ph /PATH_TO_CONFIGURE | awk 'NR==2 {print $4}')"
TARGET_SIZE_BEFORE="$(du -sh "$TARGET_ABS" 2>/dev/null | awk '{print $1}')"

deleted_count=0
deleted_bytes=0
failed_count=0

write_header() {
  {
    echo "Clear Logs Status"
    echo "Server              : $SERVER"
    echo "Run user            : $(whoami)"
    echo "Target directory    : $TARGET_ABS"
    echo "Dry run             : $DRY_RUN"
    echo "Minimum age days    : ${MIN_AGE_DAYS:-all matching files}"
    echo "Started at          : $(date)"
    echo "Scratch free before : $SCRATCH_AVAIL_BEFORE"
    echo "Target size before  : ${TARGET_SIZE_BEFORE:-unknown}"
    echo
    echo "Files matching cleanup patterns:"
  } > "$REPORT"
}

file_size() {
  stat -c%s "$1" 2>/dev/null || echo 0
}

process_file() {
  local file="$1"
  local file_abs
  file_abs="$(readlink -f "$file" 2>/dev/null || echo "$file")"

  case "$file_abs" in
    "$TARGET_ABS"/*)
      ;;
    *)
      echo "SKIP outside target: $file_abs" >> "$REPORT"
      return
      ;;
  esac

  local bytes
  bytes="$(file_size "$file_abs")"
  echo "$file_abs" >> "$REPORT"

  if [[ "$DRY_RUN" == "YES" ]]; then
    deleted_count=$((deleted_count + 1))
    deleted_bytes=$((deleted_bytes + bytes))
    return
  fi

  if rm -f -- "$file_abs"; then
    deleted_count=$((deleted_count + 1))
    deleted_bytes=$((deleted_bytes + bytes))
  else
    failed_count=$((failed_count + 1))
    echo "FAILED delete: $file_abs" >> "$REPORT"
  fi
}

run_cleanup() {
  if [[ -n "$MIN_AGE_DAYS" ]]; then
    while IFS= read -r -d '' file; do
      process_file "$file"
    done < <(
      find "$TARGET_ABS" -type f -mtime +"$MIN_AGE_DAYS" \( \
        -name '*ELCM*.TXT.*' -o \
        -name '*ELCM.TXT*.*' -o \
        -name '*SYSTEM*.TXT' -o \
        -name '*.TXT' -o \
        -name '*.TXT.0' -o \
        -name '*.trc' -o \
        -name '*.out' -o \
        -name '*.log' \
      \) -print0 2>/dev/null
    )
  else
    while IFS= read -r -d '' file; do
      process_file "$file"
    done < <(
      find "$TARGET_ABS" -type f \( \
        -name '*ELCM*.TXT.*' -o \
        -name '*ELCM.TXT*.*' -o \
        -name '*SYSTEM*.TXT' -o \
        -name '*.TXT' -o \
        -name '*.TXT.0' -o \
        -name '*.trc' -o \
        -name '*.out' -o \
        -name '*.log' \
      \) -print0 2>/dev/null
    )
  fi
}

send_mail() {
  local subject="Clear Logs Status on $SERVER"

  if command -v mailx >/dev/null 2>&1; then
    if [[ -n "$CC_MAIL" ]]; then
      mailx -s "$subject" -r "$FROM_NAME" -c "$CC_MAIL" "$TO_MAIL" < "$REPORT"
    else
      mailx -s "$subject" -r "$FROM_NAME" "$TO_MAIL" < "$REPORT"
    fi
  elif command -v mail >/dev/null 2>&1; then
    mail -s "$subject" "$TO_MAIL" < "$REPORT"
  else
    echo "WARNING: mailx/mail command not found. Email notification not sent." >> "$REPORT"
  fi
}

write_header
run_cleanup

SCRATCH_AVAIL_AFTER="$(df -Ph /PATH_TO_CONFIGURE | awk 'NR==2 {print $4}')"
TARGET_SIZE_AFTER="$(du -sh "$TARGET_ABS" 2>/dev/null | awk '{print $1}')"

{
  echo
  echo "Summary"
  echo "Deleted count        : $deleted_count"
  echo "Failed count         : $failed_count"
  echo "Approx bytes matched : $deleted_bytes"
  echo "Scratch free after   : $SCRATCH_AVAIL_AFTER"
  echo "Target size after    : ${TARGET_SIZE_AFTER:-unknown}"
  echo "Completed at         : $(date)"
  echo
  echo "For any further issues, kindly reach out to EMAIL_ADDRESS"
  echo
  echo "Thanks -- SBAT INFRA TEAM"
} >> "$REPORT"

send_mail

cat "$REPORT"

if [[ "$failed_count" -gt 0 ]]; then
  exit 1
fi
