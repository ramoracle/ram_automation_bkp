# Additional D-drive automation templates

Added 30 October 2026. This folder preserves the relative layout of selected automation sources from the user-specified D-drive folder. See `manifest.json` for the 67 prepared source/configuration templates.

## Contents

- WebLogic deployment, domain operations, undeployment and version utilities
- Domain wrappers and guided menu/wizard runners
- Java upgrade scripts
- RMAN backup/restore workflow templates, plus field-only configuration examples
- `ramctl` modules for database, cloning, RMAN and middleware operations
- WebLogic UI server/launcher and sanitized sample configuration
- Vulnerability comparison, spreadsheet tracking and documentation generators
- A PowerShell SSH runner and a Chef/Ruby patch-install template

No live databases, SSH endpoints, mail services, WebLogic servers or Chef operations were contacted. No original files were changed. Nothing was uploaded to GitHub.

## Sanitization and exclusions

Identified IPs, private hosts, local paths, account names, email addresses, database names and credential literals were replaced. Distinct discovered hosts use `hostname`, `hostname_2`, etc.; no mapping back to the private originals is published. Some identifiers in variable names and technical product/domain names remain as context, not connection details. Version numbers can resemble IP addresses; review all substitutions before adaptation.

Live auth/domain JSON, real `.conf` values, scan workbooks/CSVs, private keys, archives, JDK binaries, generated documents, Git history, dependencies and unrelated business websites were not copied. `.conf.example` files generated from live `.conf` files contain assignment names only; every original value was removed. Auth example hashes/salts/passwords are placeholders and must be replaced with a newly generated valid configuration. Proprietary SQL scripts and data dumps were excluded.

## Safety and verification

All copied shell scripts are blocked by `exit 99`. The PowerShell runner and Ruby/Chef file also stop immediately. These blocks are intentional: deployment, stopping services, patching, backup cleanup and restore operations require explicit review and approval. Do not source shell modules without reviewing the block: sourcing an `exit` terminates the calling shell too.

Python parsing, JavaScript syntax and JSON parsing checks were performed; targeted private-data pattern scans were run. Bash syntax checks were attempted but Git Bash could not start in the sandbox (`couldn't create signal pipe`, Win32 error 5). That is an environment limitation, not a successful shell validation or proof of a script syntax error. Ruby/PowerShell runtime validation was not performed. No operational source was executed.

The templates are not turnkey. Restore configuration securely, validate source/target separation and dependent scripts, and test only with synthetic data before any authorized use. The original scripts may have pre-existing issues; sanitization is not a functionality/security audit.

Keep the GitHub repository private until an independent confidentiality review and employer permission are complete. Removing credentials does not grant permission to publish employer-owned code.
