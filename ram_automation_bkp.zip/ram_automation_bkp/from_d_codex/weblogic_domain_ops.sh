#!/usr/bin/env bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99


set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DOMAIN_NAME="${DOMAIN_NAME:-WEBLOGIC}"
DOMAIN_BIN="${DOMAIN_BIN:-}"
DOMAIN_HOME="${DOMAIN_HOME:-}"
WL_HOME="${WL_HOME:-/PATH_TO_CONFIGURE}"
NODEMANAGER_BIN="${NODEMANAGER_BIN:-${WL_HOME%/}/server/bin}"
ADMIN_SERVER="${ADMIN_SERVER:-AdminServer}"
ADMIN_URL="${ADMIN_URL:-t3://hostname:PORT}"
REMOTE_HOST="${REMOTE_HOST:-}"
REMOTE_USER="${REMOTE_USER:-${USER:-weblogic}}"
SSH_OPTS="${SSH_OPTS:-}"
EXECUTION_MODE="${EXECUTION_MODE:-auto}"
MANAGED_SERVERS_CSV="${MANAGED_SERVERS_CSV:-}"
DEPLOY_SCRIPT_DIR="${DEPLOY_SCRIPT_DIR:-${SCRIPT_DIR}}"
AUTOMATION_DIR="${AUTOMATION_DIR:-${SCRIPT_DIR}}"
START_STOP_HELPER="${START_STOP_HELPER:-}"
WLST_BIN="${WLST_BIN:-}"
START_STOP_SET_CWD="${START_STOP_SET_CWD:-${SCRIPT_DIR}}"
NODE_MANAGER_USER="${NODE_MANAGER_USER:-}"
NODE_MANAGER_PASSWORD="SECRET_REMOVED"
CLUSTER_NAME="${CLUSTER_NAME:-}"
PYTHON_BIN="${PYTHON_BIN:-python3}"

if [[ -z "${DOMAIN_BIN}" && -n "${DOMAIN_HOME}" ]]; then
  DOMAIN_BIN="${DOMAIN_HOME%/}/bin"
fi

if [[ -z "${DOMAIN_HOME}" && -n "${DOMAIN_BIN}" ]]; then
  DOMAIN_HOME="$(cd "${DOMAIN_BIN}/.." >/dev/null 2>&1 && pwd || dirname "${DOMAIN_BIN}")"
fi

trim() {
  local value="${1:-}"
  value="${value#"${value%%[![:space:]]*}"}"
  value="${value%"${value##*[![:space:]]}"}"
  printf '%s' "${value}"
}

shell_quote() {
  local value="${1:-}"
  value="${value//\'/\'\"\'\"\'}"
  printf "'%s'" "${value}"
}

build_path() {
  local root_dir="${1:-}"
  local file_name="${2:-}"
  if [[ -z "${file_name}" ]]; then
    printf '%s' ""
    return
  fi
  if [[ "${file_name}" == /* ]]; then
    printf '%s' "${file_name}"
    return
  fi
  printf '%s/%s' "${root_dir%/}" "${file_name}"
}

parse_managed_servers() {
  local raw="${1:-}"
  local item=""
  IFS=',' read -r -a raw_servers <<< "${raw}"
  MANAGED_SERVERS=()
  for item in "${raw_servers[@]}"; do
    item="$(trim "${item}")"
    if [[ -n "${item}" ]]; then
      MANAGED_SERVERS+=("${item}")
    fi
  done
}

should_run_local() {
  case "${EXECUTION_MODE}" in
    local) return 0 ;;
    ssh) return 1 ;;
  esac

  if [[ -z "${REMOTE_HOST}" ]]; then
    return 0
  fi

  case "${REMOTE_HOST}" in
    localhost|IP_ADDRESS|::1) return 0 ;;
  esac

  local short_host=""
  local fqdn_host=""
  local ip_addr=""
  short_host="$(hostname -s 2>/dev/null || true)"
  fqdn_host="$(hostname -f 2>/dev/null || true)"
  if [[ "${REMOTE_HOST}" == "${short_host}" || "${REMOTE_HOST}" == "${fqdn_host}" ]]; then
    return 0
  fi

  for ip_addr in $(hostname -I 2>/dev/null || true); do
    if [[ "${REMOTE_HOST}" == "${ip_addr}" ]]; then
      return 0
    fi
  done

  return 1
}

run_command() {
  local command="${1:?Provide command}"
  if should_run_local; then
    bash -lc "${command}"
  else
    local ssh_args=(
      -o BatchMode=yes
      -o ConnectTimeout=15
      -o ServerAliveInterval=15
      -o ServerAliveCountMax=2
    )
    local user_ssh_opts=()
    if [[ -n "${SSH_OPTS}" ]]; then
      read -r -a user_ssh_opts <<< "${SSH_OPTS}"
      ssh_args+=("${user_ssh_opts[@]}")
    fi
    ssh "${ssh_args[@]}" "${REMOTE_USER}@${REMOTE_HOST}" "${command}"
  fi
}

require_domain_bin() {
  if [[ -z "${DOMAIN_BIN}" ]]; then
    echo "DOMAIN_BIN is not set. Export DOMAIN_BIN or configure weblogic_ui_domains.json first." >&2
    exit 1
  fi
}

build_helper_command() {
  local action="${1:?Provide action}"
  local server_name="${2:-}"
  local cluster_name="${3:-}"
  local parts=()

  if [[ -z "${START_STOP_HELPER}" || -z "${WLST_BIN}" ]]; then
    return 1
  fi

  parts+=("\"${WLST_BIN}\"")
  parts+=("\"${START_STOP_HELPER}\"")
  parts+=("--set_cwd")
  parts+=("\"${START_STOP_SET_CWD}\"")
  parts+=("--action")
  parts+=("\"${action}\"")

  if [[ -n "${server_name}" ]]; then
    parts+=("--server_name")
    parts+=("\"${server_name}\"")
  fi

  if [[ -n "${cluster_name}" ]]; then
    parts+=("--cluster_name")
    parts+=("\"${cluster_name}\"")
  fi

  if [[ -n "${NODE_MANAGER_USER}" ]]; then
    parts+=("--node_manager_user")
    parts+=("\"${NODE_MANAGER_USER}\"")
  fi

  if [[ -n "${NODE_MANAGER_PASSWORD}" ]]; then
    parts+=("--node_manager_password")
    parts+=("\"${NODE_MANAGER_PASSWORD}\"")
  fi

  printf '%s' "${parts[*]}"
}

run_helper_action() {
  local action="${1:?Provide action}"
  local server_name="${2:-}"
  local cluster_name="${3:-}"
  local helper_command=""

  helper_command="$(build_helper_command "${action}" "${server_name}" "${cluster_name}")" || return 1
  run_command "${helper_command}"
}

run_local_deploy() {
  local deploy_script="${1:?Provide deploy script}"
  local deploy_path=""
  deploy_path="$(build_path "${DEPLOY_SCRIPT_DIR}" "${deploy_script}")"
  run_command "bash $(shell_quote "${deploy_path}")"
}

show_versions() {
  local deploy_script="${1:?Provide deploy script}"
  local deploy_path=""
  local helper_path=""
  deploy_path="$(build_path "${DEPLOY_SCRIPT_DIR}" "${deploy_script}")"
  helper_path="$(build_path "${AUTOMATION_DIR}" "weblogic_bump_version.py")"
  run_command "$(shell_quote "${PYTHON_BIN}") $(shell_quote "${helper_path}") $(shell_quote "${deploy_path}") --show"
}

update_version() {
  local deploy_script="${1:?Provide deploy script}"
  local new_version="${2:?Provide new version}"
  local deploy_path=""
  local helper_path=""
  deploy_path="$(build_path "${DEPLOY_SCRIPT_DIR}" "${deploy_script}")"
  helper_path="$(build_path "${AUTOMATION_DIR}" "weblogic_bump_version.py")"
  run_command "$(shell_quote "${PYTHON_BIN}") $(shell_quote "${helper_path}") $(shell_quote "${deploy_path}") $(shell_quote "${new_version}")"
}

build_undeploy() {
  local deploy_script="${1:?Provide deploy script}"
  local output_script="${2:?Provide output undeploy script}"
  local deploy_path=""
  local output_path=""
  local helper_path=""
  deploy_path="$(build_path "${DEPLOY_SCRIPT_DIR}" "${deploy_script}")"
  output_path="$(build_path "${DEPLOY_SCRIPT_DIR}" "${output_script}")"
  helper_path="$(build_path "${AUTOMATION_DIR}" "weblogic_undeploy_from_deploy.py")"
  run_command "$(shell_quote "${PYTHON_BIN}") $(shell_quote "${helper_path}") $(shell_quote "${deploy_path}") --write-script $(shell_quote "${output_path}")"
}

start_admin() {
  require_domain_bin
  run_command "\"${DOMAIN_BIN}/startWebLogic.sh\""
}

stop_admin() {
  require_domain_bin
  run_command "\"${DOMAIN_BIN}/stopWebLogic.sh\""
}

start_nodemanager() {
  run_command "\"${NODEMANAGER_BIN}/startNodeManager.sh\""
}

stop_nodemanager() {
  run_command "if [[ -x \"${NODEMANAGER_BIN}/stopNodeManager.sh\" ]]; then \"${NODEMANAGER_BIN}/stopNodeManager.sh\"; else pkill -f 'weblogic.NodeManager' || true; fi"
}

start_managed() {
  local server_name="${1:?Provide managed server name}"
  require_domain_bin
  if run_helper_action start "${server_name}"; then
    return
  fi
  run_command "\"${DOMAIN_BIN}/startManagedWebLogic.sh\" \"${server_name}\" \"${ADMIN_URL}\""
}

stop_managed() {
  local server_name="${1:?Provide managed server name}"
  require_domain_bin
  if run_helper_action stop "${server_name}"; then
    return
  fi
  run_command "\"${DOMAIN_BIN}/stopManagedWebLogic.sh\" \"${server_name}\" \"${ADMIN_URL}\""
}

start_all() {
  if [[ -n "${CLUSTER_NAME}" ]] && run_helper_action start "" "${CLUSTER_NAME}"; then
    return
  fi

  start_nodemanager
  sleep 10
  start_admin
  sleep 20

  for server_name in "${MANAGED_SERVERS[@]}"; do
    start_managed "${server_name}"
    sleep 5
  done
}

stop_all() {
  if [[ -n "${CLUSTER_NAME}" ]] && run_helper_action stop "" "${CLUSTER_NAME}"; then
    return
  fi

  for server_name in "${MANAGED_SERVERS[@]}"; do
    stop_managed "${server_name}"
  done
  stop_admin
  stop_nodemanager
}

usage() {
  cat <<'EOF'
Usage:
  ./domain_ops.sh start_admin
  ./domain_ops.sh stop_admin
  ./domain_ops.sh start_nodemanager
  ./domain_ops.sh stop_nodemanager
  ./domain_ops.sh start_managed <server_name>
  ./domain_ops.sh stop_managed <server_name>
  ./domain_ops.sh start_all
  ./domain_ops.sh stop_all
  ./domain_ops.sh deploy <deploy_script.sh>
  ./domain_ops.sh show_versions <deploy_script.sh>
  ./domain_ops.sh update_version <deploy_script.sh> <new_version>
  ./domain_ops.sh build_undeploy <deploy_script.sh> <output_undeploy.sh>

Environment overrides:
  DOMAIN_NAME, DOMAIN_BIN, DOMAIN_HOME, WL_HOME, NODEMANAGER_BIN
  ADMIN_SERVER, ADMIN_URL, REMOTE_HOST, REMOTE_USER, SSH_OPTS, EXECUTION_MODE
  MANAGED_SERVERS_CSV, DEPLOY_SCRIPT_DIR, AUTOMATION_DIR, PYTHON_BIN
  START_STOP_HELPER, WLST_BIN, START_STOP_SET_CWD
  NODE_MANAGER_USER, NODE_MANAGER_PASSWORD, CLUSTER_NAME
EOF
}

main() {
  local action="${1:-}"
  parse_managed_servers "${MANAGED_SERVERS_CSV}"

  case "${action}" in
    start_admin) start_admin ;;
    stop_admin) stop_admin ;;
    start_nodemanager) start_nodemanager ;;
    stop_nodemanager) stop_nodemanager ;;
    start_managed) start_managed "${2:?Provide managed server name}" ;;
    stop_managed) stop_managed "${2:?Provide managed server name}" ;;
    start_all) start_all ;;
    stop_all) stop_all ;;
    deploy) run_local_deploy "${2:?Provide deploy script}" ;;
    show_versions) show_versions "${2:?Provide deploy script}" ;;
    update_version) update_version "${2:?Provide deploy script}" "${3:?Provide new version}" ;;
    build_undeploy) build_undeploy "${2:?Provide deploy script}" "${3:?Provide output undeploy script}" ;;
    *) usage; exit 1 ;;
  esac
}

main "$@"
