#!/bin/bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99


set -u

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG_DIR="$SCRIPT_DIR/logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/java_upgrade_single_$(date +%Y%m%d_%H%M%S).log"

# Edit this line when you want to hardcode domain/config paths.
# Comma-separated paths. Example:
# DEFAULT_SEARCH_ROOTS="/PATH_TO_CONFIGURE,/PATH_TO_CONFIGURE"
DEFAULT_SEARCH_ROOTS=""

# Optional: persist new JAVA_HOME for future logins.
# Set UPDATE_USER_PROFILE="Y" if you want this script to update ~/.bash_profile.
# The script always creates set_java_home.sh in this folder.
UPDATE_USER_PROFILE="N"
PROFILE_FILE="$HOME/.bash_profile"

DRY_RUN="N"
SEARCH_ROOTS=""
INSTALL_PARENT=""
OLD_JAVA_HOME="${JAVA_HOME:-}"

usage() {
  cat <<EOF
Usage:
  ./java_auto_upgrade_single.sh [-s <search_roots>] [-d <install_parent>] [--dry-run]

This is a single-file Java upgrade script.

It will:
  1. Use current JAVA_HOME as old Java path.
  2. Find exactly one JDK archive in this same folder: .tar.gz, .tgz, or .zip.
  3. Extract the JDK to install parent.
  4. Auto-detect new JAVA_HOME from archive top folder.
  5. Replace old JAVA_HOME with new JAVA_HOME in config files under search roots.
  6. Backup each changed file.
  7. Create ./set_java_home.sh with new JAVA_HOME export commands.
  8. Optionally update PROFILE_FILE if UPDATE_USER_PROFILE="Y".
  9. Write logs in ./logs and print final status.

Defaults:
  install_parent = parent directory of current JAVA_HOME
  search_roots   = DEFAULT_SEARCH_ROOTS inside this script, if set
                   otherwise /PATH_TO_CONFIGURE\$USER/user_projects/domains,/PATH_TO_CONFIGURE\$USER

Example:
  export JAVA_HOME=/PATH_TO_CONFIGURE
  ./java_auto_upgrade_single.sh --dry-run
  ./java_auto_upgrade_single.sh

Custom roots:
  ./java_auto_upgrade_single.sh -s /PATH_TO_CONFIGURE,/PATH_TO_CONFIGURE,/PATH_TO_CONFIGURE
EOF
}

log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

die() {
  log "ERROR: $1"
  exit 1
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -s) SEARCH_ROOTS="${2:-}"; shift 2 ;;
    -d) INSTALL_PARENT="${2:-}"; shift 2 ;;
    --dry-run) DRY_RUN="Y"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
done

[[ -n "$OLD_JAVA_HOME" ]] || die "JAVA_HOME is not set. Run: export JAVA_HOME=<old_java_home>"
[[ -d "$OLD_JAVA_HOME" ]] || die "JAVA_HOME directory does not exist: $OLD_JAVA_HOME"

if [[ -z "$INSTALL_PARENT" ]]; then
  INSTALL_PARENT="$(dirname "$OLD_JAVA_HOME")"
fi
[[ -d "$INSTALL_PARENT" ]] || die "Install parent does not exist: $INSTALL_PARENT"

if [[ -z "$SEARCH_ROOTS" ]]; then
  if [[ -n "$DEFAULT_SEARCH_ROOTS" ]]; then
    SEARCH_ROOTS="$DEFAULT_SEARCH_ROOTS"
  else
    SEARCH_ROOTS="/PATH_TO_CONFIGURE$USER/user_projects/domains,/PATH_TO_CONFIGURE$USER"
  fi
fi

mapfile -t archives < <(find "$SCRIPT_DIR" -maxdepth 1 -type f \( -name "*.tar.gz" -o -name "*.tgz" -o -name "*.zip" \) | sort)
[[ "${#archives[@]}" -gt 0 ]] || die "No JDK archive found in $SCRIPT_DIR"
if [[ "${#archives[@]}" -gt 1 ]]; then
  log "Multiple JDK archives found. Keep only one archive in this folder:"
  printf '%s\n' "${archives[@]}" | tee -a "$LOG_FILE"
  exit 1
fi

JDK_ARCHIVE="${archives[0]}"

case "$JDK_ARCHIVE" in
  *.zip)
    command -v unzip >/dev/null 2>&1 || die "unzip command not found"
    NEW_TOP="$(unzip -Z1 "$JDK_ARCHIVE" | head -1 | cut -d/ -f1)"
    ;;
  *.tar.gz|*.tgz)
    NEW_TOP="$(tar -tzf "$JDK_ARCHIVE" | head -1 | cut -d/ -f1)"
    ;;
  *)
    die "Unsupported archive type: $JDK_ARCHIVE"
    ;;
esac

[[ -n "$NEW_TOP" ]] || die "Unable to detect top directory from archive"
NEW_JAVA_HOME="$INSTALL_PARENT/$NEW_TOP"

log "Starting Java single-file upgrade"
log "Script dir     : $SCRIPT_DIR"
log "Log file       : $LOG_FILE"
log "Archive        : $JDK_ARCHIVE"
log "Old JAVA_HOME  : $OLD_JAVA_HOME"
log "New JAVA_HOME  : $NEW_JAVA_HOME"
log "Install parent : $INSTALL_PARENT"
log "Search roots   : $SEARCH_ROOTS"
log "Dry run        : $DRY_RUN"

if [[ "$DRY_RUN" == "Y" ]]; then
  log "DRY RUN: archive extraction skipped"
else
  case "$JDK_ARCHIVE" in
    *.zip)
      log "Extracting zip archive"
      unzip -oq "$JDK_ARCHIVE" -d "$INSTALL_PARENT" >>"$LOG_FILE" 2>&1 || die "Archive extraction failed"
      ;;
    *.tar.gz|*.tgz)
      log "Extracting tar archive"
      tar -xzf "$JDK_ARCHIVE" -C "$INSTALL_PARENT" >>"$LOG_FILE" 2>&1 || die "Archive extraction failed"
      ;;
  esac

  [[ -x "$NEW_JAVA_HOME/bin/java" ]] || die "New Java not executable: $NEW_JAVA_HOME/bin/java"
  "$NEW_JAVA_HOME/bin/java" -version >>"$LOG_FILE" 2>&1
fi

IFS=',' read -r -a ROOT_ARRAY <<< "$SEARCH_ROOTS"
MATCHED_COUNT=0
UPDATED_COUNT=0
SKIPPED_COUNT=0

for root in "${ROOT_ARRAY[@]}"; do
  root="$(echo "$root" | xargs)"
  if [[ ! -d "$root" ]]; then
    log "Skipping missing root: $root"
    SKIPPED_COUNT=$((SKIPPED_COUNT + 1))
    continue
  fi

  log "Scanning root: $root"
  while IFS= read -r file; do
    case "$file" in
      "$SCRIPT_DIR"/*|*/inventory/*|*/oui/*|*/cfgtoollogs/*|*/.patch_storage/*|*/logs/*|*/tmp/*|*/cache/*|*.bak_*)
        log "Skipping protected/generated file: $file"
        continue
        ;;
    esac

    MATCHED_COUNT=$((MATCHED_COUNT + 1))
    log "Found old JAVA_HOME in: $file"

    if [[ "$DRY_RUN" == "Y" ]]; then
      continue
    fi

    backup="$file.bak_$(date +%Y%m%d_%H%M%S)"
    cp -p "$file" "$backup" || die "Backup failed: $file"
    perl -pi -e "s|\\Q$OLD_JAVA_HOME\\E|$NEW_JAVA_HOME|g" "$file" || die "Replacement failed: $file"
    UPDATED_COUNT=$((UPDATED_COUNT + 1))
  done < <(
    find "$root" -type f \
      \( -name "*.sh" -o -name "*.properties" -o -name "*.conf" -o -name "*.cfg" -o -name "*.xml" -o -name "*.txt" -o -name "*.profile" -o -name ".bash_profile" -o -name ".bashrc" \) \
      -exec grep -Il "$OLD_JAVA_HOME" {} \; 2>/dev/null
  )
done

log "Scan/update completed"
log "Files matched : $MATCHED_COUNT"
log "Files updated : $UPDATED_COUNT"
log "Roots skipped : $SKIPPED_COUNT"

if [[ "$DRY_RUN" != "Y" ]]; then
  log "Set current session manually using:"
  log "export JAVA_HOME=$NEW_JAVA_HOME"
  log "export PATH=\$JAVA_HOME/bi/PATH_TO_CONFIGURE"
  log "java -version"

  ENV_FILE="$SCRIPT_DIR/set_java_home.sh"
  cat > "$ENV_FILE" <<EOF
export JAVA_HOME=$NEW_JAVA_HOME
export PATH=\$JAVA_HOME/bi/PATH_TO_CONFIGURE
java -version
EOF
  chmod +x "$ENV_FILE"
  log "Created environment file: $ENV_FILE"

  if [[ "$UPDATE_USER_PROFILE" == "Y" ]]; then
    touch "$PROFILE_FILE" || die "Unable to write profile file: $PROFILE_FILE"
    cp -p "$PROFILE_FILE" "$PROFILE_FILE.bak_$(date +%Y%m%d_%H%M%S)" || die "Profile backup failed: $PROFILE_FILE"
    if grep -q "JAVA_HOME=" "$PROFILE_FILE"; then
      perl -pi -e "s|^export JAVA_HOME=.*|export JAVA_HOME=$NEW_JAVA_HOME|g; s|^JAVA_HOME=.*|export JAVA_HOME=$NEW_JAVA_HOME|g" "$PROFILE_FILE"
    else
      {
        echo ""
        echo "# Java auto upgrade - $(date '+%Y-%m-%d %H:%M:%S')"
        echo "export JAVA_HOME=$NEW_JAVA_HOME"
      } >> "$PROFILE_FILE"
    fi
    if ! grep -q 'JAVA_HOME/bin' "$PROFILE_FILE"; then
      echo 'export PATH=$JAVA_HOME/bin:$PATH' >> "$PROFILE_FILE"
    fi
    log "Updated user profile: $PROFILE_FILE"
  else
    log "Profile update disabled. To enable, set UPDATE_USER_PROFILE=\"Y\" inside script."
  fi

  export JAVA_HOME="$NEW_JAVA_HOME"
  export PATH="$JAVA_HOME/bin:$PATH"
  log "Runtime verification after upgrade:"
  log "JAVA_HOME=$JAVA_HOME"
  "$JAVA_HOME/bin/java" -version 2>&1 | tee -a "$LOG_FILE"
fi

echo
echo "===== FINAL STATUS ====="
echo "Log file      : $LOG_FILE"
echo "Archive       : $JDK_ARCHIVE"
echo "Old JAVA_HOME : $OLD_JAVA_HOME"
echo "New JAVA_HOME : $NEW_JAVA_HOME"
echo "Matched files : $MATCHED_COUNT"
echo "Updated files : $UPDATED_COUNT"
echo "Dry run       : $DRY_RUN"
if [[ "$DRY_RUN" != "Y" ]]; then
  echo "Env file      : $SCRIPT_DIR/set_java_home.sh"
  echo "Use now       : source $SCRIPT_DIR/set_java_home.sh"
  echo "Current JAVA_HOME shown by script:"
  echo "$JAVA_HOME"
  echo "Current java -version shown by script:"
  "$JAVA_HOME/bin/java" -version
fi
echo "========================"
