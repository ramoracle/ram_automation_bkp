#!/bin/bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99


set -u

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG_DIR="$SCRIPT_DIR/logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/java_upgrade_$(date +%Y%m%d_%H%M%S).log"

usage() {
  cat <<EOF
Usage:
  ./java_auto_upgrade.sh -z <jdk_zip_or_tar> -d <install_parent_dir> -o <old_java_home> -n <new_java_home> -s <search_roots> [--dry-run]

Example:
  ./java_auto_upgrade.sh \\
    -z /PATH_TO_CONFIGURE \\
    -d /PATH_TO_CONFIGURE \\
    -o /PATH_TO_CONFIGURE \\
    -n /PATH_TO_CONFIGURE \\
    -s /PATH_TO_CONFIGURE,/PATH_TO_CONFIGURE,/PATH_TO_CONFIGURE \\
    --dry-run

Then actual run:
  ./java_auto_upgrade.sh -z <zip/tar.gz> -d <install_parent> -o <old_java_home> -n <new_java_home> -s <roots>

Options:
  -z   New JDK archive path. Supports .zip, .tar.gz, .tgz
  -d   Parent directory where JDK should be extracted
  -o   Old JAVA_HOME path to replace in config files
  -n   New JAVA_HOME path to use after extraction
  -s   Comma-separated root directories to scan/update config files
  --dry-run  Show what would change, do not edit files
EOF
}

log() {
  local msg="$1"
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $msg" | tee -a "$LOG_FILE"
}

die() {
  log "ERROR: $1"
  exit 1
}

JDK_ARCHIVE=""
INSTALL_PARENT=""
OLD_JAVA_HOME=""
NEW_JAVA_HOME=""
SEARCH_ROOTS=""
DRY_RUN="N"

while [[ $# -gt 0 ]]; do
  case "$1" in
    -z) JDK_ARCHIVE="${2:-}"; shift 2 ;;
    -d) INSTALL_PARENT="${2:-}"; shift 2 ;;
    -o) OLD_JAVA_HOME="${2:-}"; shift 2 ;;
    -n) NEW_JAVA_HOME="${2:-}"; shift 2 ;;
    -s) SEARCH_ROOTS="${2:-}"; shift 2 ;;
    --dry-run) DRY_RUN="Y"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
done

[[ -n "$JDK_ARCHIVE" ]] || { usage; die "Missing -z <jdk_archive>"; }
[[ -n "$INSTALL_PARENT" ]] || { usage; die "Missing -d <install_parent_dir>"; }
[[ -n "$OLD_JAVA_HOME" ]] || { usage; die "Missing -o <old_java_home>"; }
[[ -n "$NEW_JAVA_HOME" ]] || { usage; die "Missing -n <new_java_home>"; }
[[ -n "$SEARCH_ROOTS" ]] || { usage; die "Missing -s <search_roots>"; }

[[ -f "$JDK_ARCHIVE" ]] || die "JDK archive not found: $JDK_ARCHIVE"
[[ -d "$INSTALL_PARENT" ]] || die "Install parent not found: $INSTALL_PARENT"

log "Starting Java auto upgrade"
log "Script directory : $SCRIPT_DIR"
log "Log file         : $LOG_FILE"
log "JDK archive      : $JDK_ARCHIVE"
log "Install parent   : $INSTALL_PARENT"
log "Old JAVA_HOME    : $OLD_JAVA_HOME"
log "New JAVA_HOME    : $NEW_JAVA_HOME"
log "Search roots     : $SEARCH_ROOTS"
log "Dry run          : $DRY_RUN"

if [[ "$DRY_RUN" != "Y" ]]; then
  case "$JDK_ARCHIVE" in
    *.zip)
      command -v unzip >/dev/null 2>&1 || die "unzip command not found"
      log "Extracting zip archive into $INSTALL_PARENT"
      unzip -oq "$JDK_ARCHIVE" -d "$INSTALL_PARENT" >>"$LOG_FILE" 2>&1 || die "JDK unzip failed"
      ;;
    *.tar.gz|*.tgz)
      log "Extracting tar archive into $INSTALL_PARENT"
      tar -xzf "$JDK_ARCHIVE" -C "$INSTALL_PARENT" >>"$LOG_FILE" 2>&1 || die "JDK tar extraction failed"
      ;;
    *)
      die "Unsupported archive type. Use .zip, .tar.gz, or .tgz"
      ;;
  esac
else
  log "DRY RUN: skipping archive extraction"
fi

[[ "$DRY_RUN" == "Y" || -x "$NEW_JAVA_HOME/bin/java" ]] || die "New java not executable: $NEW_JAVA_HOME/bin/java"

if [[ "$DRY_RUN" != "Y" ]]; then
  log "New Java version:"
  "$NEW_JAVA_HOME/bin/java" -version >>"$LOG_FILE" 2>&1
fi

IFS=',' read -r -a ROOT_ARRAY <<< "$SEARCH_ROOTS"
UPDATED_COUNT=0
MATCHED_COUNT=0
SKIPPED_COUNT=0

for root in "${ROOT_ARRAY[@]}"; do
  root="$(echo "$root" | xargs)"
  [[ -d "$root" ]] || {
    log "Skipping missing search root: $root"
    SKIPPED_COUNT=$((SKIPPED_COUNT + 1))
    continue
  }

  log "Scanning root: $root"
  while IFS= read -r file; do
    MATCHED_COUNT=$((MATCHED_COUNT + 1))
    log "Matched old JAVA_HOME in: $file"

    if [[ "$DRY_RUN" == "Y" ]]; then
      continue
    fi

    cp -p "$file" "$file.bak_$(date +%Y%m%d_%H%M%S)" || die "Backup failed for $file"
    perl -pi -e "s|\\Q$OLD_JAVA_HOME\\E|$NEW_JAVA_HOME|g" "$file" || die "Replacement failed for $file"
    UPDATED_COUNT=$((UPDATED_COUNT + 1))
  done < <(
    find "$root" -type f \
      \( -name "*.sh" -o -name "*.properties" -o -name "*.conf" -o -name "*.cfg" -o -name "*.xml" -o -name "*.txt" -o -name ".bash_profile" -o -name ".bashrc" \) \
      -exec grep -Il "$OLD_JAVA_HOME" {} \; 2>/dev/null
  )
done

log "Upgrade scan complete"
log "Files matched : $MATCHED_COUNT"
log "Files updated : $UPDATED_COUNT"
log "Roots skipped : $SKIPPED_COUNT"

if [[ "$DRY_RUN" == "Y" ]]; then
  log "DRY RUN completed. No files changed."
else
  log "Export for current session:"
  log "export JAVA_HOME=$NEW_JAVA_HOME"
  log "export PATH=\$JAVA_HOME/bi/PATH_TO_CONFIGURE"
  log "Post-check command:"
  log "ps -ef | grep java | grep -v grep"
fi

log "Completed Java auto upgrade"
echo
echo "===== FINAL STATUS ====="
echo "Log file      : $LOG_FILE"
echo "Matched files : $MATCHED_COUNT"
echo "Updated files : $UPDATED_COUNT"
echo "Dry run       : $DRY_RUN"
echo "New JAVA_HOME : $NEW_JAVA_HOME"
echo "========================"
