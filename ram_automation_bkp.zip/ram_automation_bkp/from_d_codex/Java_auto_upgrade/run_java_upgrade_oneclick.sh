#!/bin/bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99


set -u

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG_DIR="$SCRIPT_DIR/logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/oneclick_java_upgrade_$(date +%Y%m%d_%H%M%S).log"

DRY_RUN="N"
SEARCH_ROOTS=""
INSTALL_PARENT=""
OLD_JAVA_HOME="${JAVA_HOME:-}"
JDK_ARCHIVE=""

usage() {
  cat <<EOF
Usage:
  ./run_java_upgrade_oneclick.sh [-s <search_roots>] [-d <install_parent>] [--dry-run]

What it does:
  1. Uses current JAVA_HOME as old Java path.
  2. Finds one JDK archive in this folder: *.tar.gz, *.tgz, or *.zip.
  3. Extracts JDK into install parent.
  4. Auto-detects new JDK folder from archive top directory.
  5. Replaces old JAVA_HOME with new JAVA_HOME in config files under search roots.
  6. Writes logs in ./logs and prints final status.

Defaults:
  install_parent = parent directory of current JAVA_HOME
  search_roots   = /PATH_TO_CONFIGURE\$USER,/PATH_TO_CONFIGURE,/PATH_TO_CONFIGURE\$USER

Example:
  export JAVA_HOME=/PATH_TO_CONFIGURE
  ./run_java_upgrade_oneclick.sh --dry-run
  ./run_java_upgrade_oneclick.sh

Custom roots:
  ./run_java_upgrade_oneclick.sh -s /PATH_TO_CONFIGURE,/PATH_TO_CONFIGURE,/PATH_TO_CONFIGURE
EOF
}

log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

die() {
  log "ERROR: $1"
  exit 1
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -s) SEARCH_ROOTS="${2:-}"; shift 2 ;;
    -d) INSTALL_PARENT="${2:-}"; shift 2 ;;
    --dry-run) DRY_RUN="Y"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
done

[[ -n "$OLD_JAVA_HOME" ]] || die "JAVA_HOME is not set. Export old JAVA_HOME first."
[[ -d "$OLD_JAVA_HOME" ]] || die "Current JAVA_HOME directory not found: $OLD_JAVA_HOME"

if [[ -z "$INSTALL_PARENT" ]]; then
  INSTALL_PARENT="$(dirname "$OLD_JAVA_HOME")"
fi
[[ -d "$INSTALL_PARENT" ]] || die "Install parent not found: $INSTALL_PARENT"

if [[ -z "$SEARCH_ROOTS" ]]; then
  SEARCH_ROOTS="/PATH_TO_CONFIGURE$USER,/PATH_TO_CONFIGURE,/PATH_TO_CONFIGURE$USER"
fi

mapfile -t archives < <(find "$SCRIPT_DIR" -maxdepth 1 -type f \( -name "*.tar.gz" -o -name "*.tgz" -o -name "*.zip" \) | sort)
if [[ "${#archives[@]}" -eq 0 ]]; then
  die "No JDK archive found in $SCRIPT_DIR"
fi
if [[ "${#archives[@]}" -gt 1 ]]; then
  log "Multiple archives found:"
  printf '%s\n' "${archives[@]}" | tee -a "$LOG_FILE"
  die "Keep only one JDK archive in this folder, then rerun."
fi
JDK_ARCHIVE="${archives[0]}"

case "$JDK_ARCHIVE" in
  *.zip)
    command -v unzip >/dev/null 2>&1 || die "unzip not found"
    NEW_TOP="$(unzip -Z1 "$JDK_ARCHIVE" | head -1 | cut -d/ -f1)"
    ;;
  *.tar.gz|*.tgz)
    NEW_TOP="$(tar -tzf "$JDK_ARCHIVE" | head -1 | cut -d/ -f1)"
    ;;
  *)
    die "Unsupported archive type: $JDK_ARCHIVE"
    ;;
esac

[[ -n "$NEW_TOP" ]] || die "Unable to detect JDK top folder from archive"
NEW_JAVA_HOME="$INSTALL_PARENT/$NEW_TOP"

log "Starting one-click Java upgrade"
log "Script dir      : $SCRIPT_DIR"
log "Log file        : $LOG_FILE"
log "Archive         : $JDK_ARCHIVE"
log "Old JAVA_HOME   : $OLD_JAVA_HOME"
log "New JAVA_HOME   : $NEW_JAVA_HOME"
log "Install parent  : $INSTALL_PARENT"
log "Search roots    : $SEARCH_ROOTS"
log "Dry run         : $DRY_RUN"

if [[ "$DRY_RUN" == "Y" ]]; then
  log "DRY RUN: no files will be changed"
else
  chmod +x "$SCRIPT_DIR/java_auto_upgrade.sh" 2>/dev/null || true
fi

"$SCRIPT_DIR/java_auto_upgrade.sh" \
  -z "$JDK_ARCHIVE" \
  -d "$INSTALL_PARENT" \
  -o "$OLD_JAVA_HOME" \
  -n "$NEW_JAVA_HOME" \
  -s "$SEARCH_ROOTS" \
  $([[ "$DRY_RUN" == "Y" ]] && echo "--dry-run") | tee -a "$LOG_FILE"

RC=${PIPESTATUS[0]}
if [[ "$RC" -ne 0 ]]; then
  die "java_auto_upgrade.sh failed with exit code $RC"
fi

if [[ "$DRY_RUN" != "Y" ]]; then
  log "Checking new Java version"
  "$NEW_JAVA_HOME/bin/java" -version >>"$LOG_FILE" 2>&1 || die "New Java version check failed"
fi

log "One-click Java upgrade completed"
echo
echo "===== ONE-CLICK FINAL STATUS ====="
echo "Log file      : $LOG_FILE"
echo "Old JAVA_HOME : $OLD_JAVA_HOME"
echo "New JAVA_HOME : $NEW_JAVA_HOME"
echo "Dry run       : $DRY_RUN"
echo "Next command  : export JAVA_HOME=$NEW_JAVA_HOME; export PATH=\$JAVA_HOME/bi/PATH_TO_CONFIGURE"
echo "=================================="
