#!/usr/bin/env bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99


set -uo pipefail

SELF_NAME="$(basename "$0")"
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${BASE_DIR}/weblogic_menu.conf"
SCRIPT_ROOT="${BASE_DIR}"
LOG_DIR="${BASE_DIR}/logs"

if [[ -f "${CONFIG_FILE}" ]]; then
  # shellcheck disable=SC1090
  source "${CONFIG_FILE}"
fi

mkdir -p "${LOG_DIR}"

print_header() {
  clear
  echo "============================================================"
  echo "            WebLogic Linux Menu Runner"
  echo "============================================================"
  echo "Script root : ${SCRIPT_ROOT}"
  echo "Log folder  : ${LOG_DIR}"
  echo
}

pause() {
  echo
  read -r -p "Press Enter to continue..." _
}

normalize() {
  echo "$1" | tr '[:upper:]' '[:lower:]'
}

script_kind() {
  local path name lowered
  path="$1"
  name="$(basename "$path")"
  lowered="$(normalize "$path")"

  if [[ "$name" == "$SELF_NAME" ]]; then
    return 1
  fi

  if [[ "$lowered" == *"/logs/"* ]]; then
    return 1
  fi

  if [[ "$lowered" == *"undeploy"* ]]; then
    echo "undeploy"
    return 0
  fi

  if [[ "$lowered" == *"start"* && "$lowered" == *"all"* ]]; then
    echo "start_all"
    return 0
  fi

  if [[ "$lowered" == *"stop"* && "$lowered" == *"all"* ]]; then
    echo "stop_all"
    return 0
  fi

  if [[ "$lowered" == *"start"* && "$lowered" == *"node"* ]]; then
    echo "start_nodemanager"
    return 0
  fi

  if [[ "$lowered" == *"stop"* && "$lowered" == *"node"* ]]; then
    echo "stop_nodemanager"
    return 0
  fi

  if [[ "$lowered" == *"start"* && "$lowered" == *"managed"* ]]; then
    echo "start_managed"
    return 0
  fi

  if [[ "$lowered" == *"stop"* && "$lowered" == *"managed"* ]]; then
    echo "stop_managed"
    return 0
  fi

  if [[ "$lowered" == *"start"* && ( "$lowered" == *"admin"* || "$lowered" == *"weblogic"* ) ]]; then
    echo "start_admin"
    return 0
  fi

  if [[ "$lowered" == *"stop"* && ( "$lowered" == *"admin"* || "$lowered" == *"weblogic"* ) ]]; then
    echo "stop_admin"
    return 0
  fi

  if [[ "$lowered" == *"start"* ]]; then
    echo "start_misc"
    return 0
  fi

  if [[ "$lowered" == *"stop"* ]]; then
    echo "stop_misc"
    return 0
  fi

  echo "deploy"
  return 0
}

collect_scripts() {
  find "${SCRIPT_ROOT}" -type f -name "*.sh" | sort
}

list_category() {
  local wanted="$1"
  local item kind

  while IFS= read -r item; do
    kind="$(script_kind "$item")" || continue
    if [[ "$kind" == "$wanted" ]]; then
      echo "$item"
    fi
  done < <(collect_scripts)
}

list_all_with_kind() {
  local item kind

  while IFS= read -r item; do
    kind="$(script_kind "$item")" || continue
    printf "%-18s %s\n" "$kind" "$item"
  done < <(collect_scripts)
}

pick_script() {
  local category="$1"
  local title="$2"
  local selection count idx
  local -a scripts=()

  mapfile -t scripts < <(list_category "$category")
  count="${#scripts[@]}"

  if [[ "$count" -eq 0 ]]; then
    echo "No scripts found for category: ${category}"
    return 1
  fi

  echo "$title"
  echo "------------------------------------------------------------"
  for idx in "${!scripts[@]}"; do
    printf "%2d. %s\n" "$((idx + 1))" "$(basename "${scripts[$idx]}")"
    printf "    %s\n" "${scripts[$idx]}"
  done
  echo " 0. Cancel"
  echo
  read -r -p "Choose script number: " selection

  if [[ "$selection" == "0" ]]; then
    return 1
  fi

  if ! [[ "$selection" =~ ^[0-9]+$ ]] || (( selection < 1 || selection > count )); then
    echo "Invalid selection."
    return 1
  fi

  printf "%s\n" "${scripts[$((selection - 1))]}"
}

run_script() {
  local script_path="$1"
  local script_name timestamp log_file extra_args
  script_name="$(basename "$script_path")"
  timestamp="$(date +%Y%m%d_%H%M%S)"
  log_file="${LOG_DIR}/${script_name%.sh}_${timestamp}.log"

  echo
  echo "Selected script: ${script_path}"
  read -r -p "Enter optional arguments for this script (or press Enter): " extra_args
  echo
  echo "Running..."
  echo "Log file: ${log_file}"
  echo

  (
    cd "$(dirname "$script_path")" || exit 1
    if [[ -n "$extra_args" ]]; then
      bash "$script_path" $extra_args
    else
      bash "$script_path"
    fi
  ) 2>&1 | tee "$log_file"

  echo
  echo "Finished. Output saved to ${log_file}"
}

show_script() {
  local script_path="$1"
  print_header
  echo "Viewing: ${script_path}"
  echo "------------------------------------------------------------"
  sed -n '1,240p' "$script_path"
}

show_summary() {
  local category
  print_header
  echo "Detected scripts"
  echo "------------------------------------------------------------"
  list_all_with_kind
  echo
  for category in deploy undeploy start_admin stop_admin start_nodemanager stop_nodemanager start_managed stop_managed start_all stop_all start_misc stop_misc; do
    printf "%-18s %s\n" "$category" "$(list_category "$category" | wc -l | awk '{print $1}')"
  done
}

run_category() {
  local category="$1"
  local title="$2"
  local script_path

  print_header
  script_path="$(pick_script "$category" "$title")" || {
    pause
    return
  }
  run_script "$script_path"
  pause
}

pick_any_script() {
  local selection count idx
  local -a scripts=()

  mapfile -t scripts < <(collect_scripts)
  count="${#scripts[@]}"
  if [[ "$count" -eq 0 ]]; then
    echo "No .sh scripts found under ${SCRIPT_ROOT}" >&2
    return 1
  fi

  echo "Scripts"
  echo "------------------------------------------------------------"
  for idx in "${!scripts[@]}"; do
    printf "%2d. [%s] %s\n" "$((idx + 1))" "$(script_kind "${scripts[$idx]}")" "${scripts[$idx]}"
  done
  echo " 0. Cancel"
  echo
  read -r -p "Choose script number: " selection

  if [[ "$selection" == "0" ]]; then
    return 1
  fi

  if ! [[ "$selection" =~ ^[0-9]+$ ]] || (( selection < 1 || selection > count )); then
    echo "Invalid selection." >&2
    return 1
  fi

  printf "%s\n" "${scripts[$((selection - 1))]}"
}

view_any_script() {
  local script_path
  print_header
  script_path="$(pick_any_script)" || {
    pause
    return
  }
  show_script "$script_path"
  pause
}

run_any_script() {
  local script_path
  print_header
  script_path="$(pick_any_script)" || {
    pause
    return
  }
  run_script "$script_path"
  pause
}

main_menu() {
  local choice

  while true; do
    print_header
    echo "1. Run deployment script"
    echo "2. Run undeployment script"
    echo "3. Start Admin Server"
    echo "4. Stop Admin Server"
    echo "5. Start Node Manager"
    echo "6. Stop Node Manager"
    echo "7. Start Managed Server"
    echo "8. Stop Managed Server"
    echo "9. Start All"
    echo "10. Stop All"
    echo "11. Run any script"
    echo "12. Show detected scripts summary"
    echo "13. View a script file"
    echo "0. Exit"
    echo
    read -r -p "Enter choice: " choice

    case "$choice" in
      1) run_category "deploy" "Deployment scripts" ;;
      2) run_category "undeploy" "Undeployment scripts" ;;
      3) run_category "start_admin" "Admin start scripts" ;;
      4) run_category "stop_admin" "Admin stop scripts" ;;
      5) run_category "start_nodemanager" "Node Manager start scripts" ;;
      6) run_category "stop_nodemanager" "Node Manager stop scripts" ;;
      7) run_category "start_managed" "Managed Server start scripts" ;;
      8) run_category "stop_managed" "Managed Server stop scripts" ;;
      9) run_category "start_all" "Start all scripts" ;;
      10) run_category "stop_all" "Stop all scripts" ;;
      11) run_any_script ;;
      12) show_summary; pause ;;
      13) view_any_script ;;
      0) exit 0 ;;
      *) echo "Invalid option."; pause ;;
    esac
  done
}

main_menu
