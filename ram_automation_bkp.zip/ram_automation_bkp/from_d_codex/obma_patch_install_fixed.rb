raise "Disabled publication template: configure and review before execution."
root = File.absolute_path(File.dirname(__FILE__))
prop_path = File.expand_path("..", root) + '/obma_patch_properties.rb'
load prop_path
name 'obma_middleware_setup'
description 'Oracle Middleware Infrastructure Setup and Product Installation'
 
default_attributes(
    obma_sysprep: {
			install_user: INSTALL_USER,
			install_group: INSTALL_GROUP,
			install_base_dir: INSTALL_BASE_DIR,
			user_root: USER_ROOT,
			group_root: GROUP_ROOT,
			user_creation: "true"
   	},
    obma_java_upgrade: {
        do_cleanup: DO_CLEANUP,
        install_user_home: INSTALL_USER_HOME,
        java_installer_source: JAVA_INSTALLER_SOURCE,
        java_installer_path: SOFTWARE_INSTALLER_HOME,
        java_installer_context_path: JAVA_INSTALLER_PATH,
        install_dir: JAVA_INSTALLATION_DIR,
        version_number: JAVA_VERSION,
        jdk_name: JDK_INSTALLER_VERSION,
        package_basename: JDK_INSTALLER_FILE,
        install_user: INSTALL_USER,
        install_group: INSTALL_GROUP,
        certs_dirname: CERTS_DIRNAME        
        },
  
     obma_zk_kafka_upgrade: {
       kafka_package_name: KAFKA_ZOOKEEPER_INSTALLER_FILE,
       kafka_version: KAFKA_VERSION,
       kafka_scala_version: KAFKA_SCALA_VERSION,
       install_dir: KAFKA_INSTALL_DIR,    
       install_user: INSTALL_USER,
       user_home: KAFKA_INSTALL_USER_HOME,
       install_group: INSTALL_GROUP,
       kafka_installer_path: KAFKA_INSTALLER_PATH,
       zookeeper_install_path: ZOOKEEPER_INSTALL_PATH,
       kafka_install_path: KAFKA_INSTALL_PATH,
      machine_config: {
          server1: {
          hostname: ZOOKEEPER_HOST1,
          id: 1
            },
          server2: {
          hostname: ZOOKEEPER_HOST2,
          id: 2
            },
          server3: {
          hostname: ZOOKEEPER_HOST3,
          id: 3
            }
        },
       machine_config_topic: {
         hostname1: ZOOKEEPER_HOST1,
         hostname2: ZOOKEEPER_HOST2,
         hostname3: ZOOKEEPER_HOST3,
       },
       peerPort1: PEER_PORT1,
       leaderPort1: LEADER_PORT1,
       clientPort1: CLIENT_PORT1,
       peerPort2: PEER_PORT2,
       leaderPort2: LEADER_PORT2,
       clientPort2: CLIENT_PORT2,
       peerPort3: PEER_PORT3,
       leaderPort3: LEADER_PORT3,
       clientPort3: CLIENT_PORT3,
       kafka_certs_dirname: KAFKA_CERTS_DIRNAME,
       kafka_host1: KAFKA_HOST,
       kafka_host2: KAFKA_HOST,
       kafka_host3: KAFKA_HOST,
       kafka_port1: KAFKA_SSL_PORT1,
       kafka_port2: KAFKA_SSL_PORT2,
       kafka_port3: KAFKA_SSL_PORT3,
       jmx_port1: JMX_PORT1,
       jmx_port2: JMX_PORT2,
       jmx_port3: JMX_PORT3,
       kafka_broker_admin: KAFKA_BROKER_ADMIN,
       kafka_client_auth: KAFKA_CLIENT_AUTH,
       is_zookeeper_installed_on_diff_vm: Is_ZOOKEEPER_INSTALLED_ON_DIFF_VM,
       log: {
         retention_hours: LOG_RETENTION_HOURS,
         retention_check_interval: LOG_RETENTION_CHECK_INTERVAL,
         segment_bytes: LOG_SEGMENT_BYTES,
         retention_bytes: LOG_RETENTION_BYTES
          },
       topics: {
        topic1: {
         topic_name: "sweep-error",
         replication_factor: "3",
         partitions: "0",
         config: {
         "segment.bytes": "NUMBER_TO_CONFIGURE",
         "retention.ms": "604800000"
         }
         },
        },
    broker0: {
        id: KAFKA_BROKER_ID_0,
        listenerPort: KAFKA_SSL_PORT1
        },
    broker1: {
          id: KAFKA_BROKER_ID_1,
          listenerPort: KAFKA_SSL_PORT2
        },
    broker2: {
          id: KAFKA_BROKER_ID_2,
          listenerPort: KAFKA_SSL_PORT3
      }
     },
    obma_sqlcl: {
        do_cleanup: DO_CLEANUP,
        sqlcl_jar_name: SQLCL_JAR_NAME,
        sqlcl_jar_location: SQLCL_JAR_LOCATION,
        sqlcl_zip_location: SQLCL_ZIP_LOCATION,
        sqlcl_json_location: SQLCL_JSON_LOCATION,
        sqlcl_temp_dir: SQLCL_TEMP_DIR,
        sqlcl_export_sh_source_path: SQLCL_EXPORT_SH_SOURCE_PATH,
        sqlcl_export_sh_template_path: SQLCL_EXPORT_SH_TEMPLATE_PATH,
        plato_security_toolkit_jar_name: PLATO_SECURITY_TOOLKIT_JAR_NAME,
        plato_security_salt_encryption_toolkit_jar_name: PLATO_SECURITY_SALT_ENCRYPTION_TOOLKIT_JAR_NAME,
        dbpassword_datastore: DBPASSWORD_DATASOURCE
    },
       obma_patchset: {
        do_cleanup: DO_CLEANUP,
        inventory_loc: ORACLE_INVENTORY,
        install_user: INSTALL_USER,
        install_group: INSTALL_GROUP,
        user_home: INSTALL_BASE_DIR,
        extract_loc: EXTRACT_LOC,
        java_home: JAVA_HOME,
        certs_dirname: CERTS_DIRNAME,
        custom_identity_jks: CUSTOM_IDENTITY_JKS,
        custom_trust_jks: CUSTOM_TRUST_JKS,
        custom_trust_crt: CUSTOM_TRUST_CRT,
        keystoretype: KEYSTORETYPE,
        wls_install_dir: WLS_INSTALL_DIR,
        wls_patch_pkg_dirname_url: SOFTWARE_INSTALLER_HOME+WLS_PATCH_INSTALLER_PATH,
        wls_patch_package_basename: WLS_PATCH_PACKAGE_BASENAME,
        wls_patch_installer_file: WLS_PATCH_INSTALLER_FILE,
        domain_path: DOMAIN_PATH,    
        domain_name: WLS_DOMAIN_NAME,
        listen_port: WEBLOGIC_ADMIN_LISTEN_PORT,
        ssl_port: WEBLOGIC_ADMIN_SSL_PORT,
        plato_config_services_uri: PLATO_CONFIG_SERVICES_URI,
        plato_config_services_port: PLATO_CONFIG_SERVICES_PORT,
        plato_service_logging_path: APPLICATION_LOGGING_PATH,
        cluster_configure: CONFIGURE_WLS_CLUSTER,
        is_node_primary: "true",
        cluster_config: {
            plato_config_cluster: {    
        	managed_servers: {
		    Config_Server1: {
        	   	listen_port: PLATO_CONFIG_SVCS_MAN_SERVER_LISTEN_PORT,
                    	ssl_port: PLATO_CONFIG_SVCS_MAN_SERVER_SSL_PORT,
                    	java_memory_min: "256",
                    	java_memory_max: "512",
                        perm_size: "512"
                    }
		}
            },   
            plato_discovery_cluster: { 
		managed_servers: {
                    Discovery_Server1: {
                    	listen_port: PLATO_DISCOVERY_SVCS_MAN_SERVER_LISTEN_PORT,
                    	ssl_port: PLATO_DISCOVERY_SVCS_MAN_SERVER_SSL_PORT,
                    	java_memory_min: "2048",
                    	java_memory_max: "2048",
                        perm_size: "512"
                    }
		}
            },
	    coherence_cluster: {    
        	managed_servers: {
		    Coherence_Server1: {
        	   	listen_port: COHERENCE_MAN_SERVER_LISTEN_PORT,
                    	ssl_port: COHERENCE_MAN_SERVER_SSL_PORT,
                    	java_memory_min: "256",
                    	java_memory_max: "256",
                        perm_size: "512"
                    }
		}
            },
            plato_api_gateway_cluster: { 
		managed_servers: {
                   API_Gateway_Server1: {
                    	listen_port: PLATO_API_GATEWAY_MAN_SERVER_LISTEN_PORT,
                    	ssl_port: PLATO_API_GATEWAY_MAN_SERVER_SSL_PORT,
                    	java_memory_min: "512",
                    	java_memory_max: "512",
                        perm_size: "512"
                    }
		}
            },
            plato_ui_config_cluster: {
		managed_servers: {
                   Plato_UI_Config_Server1: {
                    	listen_port: PLATO_UI_MAN_SERVER_LISTEN_PORT,
                    	ssl_port: PLATO_UI_MAN_SERVER_SSL_PORT,
                    	java_memory_min: "256",
                    	java_memory_max: "256",
                        perm_size: "512"
		   }
                }
            },
            plato_o_cluster: {
		managed_servers: {
                   Plato_O_Server1: {
                    	listen_port: PLATO_O_MAN_SERVER_LISTEN_PORT,
                    	ssl_port: PLATO_O_MAN_SERVER_SSL_PORT,
                    	java_memory_min: "2048",
                    	java_memory_max: "2048",
                        perm_size: "2048"
		   }
                }
            },	
            plato_orch_cluster: {
		managed_servers: {
                   Plato_Orch_Server1: {
                    	listen_port: PLATO_ORCH_MAN_SERVER_LISTEN_PORT,
                    	ssl_port: PLATO_ORCH_MAN_SERVER_SSL_PORT,
                    	java_memory_min: "2048",
                    	java_memory_max: "2048",
                        perm_size: "2048"
		   }
                }
            },  
            plato_others_cluster: {
		managed_servers: {
                   Plato_Others_Server1: {
                    	listen_port: PLATO_OTHERS_MAN_SERVER_LISTEN_PORT,
                    	ssl_port: PLATO_OTHERS_MAN_SERVER_SSL_PORT,
                    	java_memory_min: "1024",
                    	java_memory_max: "2048",
                        perm_size: "2048"
		   }
                }
            }, 
            sms_cluster: {
		managed_servers: {
                   SMS_Server1: {
                    	listen_port: SMS_MAN_SERVER_LISTEN_PORT,
                    	ssl_port: SMS_MAN_SERVER_SSL_PORT,
                    	java_memory_min: "256",
                    	java_memory_max: "512",
                        perm_size: "512"
		   }
                }
            },	
            cmc_cluster1: {
		managed_servers: {
                   CMC_Server1: {
                    	listen_port: COMMON_CORE1_MAN_SERVER_LISTEN_PORT,
                    	ssl_port: COMMON_CORE1_MAN_SERVER_SSL_PORT,
                    	java_memory_min: "2048",
                    	java_memory_max: "3072",
                        perm_size: "2048"
		 }	
			 }
		  },
           cmc_cluster2: {
	   managed_servers: {		   
                   CMC_Server2: {
                    	listen_port: COMMON_CORE2_MAN_SERVER_LISTEN_PORT,
                    	ssl_port: COMMON_CORE2_MAN_SERVER_SSL_PORT,
                    	java_memory_min: "2048",
                    	java_memory_max: "3072",
                        perm_size: "2048"
		 }	
			 }
		  },
           cmc_cluster3: {
	   managed_servers: {
                   CMC_Server3: {
                    	listen_port: COMMON_CORE3_MAN_SERVER_LISTEN_PORT,
                    	ssl_port: COMMON_CORE3_MAN_SERVER_SSL_PORT,
                    	java_memory_min: "2048",
                    	java_memory_max: "3072",
                        perm_size: "2048"
		 }	
			 }
		  },
           cmc_cluster4: {
	   managed_servers: {
                   CMC_Server4: {
                    	listen_port: COMMON_CORE4_MAN_SERVER_LISTEN_PORT,
                    	ssl_port: COMMON_CORE4_MAN_SERVER_SSL_PORT,
                    	java_memory_min: "2048",
                    	java_memory_max: "3072",
                        perm_size: "2048"
		 }	
			 }
		  },
           moc_cluster: {
	   managed_servers: {
                   MOC_Server1: {
                    	listen_port: MID_OFFICE_CORE_MAN_SERVER_LISTEN_PORT,
                    	ssl_port: MID_OFFICE_CORE_MAN_SERVER_SSL_PORT,
                    	java_memory_min: "2048",
                    	java_memory_max: "3072",
                        perm_size: "2048"
		   }
                }
            },
          obpy_cluster: {    
        	managed_servers: {
		    OBPY_Server1: {
        	   	listen_port: OBPY_MAN_SERVER_LISTEN_PORT,
                    	ssl_port: OBPY_MAN_SERVER_SSL_PORT,
                    	java_memory_min: "2048",
                    	java_memory_max: "3072",
                        perm_size: "2048"
                    }
		}
            },
	    pmu_cluster: {    
        	managed_servers: {
		    PMU_Server1: {
        	   	listen_port: PMU_MAN_SERVER_LISTEN_PORT,
                    	ssl_port: PMU_MAN_SERVER_SSL_PORT,
                    	java_memory_min: "512",
                    	java_memory_max: "512",
                        perm_size: "512"
                    }
		}
            }
        },   
        datasource_configure: "false",
        datasource_config: {
    
        }, 
        sqlcl_config: {
            PLATO: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: PLATO_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: PLATO_SCHEMA,
                target: PLATO_DS_TARGET
               },
            PLATOAIF: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: PLATOAIF_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: PLATOAIF_SCHEMA,
                target: PLATOAIF_CONFIG_DS_TARGET
            },
            PLATOSEC: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: PLATOSEC_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: PLATOSEC_SCHEMA,
                target: PLATO_SECURITY_DS_TARGET 
             },
            PLATO_UI: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: PLATO_UI_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: PLATO_UI_SCHEMA,
                target: PLATO_UI_CONFIG_DS_TARGET
            },
            PLATOVALIDATION: {
				 database_name: ORACLE_PDB_SID,
				 driver_class: "oracle.jdbc.OracleDriver",
				 jndi_name: PLATOVALIDATION_JNDI,
				 host_name: ORACLE_PDB_HOSTNAME,
				 port: ORACLE_PDB_PORT,
				 global_transaction_protocol: "OnePhaseCommit",
				 database_user_name: PLATOVALIDATION_SCHEMA,
				 target: PLATOVALIDATION_DS_TARGET
			},

            PMU: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: PMU_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: PMU_SCHEMA,
                target: PMU_DS_TARGET
			},
            SMS: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: SMS_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: SMS_SCHEMA,
                target: SMS_DS_TARGET
            },
            CONDUCTOR: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: CONDUCTOR_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: CONDUCTOR_SCHEMA,
                target: CONDUCTOR_DS_TARGET
            },
            PLATOFEED: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: PLATO_FEED_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: PLATO_FEED_SCHEMA,
                target: PLATO_FEED_DS_TARGET
            },
            PLATOALERTS: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: PLATO_ALERTS_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: PLATO_ALERTS_SCHEMA,
                target: PLATO_ALERTS_DS_TARGET
            },
            PLATOBATCH: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: PLATO_BATCH_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: PLATO_BATCH_SCHEMA,
                target: PLATO_BATCH_DS_TARGET
            },
            PLATORULE: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: PLATO_RULE_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: PLATO_RULE_SCHEMA,
                target: PLATO_RULE_DS_TARGET
            },
            REPORTSERVICE: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: REPORT_SERVICE_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: REPORT_SERVICE_SCHEMA,
                target: REPORT_SERVICE_DS_TARGET
            },
            CMNCORE: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: COMMON_CORE_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: COMMON_CORE_SCHEMA,
                target: COMMON_CORE_DS_TARGET
            },
            PLATOTRANSPORT: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: PLATOTRANSPORT_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: PLATOTRANSPORT_SCHEMA,
                target: PLATOTRANSPORT_DS_TARGET
            },
            ############ NEW ADDED ##############
            PLATOEDP: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: PLATOEDP_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: PLATOEDP_SCHEMA,
                target: PLATOEDP_DS_TARGET
            },
            PARTY: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: PARTY_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: PARTY_SCHEMA,
                target: PARTY_DS_TARGET
            },
            OBPYBPROC: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: OBPYBPROC_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: OBPYBPROC_SCHEMA,
                target: OBPYBPROC_DS_TARGET
            },
            PLATO_PASSWORD: {
               database_name: ORACLE_PDB_SID,
               driver_class: "oracle.jdbc.OracleDriver",
               jndi_name: PLATO_PASSWORD_JNDI,
               host_name: ORACLE_PDB_HOSTNAME,
               port: ORACLE_PDB_PORT,
               global_transaction_protocol: "OnePhaseCommit",
               database_user_name: PLATO_PASSWORD_SCHEMA,
               target: PLATO_PASSWORD_DS_TARGET
           },
           OBRC: {
              database_name: ORACLE_PDB_SID,
              driver_class: "oracle.jdbc.OracleDriver",
              jndi_name: OBRC_JNDI,
              host_name: ORACLE_PDB_HOSTNAME,
              port: ORACLE_PDB_PORT,
              global_transaction_protocol: "OnePhaseCommit",
              database_user_name: OBRC_SCHEMA,
              target: OBRC_DS_TARGET
           },
       PLATOFDT: {
            database_name: ORACLE_PDB_SID,
            driver_class: "oracle.jdbc.OracleDriver",
            jndi_name: PLATOFDT_JNDI,
            host_name: ORACLE_PDB_HOSTNAME,
            port: ORACLE_PDB_PORT,
            global_transaction_protocol: "OnePhaseCommit",
            database_user_name: PLATOFDT_SCHEMA,
			target: PLATOFDT_DS_TARGET
            },
       PLATOARCH: {
            database_name: ORACLE_PDB_SID,
            driver_class: "oracle.jdbc.OracleDriver",
            jndi_name: PLATOARCH_JNDI,
            host_name: ORACLE_PDB_HOSTNAME,
            port: ORACLE_PDB_PORT,
            global_transaction_protocol: "OnePhaseCommit",
            database_user_name: PLATOARCH_SCHEMA,
        target: PLATOARCH_DS_TARGET
             },
            DOMAINARCH: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: DOMAINARCH_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: DOMAINARCH_SCHEMA,
                target: DOMAINARCH_DS_TARGET
            },
            DOMAINPURGE: {
                database_name: ORACLE_PDB_SID,
                driver_class: "oracle.jdbc.OracleDriver",
                jndi_name: DOMAINPURGE_JNDI,
                host_name: ORACLE_PDB_HOSTNAME,
                port: ORACLE_PDB_PORT,
                global_transaction_protocol: "OnePhaseCommit",
                database_user_name: DOMAINPURGE_SCHEMA,
                target: DOMAINPURGE_DS_TARGET
            },
       PLATODYNADATA: {
        database_name: ORACLE_PDB_SID,
            driver_class: "oracle.jdbc.OracleDriver",
            jndi_name: PLATODYNADATA_JNDI,
            host_name: ORACLE_PDB_HOSTNAME,
            port: ORACLE_PDB_PORT,
            global_transaction_protocol: "OnePhaseCommit",
            database_user_name: PLATODYNADATA_SCHEMA,
        target: PLATODYNADATA_DS_TARGET
            }
        },   
      app_installer_path: "filesystem",    
        app_dirname_url: PRODUCT_BUNDLE_HOME,
        app_undeployment: {
            app1: {
                app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
                   app_file_name: "plato-config-service-10.2.0.war",
                   app_target_name: "plato_config_cluster"
            },        
            app2: {
                app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
                   app_file_name: "plato-discovery-service-10.2.0.war",
                   app_target_name: "plato_discovery_cluster"
             },
            app171: {    
              app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
                app_file_name: "plato-coherence-server-10.2.0.war",
              app_target_name: "coherence_cluster"
                    },
            app3: {
                app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
                app_file_name: "plato-api-gateway-10.2.0.war",
                app_target_name: "plato_api_gateway_cluster"
            },
            app4: {
                app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
                app_file_name: "plato-ui-config-services-10.2.0.war",
                app_target_name: "plato_ui_config_cluster"
            },
            app5: {
                app_file_path: "/obma_patch_installer/deployables/apps/conductor",
                app_file_name: "conductor-server-v3.15.0.war",
                app_target_name: "plato_o_cluster"
            },
            app6: {
                app_file_path: "/obma_patch_installer/deployables/apps/sms",
                app_file_name: "sms-core-services-10.2.0.war",
                app_target_name: "sms_cluster"
            },
            app193: {
              app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
                app_file_name: "plato-archival-services-10.2.0.war",
                app_target_name: "plato_others_cluster"
            },
            app7: {
                app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
                app_file_name: "plato-orch-service-10.2.0.war",
                app_target_name: "plato_orch_cluster"
            },
            app8: {
               app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
                app_file_name: "plato-alerts-management-services-10.2.0.war",
               app_target_name: "plato_others_cluster"
            },
            app9: {
                app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
                app_file_name: "plato-feed-services-10.2.0.war",
                app_target_name: "plato_others_cluster"
            },
            app10: {
               app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
                app_file_name: "plato-rule-service-10.2.0.war",
               app_target_name: "plato_others_cluster"
            },
            app11: {
                app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
                app_file_name: "plato-report-services-10.2.0.war",
                app_target_name: "plato_others_cluster"
            },
            app12: {
                app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
              app_file_name: "plato-batch-server-10.2.0.war",
                app_target_name: "plato_others_cluster"
            },
            app13: {
                app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
                app_file_name: "plato-transport-services-10.2.0.war",
                app_target_name: "plato_others_cluster"
            },            
            app91: {
                app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
                app_file_name: "plato-dynamic-data-services-10.2.0.war",
                app_target_name: "plato_others_cluster"
            },
            app92: {
              app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
                app_file_name: "plato-fast-data-transfer-service-10.2.0.war",
              app_target_name: "plato_others_cluster"
            },
            app80: {
              app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
                    app_file_name: "plato-ref-app-10.2.0.war",
              app_target_name: "plato_others_cluster"
            },
            app14: {
              app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
              app_file_name: "plato-api-hub-10.2.0.war",
              app_target_name: "plato_others_cluster"
            },
            app16: {
              app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
              app_file_name: "plato-regional-configurator-services-10.2.0.war",
              app_target_name: "plato_others_cluster"
            },            
            app82: {
              app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
              app_file_name: "plato-password-policy-service-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },            
            app83: {
               app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
               app_file_name: "plato-edp-services-10.2.0.war",
              app_target_name: "plato_others_cluster"
            },
            app18: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-resource-segment-orchestrator-service-10.2.0.war",
              app_target_name: "cmc_cluster1"
            },
            app19: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-datasegment-services-10.2.0.war",
               app_target_name: "cmc_cluster1"
             },           
            app20: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-additional-attributes-services-10.2.0.war",
               app_target_name: "cmc_cluster1"
             },            
            app21: {
               app_file_path: "/obma_patch_installer/deployables/apps/moc",
               app_file_name: "cmc-sequencegenerator-services-10.2.0.war",
               app_target_name: "moc_cluster"
             },            
            app22: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-batch-services-10.2.0.war",
               app_target_name: "cmc_cluster1"
             },            
            app23: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-mis-services-10.2.0.war",
               app_target_name: "cmc_cluster4"
             },            
            # app24: { 
               app_file_path: "/obma_patch_installer/deployables/apps/moc",
               app_file_name: "cmc-corebanking-adapter-service-10.2.0.war",
               app_target_name: "cmc_cluster3"
             },            
            app25: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-external-virtual-account-services-10.2.0.war",
               app_target_name: "cmc_cluster4"
             },            
            app26: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-obrh-kafka-consumer-10.2.0.war",
               app_target_name: "cmc_cluster1"
             },            
            app27: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-screenclass-services-10.2.0.war",
               app_target_name: "cmc_cluster2"
             },            
            app28: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-charges-calculation-services-10.2.0.war",
               app_target_name: "cmc_cluster2"
             },            
            app29: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-transactioncontroller-services-10.2.0.war",
               app_target_name: "cmc_cluster2"
             },            
            app30: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-account-services-10.2.0.war",
               app_target_name: "cmc_cluster2"
             },            
            app31: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-base-services-10.2.0.war",
              app_target_name: "cmc_cluster2"
            },
            app32: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-branch-services-10.2.0.war",
              app_target_name: "cmc_cluster2"
            },
            app33: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-currency-services-10.2.0.war",
              app_target_name: "cmc_cluster2"
            },
            app34: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-customer-services-10.2.0.war",
               app_target_name: "cmc_cluster2"
             },            
            app35: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-external-chart-account-10.2.0.war",
               app_target_name: "cmc_cluster3"
             },            
            app36: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-external-system-services-10.2.0.war",
               app_target_name: "cmc_cluster3"
             },            
            app37: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-report-services-10.2.0.war",
              app_target_name: "cmc_cluster3"
            },
            app38: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-resourceclass-services-10.2.0.war",
               app_target_name: "cmc_cluster1"
             },            
            app39: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-settlements-services-10.2.0.war",
               app_target_name: "cmc_cluster3"
             },            
            app40: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-txn-code-services-10.2.0.war",
               app_target_name: "cmc_cluster3"
             },            
            app41: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-businessoverrides-services-10.2.0.war",
               app_target_name: "cmc_cluster4"
             },            
            app42: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-advice-services-10.2.0.war",
               app_target_name: "cmc_cluster4"
            },
            app50: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-facilities-service-10.2.0.war",
              app_target_name: "cmc_cluster4"
            },
            app64: {
              app_file_path: "/obma_patch_installer/deployables/apps/moc",
              app_file_name: "cmc-service-deprecation-svc-10.2.0.war",
              app_target_name: "moc_cluster"
            },
            app44: {
               app_file_path: "/obma_patch_installer/deployables/apps/moc",
               app_file_name: "cmc-sla-services-10.2.0.war",
               app_target_name: "moc_cluster"
             },
            app45: {
               app_file_path: "/obma_patch_installer/deployables/apps/moc",
               app_file_name: "cmc-processcode-service-10.2.0.war",
               app_target_name: "moc_cluster"
             },            
            app46: {
               app_file_path: "/obma_patch_installer/deployables/apps/moc",
               app_file_name: "cmc-checklist-services-10.2.0.war",
               app_target_name: "moc_cluster"
             },          
            app47: {
               app_file_path: "/obma_patch_installer/deployables/apps/moc",
               app_file_name: "cmc-checklistmanagement-services-10.2.0.war",
               app_target_name: "moc_cluster"
             },                
            app48: {
              app_file_path: "/obma_patch_installer/deployables/apps/moc",
              app_file_name: "cmc-applicationcategory-services-10.2.0.war",
              app_target_name: "moc_cluster"
            },            
            app49: {
              app_file_path: "/obma_patch_installer/deployables/apps/moc",
              app_file_name: "cmc-comments-services-10.2.0.war",
              app_target_name: "moc_cluster"
            },            
            app50: {
              app_file_path: "/obma_patch_installer/deployables/apps/moc",
              app_file_name: "cmc-document-services-10.2.0.war",
              app_target_name: "moc_cluster"
            },        
            app51: {
              app_file_path: "/obma_patch_installer/deployables/apps/moc",
              app_file_name: "cmc-documentmanagement-services-10.2.0.war",
              app_target_name: "moc_cluster"
            },        
            app52: {
              app_file_path: "/obma_patch_installer/deployables/apps/moc",
              app_file_name: "cmc-mailnotification-services-10.2.0.war",
              app_target_name: "moc_cluster"
            },        
            app53: {
              app_file_path: "/obma_patch_installer/deployables/apps/moc",
              app_file_name: "cmc-priority-service-10.2.0.war",
              app_target_name: "moc_cluster"
            },        
            app54: { 
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-external-deposit-account-services-10.2.0.war",
              app_target_name: "cmc_cluster3"
            },        
           ap55: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-obrh-service-10.2.0.war",
              app_target_name: "cmc_cluster1"
            },
           app56: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-interest-rate-services-10.2.0.war",
              app_target_name: "cmc_cluster1"
            },        
            app100: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-opds-services-10.2.0.war",
              app_target_name: "cmc_cluster4"
            },        
            app655: {
                app_file_path: "/obma_patch_installer/deployables/apps/obpy",
                   app_file_name: "obpy-party-maintenance-service-10.2.0.war",
                   app_target_name: "obpy_cluster"
            },
            app66: {
                app_file_path: "/obma_patch_installer/deployables/apps/obpy",
                   app_file_name: "obpy-stage-services-10.2.0.war",
                   app_target_name: "obpy_cluster"
            },
            app67: {
                app_file_path: "/obma_patch_installer/deployables/apps/obpy",
                app_file_name: "obpy-party-services-10.2.0.war",
                app_target_name: "obpy_cluster"
            },
            app68: {
                app_file_path: "/obma_patch_installer/deployables/apps/obpy",
                app_file_name: "obpy-party-kyc-services-10.2.0.war",
                app_target_name: "obpy_cluster"
            },
            app69: {
                app_file_path: "/obma_patch_installer/deployables/apps/obpy",
                app_file_name: "obpy-businessprocess-services-10.2.0.war",
                app_target_name: "obpy_cluster"
            },
            app70: {
                app_file_path: "/obma_patch_installer/deployables/apps/obpy",
                app_file_name: "obpy-party-handoff-services-10.2.0.war",
                app_target_name: "obpy_cluster"
            },
            app71: {
                app_file_path: "/obma_patch_installer/deployables/apps/obpy",
                app_file_name: "obpy-party-publisher-services-10.2.0.war",
                app_target_name: "obpy_cluster"
            },
            app72: {
               app_file_path: "/obma_patch_installer/deployables/apps/obpy",
               app_file_name: "obpy-party-adapter-services-10.2.0.war",
               app_target_name: "obpy_cluster"
            },
            app73: {
                app_file_path: "/obma_patch_installer/deployables/apps/obpy",
                app_file_name: "obpy-party-corporate-view-services-10.2.0.war",
                app_target_name: "obpy_cluster"
            },
            app74: {
                app_file_path: "/obma_patch_installer/deployables/apps/obpy",
                app_file_name: "obpy-party-batch-services-10.2.0.war",
                app_target_name: "obpy_cluster"
            },                    
            app75: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "app-shell-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
            app76: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "cmc-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },        
            app77: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "sms-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },        
            app77: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "oblm-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },        
            app77: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obvamlm-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },        
            app77: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obic-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
            app78: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "moc-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },        
            app79: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-limits-collaterals-services-10.2.0.war",
              app_target_name: "cmc_cluster4"
            },        
            app102: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obpy-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
            app1042: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obbrn-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
            app105: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obbrncmn-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
            app106: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obbrscasa-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
            app107: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obbrsdep-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
            app108: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obbrsloan-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
            app103: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obcm-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
            app104: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obscfcm-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
            app57: {
            app_file_path: "/obma_patch_installer/deployables/apps/cmc",
            app_file_name: "cmc-nlp-maintenance-services-10.2.0.war",
            app_target_name: "cmc_cluster3"
            },
            app58: {
            app_file_path: "/obma_patch_installer/deployables/apps/cmc",
            app_file_name: "cmc-nlp-pipeline-services-10.2.0.war",
            app_target_name: "cmc_cluster3"
            },
            app59: {
            app_file_path: "/obma_patch_installer/deployables/apps/cmc",
            app_file_name: "cmc-nlp-text-extraction-services-10.2.0.war",
            app_target_name: "cmc_cluster3"
            },
            app60: {
            app_file_path: "/obma_patch_installer/deployables/apps/cmc",
            app_file_name: "cmc-nlp-dashboard-widget-services-10.2.0.war",
            app_target_name: "cmc_cluster3"
            },
            app61: {
            app_file_path: "/obma_patch_installer/deployables/apps/cmc",    
            app_file_name: "cmc-fc-ai-ml-services-10.2.0.war",
            app_target_name: "cmc_cluster4"
            },
            app62: {
            app_file_path: "/obma_patch_installer/deployables/apps/cmc",
            app_file_name: "cmc-nlp-docview-services-10.2.0.war",
            app_target_name: "cmc_cluster4"
            },
            app63: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-ml-indb-services-10.2.0.war",
              app_target_name: "cmc_cluster4"
           },
           app64: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-obcbs-services-10.2.0.war",
              app_target_name: "cmc_cluster4"
           },           
           app84: {
              app_file_path: "/obma_installer/deployables/apps/cmc",
              app_file_name: "cmc-aif-config-provider-services-10.2.0.war",
              app_target_name: "cmc_cluster4"
           },
           app85: {
              app_file_path: "/obma_installer/deployables/apps/cmc",
              app_file_name: "cmc-aif-document-system-config-services-10.2.0.war",
              app_target_name: "cmc_cluster4"
           },
           app65: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-ml-genai-admin-services-10.2.0.war",
              app_target_name: "cmc_cluster4"
           },
           app105: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obcc-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
 
            app106: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obcfpm-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
 
            app107: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obclmo-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
 
            app108: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obcr-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
 
            app109: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obelcm-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
 
            app110: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "oboflo-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
 
            app111: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obscf-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
 
            app112: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obtfpm-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
            app104: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obscfcm-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
            app113: {
              app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
              app_file_name: "plato-api-idempotency-config-service-10.2.0.war",
              app_target_name: "plato_others_cluster"
            },
            app114: {
              app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
              app_file_name: "plato-validation-framework-10.2.0.war",
              app_target_name: "plato_others_cluster"
            },
            app115: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-inc-file-services-10.2.0.war",
               app_target_name: "cmc_cluster4"
            },
            app116: {
              app_file_path: "/obma_installer/deployables/apps/pmu",
              app_file_name: "pmu-bd-maintenance-service-10.2.0.war",
              app_target_name: "pmu_cluster"
            },
            app117: {
              app_file_path: "/obma_installer/deployables/apps/pmu",
              app_file_name: "pmu-component-server-10.2.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
            app118: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-inc-file-monitor-services-10.2.0.war",
               app_target_name: "cmc_cluster4"
            }
	},
          app_deployment: {
            app1: {
                app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
               	app_file_name: "plato-config-service-10.3.0.war",
               	app_target_name: "plato_config_cluster"
            },		
            app2: {
                app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
               	app_file_name: "plato-discovery-service-10.3.0.war",
               	app_target_name: "plato_discovery_cluster"
             },
            app17: {    
              app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
				app_file_name: "plato-coherence-server-10.3.0.war",
              app_target_name: "coherence_cluster"
				    },
		    app3: {
                app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
                app_file_name: "plato-api-gateway-10.3.0.war",
                app_target_name: "plato_api_gateway_cluster"
            },
            app4: {
                app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
                app_file_name: "plato-ui-config-services-10.3.0.war",
                app_target_name: "plato_ui_config_cluster"
            },
            app5: {
                app_file_path: "/obma_patch_installer/deployables/apps/conductor",
                app_file_name: "conductor-server-v3.15.3.war",
                app_target_name: "plato_o_cluster"
            },
            app6: {
                app_file_path: "/obma_patch_installer/deployables/apps/sms",
                app_file_name: "sms-core-services-10.3.0.war",
                app_target_name: "sms_cluster"
            },
			app93: {
              app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
				app_file_name: "plato-archival-services-10.3.0.war",
				app_target_name: "plato_others_cluster"
			},
            app7: {
                app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
                app_file_name: "plato-orch-service-10.3.0.war",
                app_target_name: "plato_orch_cluster"
            },
			app8: {
               app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
				app_file_name: "plato-alerts-management-services-10.3.0.war",
               app_target_name: "plato_others_cluster"
            },
			app9: {
                app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
				app_file_name: "plato-feed-services-10.3.0.war",
                app_target_name: "plato_others_cluster"
            },
			app10: {
               app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
				app_file_name: "plato-rule-service-10.3.0.war",
               app_target_name: "plato_others_cluster"
            },
			app11: {
				app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
				app_file_name: "plato-report-services-10.3.0.war",
				app_target_name: "plato_others_cluster"
			},
			app12: {
				app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
              app_file_name: "plato-batch-server-10.3.0.war",
				app_target_name: "plato_others_cluster"
			},
			app13: {
				app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
				app_file_name: "plato-transport-services-10.3.0.war",
				app_target_name: "plato_others_cluster"
			},			
			app91: {
				app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
				app_file_name: "plato-dynamic-data-services-10.3.0.war",
				app_target_name: "plato_others_cluster"
			},
			app92: {
              app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
				app_file_name: "plato-fast-data-transfer-service-10.3.0.war",
              app_target_name: "plato_others_cluster"
            },
			app80: {
              app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
					app_file_name: "plato-ref-app-10.3.0.war",
              app_target_name: "plato_others_cluster"
            },
			app14: {
              app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
              app_file_name: "plato-api-hub-10.3.0.war",
              app_target_name: "plato_others_cluster"
            },
			app16: {
              app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
              app_file_name: "plato-regional-configurator-services-10.3.0.war",
              app_target_name: "plato_others_cluster"
            },			
			app82: {
              app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
              app_file_name: "plato-password-policy-service-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },			
			app83: {
               app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
               app_file_name: "plato-edp-services-10.3.0.war",
              app_target_name: "plato_others_cluster"
            },
            app18: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-resource-segment-orchestrator-service-10.3.0.war",
              app_target_name: "cmc_cluster1"
            },
			app19: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-datasegment-services-10.3.0.war",
               app_target_name: "cmc_cluster1"
             },           
			app20: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-additional-attributes-services-10.3.0.war",
               app_target_name: "cmc_cluster1"
             },			
			app21: {
               app_file_path: "/obma_patch_installer/deployables/apps/moc",
               app_file_name: "cmc-sequencegenerator-services-10.3.0.war",
               app_target_name: "moc_cluster"
             },			
			app22: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-batch-services-10.3.0.war",
               app_target_name: "cmc_cluster1"
             },			
			app23: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-mis-services-10.3.0.war",
               app_target_name: "cmc_cluster4"
             },			
			app24: { 
               app_file_path: "/obma_patch_installer/deployables/apps/moc",
               app_file_name: "cmc-corebanking-adapter-service-10.3.0.war",
               app_target_name: "cmc_cluster3"
             },			
			app25: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-external-virtual-account-services-10.3.0.war",
               app_target_name: "cmc_cluster4"
             },			
			app26: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-obrh-kafka-consumer-10.3.0.war",
               app_target_name: "cmc_cluster1"
             },			
			app27: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-screenclass-services-10.3.0.war",
               app_target_name: "cmc_cluster2"
             },			
			app28: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-charges-calculation-services-10.3.0.war",
               app_target_name: "cmc_cluster2"
             },			
            app29: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-transactioncontroller-services-10.3.0.war",
               app_target_name: "cmc_cluster2"
             },			
            app30: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-account-services-10.3.0.war",
               app_target_name: "cmc_cluster2"
             },			
            app31: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-base-services-10.3.0.war",
              app_target_name: "cmc_cluster2"
            },
            app32: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-branch-services-10.3.0.war",
              app_target_name: "cmc_cluster2"
            },
            app33: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-currency-services-10.3.0.war",
              app_target_name: "cmc_cluster2"
            },
            app34: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-customer-services-10.3.0.war",
               app_target_name: "cmc_cluster2"
             },			
            app35: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-external-chart-account-10.3.0.war",
               app_target_name: "cmc_cluster3"
             },			
            app36: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-external-system-services-10.3.0.war",
               app_target_name: "cmc_cluster3"
             },			
			app37: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-report-services-10.3.0.war",
              app_target_name: "cmc_cluster3"
            },
			app38: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-resourceclass-services-10.3.0.war",
               app_target_name: "cmc_cluster1"
             },			
			app39: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-settlements-services-10.3.0.war",
               app_target_name: "cmc_cluster3"
             },			
            app40: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-txn-code-services-10.3.0.war",
               app_target_name: "cmc_cluster3"
             },			
            app41: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-businessoverrides-services-10.3.0.war",
               app_target_name: "cmc_cluster4"
             },			
            app42: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-advice-services-10.3.0.war",
               app_target_name: "cmc_cluster4"
            },
            app50: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-facilities-service-10.3.0.war",
              app_target_name: "cmc_cluster4"
            },
            app64: {
              app_file_path: "/obma_patch_installer/deployables/apps/moc",
              app_file_name: "cmc-service-deprecation-svc-10.3.0.war",
              app_target_name: "moc_cluster"
            },
			app44: {
               app_file_path: "/obma_patch_installer/deployables/apps/moc",
               app_file_name: "cmc-sla-services-10.3.0.war",
               app_target_name: "moc_cluster"
             },
			app45: {
               app_file_path: "/obma_patch_installer/deployables/apps/moc",
               app_file_name: "cmc-processcode-service-10.3.0.war",
               app_target_name: "moc_cluster"
             },			
			app46: {
               app_file_path: "/obma_patch_installer/deployables/apps/moc",
               app_file_name: "cmc-checklist-services-10.3.0.war",
               app_target_name: "moc_cluster"
             },          
			app47: {
               app_file_path: "/obma_patch_installer/deployables/apps/moc",
               app_file_name: "cmc-checklistmanagement-services-10.3.0.war",
               app_target_name: "moc_cluster"
             },				
			app48: {
              app_file_path: "/obma_patch_installer/deployables/apps/moc",
              app_file_name: "cmc-applicationcategory-services-10.3.0.war",
              app_target_name: "moc_cluster"
            },			
			app49: {
              app_file_path: "/obma_patch_installer/deployables/apps/moc",
              app_file_name: "cmc-comments-services-10.3.0.war",
              app_target_name: "moc_cluster"
            },			
			app50: {
              app_file_path: "/obma_patch_installer/deployables/apps/moc",
              app_file_name: "cmc-document-services-10.3.0.war",
              app_target_name: "moc_cluster"
            },		
			app51: {
              app_file_path: "/obma_patch_installer/deployables/apps/moc",
              app_file_name: "cmc-documentmanagement-services-10.3.0.war",
              app_target_name: "moc_cluster"
            },		
			app52: {
              app_file_path: "/obma_patch_installer/deployables/apps/moc",
              app_file_name: "cmc-mailnotification-services-10.3.0.war",
              app_target_name: "moc_cluster"
            },		
			app53: {
              app_file_path: "/obma_patch_installer/deployables/apps/moc",
              app_file_name: "cmc-priority-service-10.3.0.war",
              app_target_name: "moc_cluster"
            },		
			app54: { 
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-external-deposit-account-services-10.3.0.war",
              app_target_name: "cmc_cluster3"
			},		
		   ap55: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-obrh-service-10.3.0.war",
              app_target_name: "cmc_cluster1"
            },
           app56: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-interest-rate-services-10.3.0.war",
              app_target_name: "cmc_cluster1"
            },		
			app100: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-opds-services-10.3.0.war",
              app_target_name: "cmc_cluster4"
            },		
			app655: {
                app_file_path: "/obma_patch_installer/deployables/apps/obpy",
               	app_file_name: "obpy-party-maintenance-service-10.3.0.war",
               	app_target_name: "obpy_cluster"
            },
            app66: {
                app_file_path: "/obma_patch_installer/deployables/apps/obpy",
               	app_file_name: "obpy-stage-services-10.3.0.war",
               	app_target_name: "obpy_cluster"
            },
			app67: {
                app_file_path: "/obma_patch_installer/deployables/apps/obpy",
                app_file_name: "obpy-party-services-10.3.0.war",
                app_target_name: "obpy_cluster"
            },
            app68: {
                app_file_path: "/obma_patch_installer/deployables/apps/obpy",
                app_file_name: "obpy-party-kyc-services-10.3.0.war",
                app_target_name: "obpy_cluster"
            },
            app69: {
                app_file_path: "/obma_patch_installer/deployables/apps/obpy",
                app_file_name: "obpy-businessprocess-services-10.3.0.war",
                app_target_name: "obpy_cluster"
            },
            app70: {
                app_file_path: "/obma_patch_installer/deployables/apps/obpy",
                app_file_name: "obpy-party-handoff-services-10.3.0.war",
                app_target_name: "obpy_cluster"
            },
            app71: {
                app_file_path: "/obma_patch_installer/deployables/apps/obpy",
                app_file_name: "obpy-party-publisher-services-10.3.0.war",
                app_target_name: "obpy_cluster"
            },
			app72: {
               app_file_path: "/obma_patch_installer/deployables/apps/obpy",
               app_file_name: "obpy-party-adapter-services-10.3.0.war",
               app_target_name: "obpy_cluster"
            },
            app73: {
                app_file_path: "/obma_patch_installer/deployables/apps/obpy",
                app_file_name: "obpy-party-corporate-view-services-10.3.0.war",
                app_target_name: "obpy_cluster"
            },
            app74: {
                app_file_path: "/obma_patch_installer/deployables/apps/obpy",
                app_file_name: "obpy-party-batch-services-10.3.0.war",
                app_target_name: "obpy_cluster"
            },					
            app75: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "app-shell-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
            app76: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "cmc-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },		
            app77: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "sms-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },		
            app77: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "oblm-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },		
            app77: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obvamlm-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },		
            app77: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obic-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
            app78: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "moc-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },		
            app79: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-limits-collaterals-services-10.3.0.war",
              app_target_name: "cmc_cluster4"
            },		
			app102: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obpy-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
			app1042: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obbrn-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
			app105: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obbrncmn-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
			app106: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obbrscasa-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
			app107: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obbrsdep-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
			app108: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obbrsloan-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
			app103: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obcm-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
			app104: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obscfcm-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
			app57: {
			app_file_path: "/obma_patch_installer/deployables/apps/cmc",
			app_file_name: "cmc-nlp-maintenance-services-10.3.0.war",
			app_target_name: "cmc_cluster3"
			},
			app58: {
			app_file_path: "/obma_patch_installer/deployables/apps/cmc",
			app_file_name: "cmc-nlp-pipeline-services-10.3.0.war",
			app_target_name: "cmc_cluster3"
			},
			app59: {
			app_file_path: "/obma_patch_installer/deployables/apps/cmc",
			app_file_name: "cmc-nlp-text-extraction-services-10.3.0.war",
			app_target_name: "cmc_cluster3"
			},
			app60: {
			app_file_path: "/obma_patch_installer/deployables/apps/cmc",
			app_file_name: "cmc-nlp-dashboard-widget-services-10.3.0.war",
			app_target_name: "cmc_cluster3"
			},
			app61: {
			app_file_path: "/obma_patch_installer/deployables/apps/cmc",	
			app_file_name: "cmc-fc-ai-ml-services-10.3.0.war",
			app_target_name: "cmc_cluster4"
			},
			app62: {
			app_file_path: "/obma_patch_installer/deployables/apps/cmc",
			app_file_name: "cmc-nlp-docview-services-10.3.0.war",
			app_target_name: "cmc_cluster4"
			},
            app63: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-ml-indb-services-10.3.0.war",
              app_target_name: "cmc_cluster4"
           },
           app64: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-obcbs-services-10.3.0.war",
              app_target_name: "cmc_cluster4"
           },
           app65: {
              app_file_path: "/obma_patch_installer/deployables/apps/cmc",
              app_file_name: "cmc-ml-genai-admin-services-10.3.0.war",
              app_target_name: "cmc_cluster4"
           },
		   app105: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obcc-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },

			app106: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obcfpm-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },

			app107: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obclmo-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },

			app108: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obcr-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },

			app109: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obelcm-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },

			app110: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "oboflo-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },

			app111: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obscf-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },

			app112: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obtfpm-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
			app104: {
              app_file_path: "/obma_patch_installer/deployables/apps/ui",
              app_file_name: "obscfcm-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
            app113: {
              app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
              app_file_name: "plato-api-idempotency-config-service-10.3.0.war",
              app_target_name: "plato_others_cluster"
            },
            app114: {
              app_file_path: "/obma_patch_installer/deployables/apps/platoinfra",
              app_file_name: "plato-validation-framework-10.3.0.war",
              app_target_name: "plato_others_cluster"
            },
			app115: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-inc-file-services-10.3.0.war",
               app_target_name: "cmc_cluster4"
	        },
            app116: {
              app_file_path: "/obma_installer/deployables/apps/pmu",
              app_file_name: "pmu-bd-maintenance-service-10.3.0.war",
              app_target_name: "pmu_cluster"
            },
			app117: {
              app_file_path: "/obma_installer/deployables/apps/pmu",
              app_file_name: "pmu-component-server-10.3.0.war",
              app_target_name: "plato_api_gateway_cluster"
            },
            app118: {
               app_file_path: "/obma_patch_installer/deployables/apps/cmc",
               app_file_name: "cmc-inc-file-monitor-services-10.3.0.war",
               app_target_name: "cmc_cluster4"
	        }
        },
         plato_apigateway_router_deploy: "true",
         deploy_apigateway_router: {
            plato_apigateway_router_port: PLATO_APIGATEWAY_ROUTER_PORT,
         plato_apigateway_router_protocol: PLATO_APIGATEWAY_ROUTER_PROTOCOL,
         app_file_path: APIGATEWAY_ROUTER_JAR_LOCATION,
         app_filename: APIGATEWAY_ROUTER_JAR_NAME
        },
      }
)
# # Runlist
#run_list ['recipe[obma_java_upgrade::_upgrade_java]']

#,'recipe[obma_zk_kafka_upgrade::delete_topic]','recipe[obma_zk_kafka_upgrade::delete_scram_users]','recipe[obma_zk_kafka_upgrade::stop_kafka]','recipe[obma_zk_kafka_upgrade::stop_zookeeper]','recipe[obma_zk_kafka_upgrade]']


#run_list ['recipe[obma_patchset::undeployapigateway_router]','recipe[obma_patchset::undeployallapp]','recipe[obma_patchset::stopman]', 'recipe[obma_patchset::stopnm]','recipe[obma_patchset::stopadmin]', 'recipe[obma_zk_kafka_upgrade::delete_scram_users]','recipe[obma_zk_kafka_upgrade::stop_kafka]','recipe[obma_zk_kafka_upgrade::stop_zookeeper]','recipe[obma_patchset::updatesetuseroverrides_patch]','recipe[obma_zk_kafka_upgrade]','recipe[obma_sqlcl::sqlcl_deployer]','recipe[obma_patchset::startadmin]','recipe[obma_patchset::startnm]','recipe[obma_patchset::startman]','recipe[obma_patchset::deployapp]','recipe[obma_patchset::deployapigateway_router]']

#run_list ['recipe[obma_sqlcl::sqlcl_deployer]']

#run_list ['recipe[obma_patchset::undeployapp]']

run_list ['recipe[obma_zk_kafka_upgrade]']

#run_list ['recipe[obma_patchset::deployapigateway_router]']
