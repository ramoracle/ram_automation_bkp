#!/usr/bin/env bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99


set -uo pipefail

export CLASSPATH="${CLASSPATH:-/PATH_TO_CONFIGURE}"

ADMIN_URL="${ADMIN_URL:-t3://hostname:PORT}"
ADMIN_USER="${ADMIN_USER:-weblogic}"
ADMIN_PASSWORD="SECRET_REMOVED"
WAR_DIR="${WAR_DIR:-/PATH_TO_CONFIGURE}"
LOG_DIR="${LOG_DIR:-/PATH_TO_CONFIGURE}"
DRY_RUN="${DRY_RUN:-0}"

mkdir -p "${LOG_DIR}"
LOG_FILE="${LOG_DIR}/OBDX_may2026_deploy_$(date +%Y%m%d_%H%M%S).log"

# Mapping taken from the provided workbook/console target list.
DEPLOYMENTS=(
  "com.ofss.digx.connector|obdx_server1"
  "digx-account|obdx_cluster"
  "digx-admin|obdx_cluster"
  "digx-approval|obdx_cluster"
  "digx-berlinob|obdx_cluster"
  "digx-cms|obdx_cluster"
  "digx-common|obdx_cluster"
  "digx-configserver|obdx_configserver_cluster"
  "digx-corporateloan|obdx_cluster"
  "digx-corporateorigination|obdx_cluster"
  "digx-creditfacility|obdx_cluster"
  "digx-edx|obdx_cluster"
  "digx-em|obdx_cluster"
  "digx-finlimit|obdx_cluster"
  "digx-genai|obdx_cluster"
  "digx-infra|obdx_cluster"
  "digx-liquiditymanagement|obdx_cluster"
  "digx-migration|obdx_cluster"
  "digx-payments|obdx_cluster"
  "digx-pfm|obdx_cluster"
  "digx-processmanagement|obdx_cluster"
  "digx-retail|obdx_cluster"
  "digx-scf|obdx_cluster"
  "digx-scfcm|obdx_cluster"
  "digx-sms|obdx_cluster"
  "digx-tradefinance|obdx_cluster"
  "digx-ubsnotification|obdx_cluster"
  "digx-ukob|obdx_cluster"
  "digx-virtual-account|obdx_cluster"
  "digx-webauthn|obdx_cluster"
)

SUCCESS_APPS=()
FAILED_APPS=()
MISSING_APPS=()

log() {
  printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" | tee -a "${LOG_FILE}"
}

deploy_app() {
  local app_name="$1"
  local target_name="$2"
  local war_path="${WAR_DIR}/${app_name}.war"
  local cmd=(
    java weblogic.Deployer
    -adminurl "${ADMIN_URL}"
    -user "${ADMIN_USER}"
    -password "${ADMIN_PASSWORD}"
    -name "${app_name}"
    -targets "${target_name}"
    -deploy "${war_path}"
    -remote
    -upload
  )

  if [[ ! -f "${war_path}" ]]; then
    MISSING_APPS+=("${app_name}")
    log "MISSING  ${war_path}  target=${target_name}"
    return 0
  fi

  log "START    app=${app_name} target=${target_name} war=${war_path}"

  if [[ "${DRY_RUN}" == "1" ]]; then
    printf '%q ' "${cmd[@]}" | tee -a "${LOG_FILE}"
    printf '\n' | tee -a "${LOG_FILE}"
    SUCCESS_APPS+=("${app_name}")
    log "DRY-RUN  app=${app_name}"
    return 0
  fi

  if "${cmd[@]}" >>"${LOG_FILE}" 2>&1; then
    SUCCESS_APPS+=("${app_name}")
    log "SUCCESS  app=${app_name}"
  else
    FAILED_APPS+=("${app_name}")
    log "FAILED   app=${app_name}"
  fi
}

{
  echo "STARTED deployments of OBDX Services"
  echo "Admin URL : ${ADMIN_URL}"
  echo "WAR dir   : ${WAR_DIR}"
  echo "Log file  : ${LOG_FILE}"
} >>"${LOG_FILE}"

for entry in "${DEPLOYMENTS[@]}"; do
  IFS='|' read -r app_name target_name <<< "${entry}"
  deploy_app "${app_name}" "${target_name}"
done

log "SUMMARY success=${#SUCCESS_APPS[@]} failed=${#FAILED_APPS[@]} missing=${#MISSING_APPS[@]}"

if (( ${#MISSING_APPS[@]} > 0 )); then
  log "Missing WARs: ${MISSING_APPS[*]}"
fi

if (( ${#FAILED_APPS[@]} > 0 )); then
  log "Failed deployments: ${FAILED_APPS[*]}"
fi

if (( ${#FAILED_APPS[@]} > 0 || ${#MISSING_APPS[@]} > 0 )); then
  exit 1
fi

exit 0
