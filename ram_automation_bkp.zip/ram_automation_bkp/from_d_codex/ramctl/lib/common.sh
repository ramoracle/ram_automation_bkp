#!/usr/bin/env bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99


die() {
  echo "ERROR: $*" >&2
  exit 1
}

confirm_or_die() {
  local prompt="$1"
  local flag="${2:-}"
  if [[ "$flag" == "--yes-i-understand" ]]; then
    return 0
  fi
  echo "$prompt"
  echo "Re-run with --yes-i-understand to continue."
  exit 3
}

valid_name() {
  [[ "${1:-}" =~ ^[A-Za-z][A-Za-z0-9_#\$]*$ ]]
}

load_db_config() {
  local db_key="${1:-}"
  [[ -n "$db_key" ]] || die "Database target is required."
  valid_name "$db_key" || die "Invalid database target name: $db_key"

  local cfg="$RAMCTL_HOME/config/databases.conf"
  [[ -f "$cfg" ]] || die "Missing config: $cfg. Copy config/databases.conf.example first."
  # shellcheck source=/dev/null
  . "$cfg"

  local prefix="DB_${db_key}_"
  eval "DB_HOST=\"\${${prefix}HOST:-}\""
  eval "DB_IP=\"\${${prefix}IP:-}\""
  eval "DB_OS_USER=\"\${${prefix}OS_USER:-}\""
  eval "ORACLE_SID=\"\${${prefix}ORACLE_SID:-}\""
  eval "ORACLE_HOME=\"\${${prefix}ORACLE_HOME:-}\""
  eval "ORACLE_BASE=\"\${${prefix}ORACLE_BASE:-}\""
  eval "BACKUP_ROOT=\"\${${prefix}BACKUP_ROOT:-}\""
  eval "LOG_ROOT=\"\${${prefix}LOG_ROOT:-}\""
  eval "DATA_ROOT=\"\${${prefix}DATA_ROOT:-}\""
  eval "START_MODE=\"\${${prefix}START_MODE:-open}\""
  eval "DB_RUN_LOCAL=\"\${${prefix}RUN_LOCAL:-false}\""

  [[ -n "$ORACLE_SID" ]] || die "ORACLE_SID missing for $db_key"
  [[ -n "$ORACLE_HOME" ]] || die "ORACLE_HOME missing for $db_key"
  [[ -n "$ORACLE_BASE" ]] || die "ORACLE_BASE missing for $db_key"
  [[ -n "$BACKUP_ROOT" ]] || die "BACKUP_ROOT missing for $db_key"
  [[ -n "$LOG_ROOT" ]] || die "LOG_ROOT missing for $db_key"

  export ORACLE_SID ORACLE_HOME ORACLE_BASE
  export PATH="$ORACLE_HOME/bin:$PATH"
}

load_domain_config() {
  local domain_key="${1:-}"
  [[ -n "$domain_key" ]] || die "Domain target is required."
  domain_key="$(echo "$domain_key" | tr '[:lower:]' '[:upper:]' | sed -E 's/[^A-Z0-9]+/_/g; s/^_+|_+$//g')"
  valid_name "$domain_key" || die "Invalid domain target name: $domain_key"

  local cfg="$RAMCTL_HOME/config/domains.conf"
  [[ -f "$cfg" ]] || die "Missing config: $cfg."
  # shellcheck source=/dev/null
  . "$cfg"

  local prefix="DOMAIN_${domain_key}_"
  eval "DOMAIN_PRODUCT=\"\${${prefix}PRODUCT:-}\""
  eval "DOMAIN_HOST=\"\${${prefix}HOST:-}\""
  eval "DOMAIN_IP=\"\${${prefix}IP:-}\""
  eval "DOMAIN_OS_USER=\"\${${prefix}OS_USER:-}\""
  eval "DOMAIN_NAME=\"\${${prefix}DOMAIN_NAME:-}\""
  eval "DOMAIN_PATH=\"\${${prefix}DOMAIN_PATH:-}\""
  eval "DOMAIN_BIN=\"\${${prefix}DOMAIN_BIN:-}\""
  eval "DOMAIN_ADMIN_PORT=\"\${${prefix}ADMIN_PORT:-}\""
  eval "DOMAIN_SSL_PORT=\"\${${prefix}SSL_PORT:-}\""
  eval "DOMAIN_CONSOLE_URL=\"\${${prefix}CONSOLE_URL:-}\""
  eval "DOMAIN_APP_URL=\"\${${prefix}APP_URL:-}\""
  eval "DOMAIN_LOG_PATH=\"\${${prefix}LOG_PATH:-}\""
  eval "DOMAIN_MANAGED_SERVER=\"\${${prefix}MANAGED_SERVER:-}\""
  eval "DOMAIN_NODEMANAGER_PORT=\"\${${prefix}NODEMANAGER_PORT:-}\""

  [[ -n "$DOMAIN_HOST" ]] || die "DOMAIN_HOST missing for $domain_key"
  [[ -n "$DOMAIN_OS_USER" ]] || die "DOMAIN_OS_USER missing for $domain_key"
  [[ -n "$DOMAIN_PATH" ]] || die "DOMAIN_PATH missing for $domain_key"
}

sq() {
  printf "'%s'" "$(printf "%s" "$1" | sed "s/'/'\\\\''/g")"
}

sql_sq() {
  printf "'%s'" "$(printf "%s" "$1" | sed "s/'/''/g")"
}

make_log() {
  local action="$1"
  local root="${LOG_ROOT:-$RAMCTL_HOME/logs}"
  mkdir -p "$root" 2>/dev/null || root="$RAMCTL_HOME/logs"
  mkdir -p "$root"
  RUN_LOG="$root/${action}_${ORACLE_SID:-ramctl}_$(date +%Y%m%d_%H%M%S).log"
  touch "$RUN_LOG" || die "Cannot create log: $RUN_LOG"
  export RUN_LOG
}

log() {
  local now
  now="$(date '+%Y-%m-%d %H:%M:%S')"
  echo "[$now] $*" | tee -a "${RUN_LOG:-/dev/null}"
}

run_sqlplus() {
  sqlplus -s / as sysdba
}

run_rman() {
  rman target /
}

ssh_bash() {
  local target="$1"
  ssh \
    -o Ciphers=aes256-ctr,aes128-ctr \
    -o MACs=hmac-sha2-256,hmac-sha2-512 \
    -o IPQoS=none \
    "$target" "bash -s"
}

db_use_ssh() {
  [[ "${DB_RUN_LOCAL:-false}" != "true" && -n "${DB_HOST:-}" && -n "${DB_OS_USER:-}" ]]
}

db_ssh_target() {
  [[ -n "${DB_HOST:-}" ]] || die "DB_HOST missing for database target."
  [[ -n "${DB_OS_USER:-}" ]] || die "DB_OS_USER missing for database target."
  printf "%s@%s" "$DB_OS_USER" "$DB_HOST"
}

db_env_header() {
  cat <<DBENV
set -euo pipefail
export ORACLE_SID=$(sq "$ORACLE_SID")
export ORACLE_HOME=$(sq "$ORACLE_HOME")
export ORACLE_BASE=$(sq "$ORACLE_BASE")
export PATH="\$ORACLE_HOME/bi/PATH_TO_CONFIGURE"
export LD_LIBRARY_PATH="\$ORACLE_HOME/li/PATH_TO_CONFIGURE"
unset TWO_TASK LOCAL TNS_ADMIN
echo "===== RAMCTL DB ====="
echo "Host        : \$(hostname -f 2>/dev/null || hostname)"
echo "User        : \$(whoami)"
echo "ORACLE_SID  : \$ORACLE_SID"
echo "ORACLE_HOME : \$ORACLE_HOME"
echo
DBENV
}

run_db_bash() {
  if db_use_ssh; then
    local target
    target="$(db_ssh_target)"
    {
      db_env_header
      cat
    } | ssh_bash "$target"
  else
    {
      db_env_header
      cat
    } | bash
  fi
}
