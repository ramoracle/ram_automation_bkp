#!/usr/bin/env bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99

set -euo pipefail

# shellcheck source=../lib/common.sh
. "$RAMCTL_HOME/lib/common.sh"

usage() {
  cat <<'EOF'
Usage:
  ramctl.sh db status <DB>
  ramctl.sh db start <DB> [mount|open]
  ramctl.sh db stop <DB> --yes-i-understand
  ramctl.sh db pdbs <DB>
EOF
}

action="${1:-}"
db="${2:-}"
mode="${3:-}"

[[ -n "$action" && -n "$db" ]] || { usage; exit 2; }
load_db_config "$db"
make_log "db_${action}"

case "$action" in
  status)
    log "Checking database status for $ORACLE_SID"
    run_db_bash <<'REMOTE' | tee -a "$RUN_LOG"
sqlplus -s / as sysdba <<'SQL'
set lines 200 pages 100
select instance_name, status, database_status from v$instance;
select name, open_mode, log_mode from v$database;
show pdbs
SQL
REMOTE
    ;;

  pdbs)
    run_db_bash <<'REMOTE' | tee -a "$RUN_LOG"
sqlplus -s / as sysdba <<'SQL'
set lines 200 pages 100
show pdbs
SQL
REMOTE
    ;;

  start)
    start_mode="${mode:-$START_MODE}"
    [[ "$start_mode" == "mount" || "$start_mode" == "open" ]] || die "Start mode must be mount or open."
    log "Starting $ORACLE_SID in $start_mode mode"
    if [[ "$start_mode" == "mount" ]]; then
      run_db_bash <<'REMOTE' | tee -a "$RUN_LOG"
sqlplus -s / as sysdba <<'SQL'
startup mount;
select instance_name, status from v$instance;
SQL
REMOTE
    else
      run_db_bash <<'REMOTE' | tee -a "$RUN_LOG"
sqlplus -s / as sysdba <<'SQL'
startup;
alter pluggable database all open;
alter pluggable database all save state;
show pdbs
SQL
REMOTE
    fi
    ;;

  stop)
    confirm_or_die "This will stop database $ORACLE_SID." "$mode"
    log "Stopping $ORACLE_SID"
    run_db_bash <<'REMOTE' | tee -a "$RUN_LOG"
sqlplus -s / as sysdba <<'SQL'
shutdown immediate;
SQL
REMOTE
    ;;

  *)
    usage
    exit 2
    ;;
esac
