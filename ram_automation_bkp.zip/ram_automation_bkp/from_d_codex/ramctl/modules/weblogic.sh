#!/usr/bin/env bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99

set -euo pipefail

# shellcheck source=../lib/common.sh
. "$RAMCTL_HOME/lib/common.sh"

usage() {
  cat <<'EOF'
Usage:
  ramctl.sh weblogic status <DOMAIN>
  ramctl.sh weblogic logs <DOMAIN> [managed_server]
  ramctl.sh weblogic start-nm <DOMAIN>
  ramctl.sh weblogic start-admin <DOMAIN>
  ramctl.sh weblogic start-managed <DOMAIN> [managed_server]
  ramctl.sh weblogic start-full <DOMAIN> [managed_server]
  ramctl.sh weblogic stop-managed <DOMAIN> [managed_server] --yes-i-understand
  ramctl.sh weblogic stop-admin <DOMAIN> --yes-i-understand

Examples:
  ramctl.sh weblogic status OBDX
  ramctl.sh weblogic logs OBDX obdx_server1
  ramctl.sh weblogic start-full OBDX obdx_server1
EOF
}

to_t3_url() {
  local url="$1"
  url="${url%/console}"
  url="${url%/console/}"
  url="${url/#http/PATH_TO_CONFIGURE"
  url="${url/#htt/PATH_TO_CONFIGURE"
  printf "%s" "$url"
}

action="${1:-}"
target="${2:-}"
server_arg="${3:-}"
if [[ "$action" == "stop-admin" ]]; then
  confirm="${3:-}"
else
  confirm="${4:-}"
fi

[[ -n "$action" && -n "$target" ]] || { usage; exit 2; }
load_domain_config "$target"

managed_server="${server_arg:-$DOMAIN_MANAGED_SERVER}"
admin_url="$(to_t3_url "$DOMAIN_CONSOLE_URL")"
ssh_target="$DOMAIN_OS_USER@$DOMAIN_HOST"

case "$action" in
  status|logs|start-nm|start-admin|start-managed|start-full)
    ;;
  stop-admin|stop-managed)
    confirm_or_die "This will stop WebLogic server(s) for $target on $ssh_target." "$confirm"
    ;;
  *)
    usage
    exit 2
    ;;
esac

if [[ "$action" == "start-managed" || "$action" == "start-full" || "$action" == "stop-managed" || "$action" == "logs" ]]; then
  [[ -n "$managed_server" ]] || die "Managed server is required for $action. Pass it as the next argument or fill DOMAIN_${target}_MANAGED_SERVER."
fi

remote_script=$(cat <<REMOTE
set -u
DOMAIN_PATH=$(sq "$DOMAIN_PATH")
MANAGED_SERVER=$(sq "$managed_server")
ADMIN_URL=$(sq "$admin_url")
ACTION=$(sq "$action")

echo "===== RAMCTL WebLogic ====="
echo "Host       : \$(hostname -f 2>/dev/null || hostname)"
echo "User       : \$(whoami)"
echo "Domain     : \$DOMAIN_PATH"
echo "Action     : \$ACTION"
echo "Server     : \$MANAGED_SERVER"
echo "Admin URL  : \$ADMIN_URL"
echo

if [ ! -d "\$DOMAIN_PATH" ]; then
  echo "ERROR: Domain path not found: \$DOMAIN_PATH"
  exit 2
fi

server_logs() {
  find "\$DOMAIN_PATH/servers" -path "*/logs/*.log" -type f \
    ! -name "access.log" ! -name "*access*.log" ! -name "*.out" 2>/dev/null
}

recent_states() {
  server_logs | xargs grep -iE "BEA-000365|Server state changed|RUNNING|ADMIN|FAILED|ModuleException|DeploymentException|Critical|Emergency|Caused By|Caused by|Exception|Error" 2>/dev/null | tail -120 || true
}

start_nm() {
  if ps -ef | grep -v grep | grep -q "[w]eblogic.NodeManager.*\$DOMAIN_PATH"; then
    echo "NodeManager already running for \$DOMAIN_PATH"
    return 0
  fi
  cd "\$DOMAIN_PATH/bin"
  out="nodemanager_start_\$(date +%Y%m%d_%H%M%S).out"
  echo "Starting NodeManager: \$DOMAIN_PATH/bin/\$out"
  nohup ./startNodeManager.sh > "\$out" 2>&1 &
  sleep 10
  tail -120 "\$DOMAIN_PATH/nodemanager/nodemanager.log" 2>/dev/null || tail -120 "\$out"
}

start_admin() {
  if ps -ef | grep -v grep | grep -q "[D]weblogic.Name=AdminServer"; then
    echo "AdminServer process already running"
    return 0
  fi
  cd "\$DOMAIN_PATH/bin"
  out="admin_start_\$(date +%Y%m%d_%H%M%S).out"
  echo "Starting AdminServer: \$DOMAIN_PATH/bin/\$out"
  nohup ./startWebLogic.sh > "\$out" 2>&1 &
  sleep 15
  tail -160 "\$DOMAIN_PATH/servers/AdminServer/logs/AdminServer.log" 2>/dev/null || tail -160 "\$out"
}

start_managed() {
  if ps -ef | grep -v grep | grep -q "[D]weblogic.Name=\$MANAGED_SERVER"; then
    echo "\$MANAGED_SERVER process already running"
    return 0
  fi
  cd "\$DOMAIN_PATH/bin"
  out="\${MANAGED_SERVER}_start_\$(date +%Y%m%d_%H%M%S).out"
  echo "Starting \$MANAGED_SERVER: \$DOMAIN_PATH/bin/\$out"
  nohup ./startManagedWebLogic.sh "\$MANAGED_SERVER" "\$ADMIN_URL" > "\$out" 2>&1 &
  sleep 15
  tail -160 "\$DOMAIN_PATH/servers/\$MANAGED_SERVER/logs/\$MANAGED_SERVER.log" 2>/dev/null || tail -160 "\$out"
}

case "\$ACTION" in
  status)
    echo "===== Processes ====="
    ps -ef | egrep "weblogic.Server|NodeManager|httpd|ohs" | grep -v grep || true
    echo
    echo "===== Ports ====="
    netstat -tulnp 2>/dev/null | egrep "7001|7002|7101|7102|7201|7202|7301|7302|7401|7402|7501|7502|7601|7602|7701|7702|7901|7902|8001|8002|9001|9002|5556|5558" || true
    echo
    echo "===== Recent states/errors ====="
    recent_states
    ;;
  logs)
    recent_states
    if [ -f "\$DOMAIN_PATH/servers/\$MANAGED_SERVER/logs/\$MANAGED_SERVER.log" ]; then
      echo
      echo "===== Tail \$MANAGED_SERVER.log ====="
      tail -160 "\$DOMAIN_PATH/servers/\$MANAGED_SERVER/logs/\$MANAGED_SERVER.log"
    fi
    ;;
  start-nm)
    start_nm
    ;;
  start-admin)
    start_admin
    ;;
  start-managed)
    start_managed
    ;;
  start-full)
    start_nm
    start_admin
    start_managed
    echo
    echo "===== Final status ====="
    ps -ef | egrep "weblogic.Name=AdminServer|weblogic.Name=\$MANAGED_SERVER|NodeManager" | grep -v grep || true
    recent_states
    ;;
  stop-managed)
    cd "\$DOMAIN_PATH/bin"
    ./stopManagedWebLogic.sh "\$MANAGED_SERVER" "\$ADMIN_URL"
    ;;
  stop-admin)
    cd "\$DOMAIN_PATH/bin"
    ./stopWebLogic.sh
    ;;
esac
REMOTE
)

echo "Target: $ssh_target"
echo "Domain: $target ($DOMAIN_PATH)"
echo "Action: $action"
printf "%s\n" "$remote_script" | ssh_bash "$ssh_target"
