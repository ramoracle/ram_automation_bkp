#!/usr/bin/env bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99

set -euo pipefail

# shellcheck source=../lib/common.sh
. "$RAMCTL_HOME/lib/common.sh"

usage() {
  cat <<'EOF'
Usage:
  ramctl.sh rman backup <DB>
  ramctl.sh rman list <DB>
  ramctl.sh rman validate <DB> [latest|catalog_dir]
  ramctl.sh rman restore <DB> <catalog_dir> <controlfile_backup> --yes-i-understand

Notes:
  - backup creates date folder under BACKUP_ROOT.
  - restore is destructive and requires --yes-i-understand.
EOF
}

action="${1:-}"
db="${2:-}"
arg1="${3:-}"
arg2="${4:-}"
arg3="${5:-}"

[[ -n "$action" && -n "$db" ]] || { usage; exit 2; }
load_db_config "$db"
make_log "rman_${action}"

case "$action" in
  backup)
    run_dir="$BACKUP_ROOT/$(date +%Y_%m_%d)"
    log "Starting RMAN backup for $ORACLE_SID"
    log "Backup run directory: $run_dir"
    run_db_bash <<REMOTE | tee -a "$RUN_LOG"
RUN_DIR=$(sq "$run_dir")
mkdir -p "\$RUN_DIR"
rman target / <<RMAN
CONFIGURE CONTROLFILE AUTOBACKUP ON;
RUN {
  ALLOCATE CHANNEL c1 DEVICE TYPE DISK
    FORMAT '\$RUN_DIR/%d_%T_%U.bkp';
  BACKUP AS COMPRESSED BACKUPSET DATABASE TAG 'RAMCTL_BKP_$(date +%Y%m%d_%H%M%S)';
  BACKUP CURRENT CONTROLFILE
    FORMAT '\$RUN_DIR/controlfile_%d_%T_%U.bkp';
  RELEASE CHANNEL c1;
}
LIST BACKUP SUMMARY COMPLETED AFTER 'SYSDATE-1';
RMAN
REMOTE
    ;;

  list)
    log "Listing RMAN backups for $ORACLE_SID"
    run_db_bash <<'REMOTE' | tee -a "$RUN_LOG"
rman target / <<'RMAN'
LIST BACKUP SUMMARY;
LIST BACKUP OF CONTROLFILE;
RMAN
REMOTE
    ;;

  validate)
    target="${arg1:-latest}"
    log "Validating RMAN restore readiness for $ORACLE_SID target=$target"
    run_db_bash <<REMOTE | tee -a "$RUN_LOG"
TARGET=$(sq "$target")
BACKUP_ROOT=$(sq "$BACKUP_ROOT")
if [ "\$TARGET" = "latest" ]; then
  CATALOG_DIR="\$(find "\$BACKUP_ROOT" -maxdepth 1 -mindepth 1 -type d 2>/dev/null | sort | tail -1)"
else
  CATALOG_DIR="\$TARGET"
fi
[ -n "\$CATALOG_DIR" ] && [ -d "\$CATALOG_DIR" ] || { echo "ERROR: Catalog directory not found: \$CATALOG_DIR"; exit 2; }
echo "Catalog directory: \$CATALOG_DIR"
rman target / <<RMAN
CATALOG START WITH '\$CATALOG_DIR/' NOPROMPT;
RESTORE DATABASE VALIDATE;
RMAN
REMOTE
    ;;

  restore)
    catalog_dir="$arg1"
    controlfile="$arg2"
    confirm_or_die "This will restore database $ORACLE_SID using RMAN. Ensure database downtime and backup approval." "$arg3"
    [[ -n "$catalog_dir" ]] || die "Catalog directory is required."
    [[ -n "$controlfile" ]] || die "Controlfile backup is required."
    log "Starting RMAN restore for $ORACLE_SID"
    log "Catalog dir: $catalog_dir"
    log "Controlfile: $controlfile"
    run_db_bash <<REMOTE | tee -a "$RUN_LOG"
CATALOG_DIR=$(sq "$catalog_dir")
CONTROLFILE=$(sq "$controlfile")
[ -d "\$CATALOG_DIR" ] || { echo "ERROR: Catalog directory not found: \$CATALOG_DIR"; exit 2; }
[ -f "\$CONTROLFILE" ] || { echo "ERROR: Controlfile backup not found: \$CONTROLFILE"; exit 2; }
rman target / <<RMAN
SHUTDOWN ABORT;
STARTUP NOMOUNT;
RESTORE CONTROLFILE FROM '\$CONTROLFILE';
ALTER DATABASE MOUNT;
CATALOG START WITH '\$CATALOG_DIR/' NOPROMPT;
RESTORE DATABASE;
RECOVER DATABASE;
ALTER DATABASE OPEN RESETLOGS;
RMAN
REMOTE
    ;;

  *)
    usage
    exit 2
    ;;
esac
