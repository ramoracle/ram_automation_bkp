#!/usr/bin/env bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99

set -euo pipefail

# shellcheck source=../lib/common.sh
. "$RAMCTL_HOME/lib/common.sh"

usage() {
  cat <<'EOF'
Usage:
  ramctl.sh clone pdb <DB> <SOURCE_PDB> <TARGET_PDB> [--yes-i-understand]

Example:
  ramctl.sh clone pdb DATABASE_NAME FC145ODT1 FC145ODT1_0306BK --yes-i-understand

Notes:
  - This creates a new local PDB from an existing source PDB.
  - DATA_ROOT must be set in config/databases.conf.
  - If your DB uses OMF or a special file layout, review generated SQL before using.
EOF
}

kind="${1:-}"
db="${2:-}"
source_pdb="${3:-}"
target_pdb="${4:-}"
confirm="${5:-}"

[[ "$kind" == "pdb" && -n "$db" && -n "$source_pdb" && -n "$target_pdb" ]] || { usage; exit 2; }
valid_name "$source_pdb" || die "Invalid source PDB name: $source_pdb"
valid_name "$target_pdb" || die "Invalid target PDB name: $target_pdb"

load_db_config "$db"
[[ -n "${DATA_ROOT:-}" ]] || die "DATA_ROOT missing for $db"
make_log "clone_pdb"

confirm_or_die "This will create PDB $target_pdb from $source_pdb in $ORACLE_SID." "$confirm"

src_path="$DATA_ROOT/$source_pdb"
tgt_path="$DATA_ROOT/$target_pdb"

log "Cloning PDB $source_pdb to $target_pdb"
log "Source path hint: $src_path"
log "Target path hint: $tgt_path"

run_db_bash <<REMOTE | tee -a "$RUN_LOG"
sqlplus -s / as sysdba <<SQL
set echo on timing on
set lines 200 pages 100
whenever sqlerror exit sql.sqlcode

select name, open_mode from v\$pdbs where name in (upper($(sql_sq "$source_pdb")), upper($(sql_sq "$target_pdb")));

declare
  l_count number;
begin
  select count(*) into l_count from v\$pdbs where name = upper($(sql_sq "$target_pdb"));
  if l_count > 0 then
    raise_application_error(-20001, 'Target PDB already exists: $target_pdb');
  end if;
end;
/

alter pluggable database $source_pdb close immediate;
alter pluggable database $source_pdb open read only;

create pluggable database $target_pdb
  from $source_pdb
  file_name_convert = ($(sql_sq "$src_path"), $(sql_sq "$tgt_path"));

alter pluggable database $target_pdb open;
alter pluggable database $target_pdb save state;
alter pluggable database $source_pdb close immediate;
alter pluggable database $source_pdb open;

show pdbs
SQL
REMOTE
