#!/usr/bin/env bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99

set -euo pipefail

RAMCTL_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export RAMCTL_HOME

usage() {
  cat <<'EOF'
Usage:
  ramctl.sh <module> <action> [args...]

Modules:
  weblogic WebLogic/NodeManager status, start, stop, logs
  db       Database start/stop/status/open/close checks
  rman     RMAN backup/restore/list/validate
  clone    PDB clone helper

Examples:
  ramctl.sh weblogic status OBDX
  ramctl.sh weblogic logs OBDX obdx_server1
  ramctl.sh weblogic start-full OBDX obdx_server1

  ramctl.sh db status DATABASE_NAME
  ramctl.sh db start DATABASE_NAME
  ramctl.sh db stop DATABASE_NAME

  ramctl.sh rman backup DATABASE_NAME
  ramctl.sh rman list DATABASE_NAME
  ramctl.sh rman validate DATABASE_NAME latest
  ramctl.sh rman restore DATABASE_NAME /backup/catalog_dir /backup/controlfile.bkp --yes-i-understand

  ramctl.sh clone pdb DATABASE_NAME FC145ODT1 FC145ODT1_0306BK
EOF
}

module="${1:-}"
if [[ -z "$module" || "$module" == "-h" || "$module" == "--help" ]]; then
  usage
  exit 0
fi
shift || true

case "$module" in
  weblogic)
    exec "$RAMCTL_HOME/modules/weblogic.sh" "$@"
    ;;
  db)
    exec "$RAMCTL_HOME/modules/db.sh" "$@"
    ;;
  rman)
    exec "$RAMCTL_HOME/modules/rman.sh" "$@"
    ;;
  clone)
    exec "$RAMCTL_HOME/modules/clone.sh" "$@"
    ;;
  *)
    echo "Unknown module: $module"
    usage
    exit 2
    ;;
esac
