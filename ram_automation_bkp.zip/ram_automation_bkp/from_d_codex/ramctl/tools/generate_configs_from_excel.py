# SANITIZED PUBLICATION TEMPLATE. Not runtime-tested.
#!/usr/bin/env python3
import argparse
import re
from pathlib import Path

from openpyxl import load_workbook


PASSWORD_PATTERNS = ("pwd", "password", "login details")


def clean(value):
    if value is None:
        return ""
    return str(value).replace("\xa0", " ").strip()


def key(value):
    value = clean(value).upper()
    value = re.sub(r"[^A-Z0-9]+", "_", value)
    value = re.sub(r"_+", "_", value).strip("_")
    if not value:
        return "UNKNOWN"
    if value[0].isdigit():
        value = "T_" + value
    return value


def os_user(value):
    value = clean(value)
    if not value:
        return ""
    return re.split(r"[\s/,;:]+", value)[0]


def domain_root(value):
    value = clean(value)
    return value[:-4] if value.endswith("/bin") else value


def q(value):
    return '"' + clean(value).replace("\\", "\\\\").replace('"', '\\"') + '"'


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("xlsx", type=Path)
    parser.add_argument("--out", type=Path, default=Path("config"))
    parser.add_argument("--sheet", default=None)
    args = parser.parse_args()

    wb = load_workbook(args.xlsx, data_only=True)
    ws = wb[args.sheet] if args.sheet else wb[wb.sheetnames[0]]
    headers = [clean(cell.value) for cell in ws[1]]
    index = {name: i for i, name in enumerate(headers)}

    required = [
        "Product",
        "DB Hostname",
        "DB Server IP",
        "CDB Name",
        "PDB Name",
        "Schema Name",
        "Listener Port",
        "App Server Hostname",
        "App Server IP",
        "Domain Name",
        "Domain Listener Port",
        "Domain Listener SSL Port",
        "Console Url",
        "App Debug Path",
        "Domain Path",
        "DB Server Login Details ( Linux server )",
        "App Server Login Details ( Linux server )",
    ]
    missing = [name for name in required if name not in index]
    if missing:
        raise SystemExit(f"Missing columns: {', '.join(missing)}")

    rows = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        vals = [clean(v) for v in row]
        if not any(vals):
            continue
        if not vals[index["Product"]]:
            continue
        rows.append(vals)

    hosts = {}
    domains = []
    dbs = {}
    pdbs = []

    for vals in rows:
        product = vals[index["Product"]]
        domain_name = vals[index["Domain Name"]]
        domain_key = key(product)
        app_host = vals[index["App Server Hostname"]]
        app_ip = vals[index["App Server IP"]]
        app_user = os_user(vals[index["App Server Login Details ( Linux server )"]])
        db_host = vals[index["DB Hostname"]]
        db_ip = vals[index["DB Server IP"]]
        db_user = os_user(vals[index["DB Server Login Details ( Linux server )"]])
        cdb = vals[index["CDB Name"]]
        pdb = vals[index["PDB Name"]]
        schema = vals[index["Schema Name"]]

        if app_host:
            hosts[key(app_host)] = (app_host, app_ip, app_user, "app")
        if db_host:
            hosts[key(db_host)] = (db_host, db_ip, db_user, "db")

        domains.append(
            {
                "key": domain_key,
                "product": product,
                "host": app_host,
                "ip": app_ip,
                "os_user": app_user,
                "domain_name": domain_name,
                "domain_path": domain_root(vals[index["Domain Path"]]),
                "domain_bin": vals[index["Domain Path"]],
                "admin_port": vals[index["Domain Listener Port"]],
                "ssl_port": vals[index["Domain Listener SSL Port"]],
                "console_url": vals[index["Console Url"]],
                "app_url": vals[index["Application Login"]] if "Application Login" in index else "",
                "log_path": vals[index["App Debug Path"]],
                "managed_server": extract_managed_server(vals[index["App Debug Path"]]),
                "nodemanager_port": "",
            }
        )

        if cdb:
            dbs[key(cdb)] = {
                "host": db_host,
                "ip": db_ip,
                "os_user": db_user,
                "oracle_sid": cdb,
                "listener_port": vals[index["Listener Port"]],
            }
            pdbs.append((domain_key, product, cdb, pdb, schema))

    hosts_text = [
        "# Generated from Excel. Passwords intentionally omitted.",
        "# Format: HOST_<KEY>_<FIELD>",
        "",
    ]
    for host_key, (host, ip, user, role) in sorted(hosts.items()):
        hosts_text += [
            f"HOST_{host_key}_NAME={q(host)}",
            f"HOST_{host_key}_IP={q(ip)}",
            f"HOST_{host_key}_OS_USER={q(user)}",
            f"HOST_{host_key}_ROLE={q(role)}",
            "",
        ]

    domains_text = [
        "# Generated from Excel. Passwords intentionally omitted.",
        "# DOMAIN_*_PATH is normalized without trailing /bin.",
        "# Fill MANAGED_SERVER if blank before start-managed/start-full.",
        "",
    ]
    for item in domains:
        prefix = f"DOMAIN_{item['key']}_"
        for field in (
            "product",
            "host",
            "ip",
            "os_user",
            "domain_name",
            "domain_path",
            "domain_bin",
            "admin_port",
            "ssl_port",
            "console_url",
            "app_url",
            "log_path",
            "managed_server",
            "nodemanager_port",
        ):
            domains_text.append(f"{prefix}{field.upper()}={q(item[field])}")
        domains_text.append("")

    db_text = [
        "# Generated from Excel. Passwords intentionally omitted.",
        "# Verify ORACLE_HOME, ORACLE_BASE, BACKUP_ROOT, LOG_ROOT, and DATA_ROOT before running DB/RMAN actions.",
        "",
    ]
    for db_key, item in sorted(dbs.items()):
        prefix = f"DB_{db_key}_"
        db_text += [
            f"{prefix}HOST={q(item['host'])}",
            f"{prefix}IP={q(item['ip'])}",
            f"{prefix}OS_USER={q(item['os_user'])}",
            f"{prefix}ORACLE_SID={q(item['oracle_sid'])}",
            f"{prefix}LISTENER_PORT={q(item['listener_port'])}",
            f"{prefix}ORACLE_HOME={q('/PATH_TO_CONFIGURE')}",
            f"{prefix}ORACLE_BASE={q('/PATH_TO_CONFIGURE')}",
            f"{prefix}BACKUP_ROOT={q('/PATH_TO_CONFIGURE' + item['oracle_sid'])}",
            f"{prefix}LOG_ROOT={q('/PATH_TO_CONFIGURE')}",
            f"{prefix}DATA_ROOT={q('/PATH_TO_CONFIGURE' + item['oracle_sid'])}",
            f"{prefix}START_MODE={q('open')}",
            f"{prefix}RUN_LOCAL={q('false')}",
            "",
        ]

    pdb_text = [
        "# Generated from Excel. Passwords intentionally omitted.",
        "# PDB/schema mapping only.",
        "",
    ]
    for domain_key, product, cdb, pdb, schema in pdbs:
        prefix = f"PDB_{domain_key}_"
        pdb_text += [
            f"{prefix}PRODUCT={q(product)}",
            f"{prefix}CDB={q(cdb)}",
            f"{prefix}PDB={q(pdb)}",
            f"{prefix}SCHEMA={q(schema)}",
            "",
        ]

    write(args.out / "hosts.conf", "\n".join(hosts_text))
    write(args.out / "domains.conf", "\n".join(domains_text))
    write(args.out / "databases.conf", "\n".join(db_text))
    write(args.out / "pdbs.conf", "\n".join(pdb_text))

    print(f"Wrote {args.out / 'hosts.conf'}")
    print(f"Wrote {args.out / 'domains.conf'}")
    print(f"Wrote {args.out / 'databases.conf'}")
    print(f"Wrote {args.out / 'pdbs.conf'}")
    print(f"Domains: {len(domains)}")
    print(f"Databases: {len(dbs)}")
    print(f"Hosts: {len(hosts)}")


def extract_managed_server(log_path):
    log_path = clean(log_path)
    match = re.search(r"/servers/([^/]+)/logs", log_path)
    return match.group(1) if match else ""


if __name__ == "__main__":
    main()
