#!/usr/bin/env bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99

set -euo pipefail

usage() {
  cat <<'EOF'
Usage:
  ./obma_batch_databag_update.sh --updates updates.csv --secret-file /path/to/encrypted_data_bag_secret [--root /path/to/json/files] [--dry-run]

CSV columns:
  file,key,password,password_env

Notes:
  - file can be an absolute JSON path or relative to --root.
  - password can be left blank when password_env is set.
  - Existing JSON files are backed up as <file>.bak.<timestamp>.
  - No password values are printed.

Example:
  ./obma_batch_databag_update.sh --updates obma_batch_updates.csv --root /PATH_TO_CONFIGURE --secret-file /etc/chef/encrypted_data_bag_secret
EOF
}

updates_file=""
secret_file=""
root_dir="."
dry_run="false"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --updates)
      updates_file="${2:-}"
      shift 2
      ;;
    --secret-file)
      secret_file="SECRET_REMOVED"
      shift 2
      ;;
    --root)
      root_dir="${2:-}"
      shift 2
      ;;
    --dry-run)
      dry_run="true"
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

if [[ -z "$updates_file" || -z "$secret_file" ]]; then
  usage >&2
  exit 2
fi

if [[ ! -f "$updates_file" ]]; then
  echo "Updates CSV not found: $updates_file" >&2
  exit 1
fi

if [[ ! -f "$secret_file" ]]; then
  echo "Chef encrypted data bag secret file not found: $secret_file" >&2
  exit 1
fi

if command -v chef >/dev/null 2>&1; then
  ruby_cmd=(chef exec ruby)
elif command -v ruby >/dev/null 2>&1; then
  ruby_cmd=(ruby)
else
  echo "Neither 'chef exec ruby' nor 'ruby' was found in PATH." >&2
  exit 1
fi

export OBMA_BATCH_UPDATES="$updates_file"
export OBMA_BATCH_SECRET="SECRET_REMOVED"
export OBMA_BATCH_ROOT="$root_dir"
export OBMA_BATCH_DRY_RUN="$dry_run"

"${ruby_cmd[@]}" <<'RUBY'
require "csv"
require "fileutils"
require "json"

begin
  require "chef/encrypted_data_bag_item"
rescue LoadError => e
  abort "Unable to load Chef encryption library. Run this on the OBMA/Chef installer server. #{e.message}"
end

updates_file = ENV.fetch("OBMA_BATCH_UPDATES")
secret_file = ENV.fetch("OBMA_BATCH_SECRET")
root_dir = ENV.fetch("OBMA_BATCH_ROOT")
dry_run = ENV.fetch("OBMA_BATCH_DRY_RUN") == "true"

secret = Chef::EncryptedDataBagItem.load_secret(secret_file)
rows = CSV.read(updates_file, headers: true)

required = %w[file key]
missing = required.reject { |name| rows.headers&.include?(name) }
abort "CSV missing required columns: #{missing.join(", ")}" unless missing.empty?

updates_by_file = Hash.new { |hash, key| hash[key] = [] }

rows.each_with_index do |row, index|
  line_no = index + 2
  file = row["file"].to_s.strip
  key = row["key"].to_s.strip
  password = row["password"].to_s
  password_env = row["password_env"].to_s.strip

  abort "Line #{line_no}: file is blank" if file.empty?
  abort "Line #{line_no}: key is blank" if key.empty?

  if password.empty? && !password_env.empty?
    abort "Line #{line_no}: environment variable #{password_env} is not set" unless ENV.key?(password_env)
    password = ENV.fetch(password_env)
  end

  abort "Line #{line_no}: password is blank; set password or password_env" if password.empty?

  path = File.absolute_path(file.start_with?("/") ? file : File.join(root_dir, file))
  updates_by_file[path] << [key, password, line_no]
end

timestamp = Time.now.strftime("%Y%m%d%H%M%S")

updates_by_file.each do |path, updates|
  abort "Data bag JSON not found: #{path}" unless File.file?(path)

  encrypted_item = JSON.parse(File.read(path))
  plain_item = Chef::EncryptedDataBagItem.new(encrypted_item, secret).to_hash

  updates.each do |key, password, line_no|
    abort "Line #{line_no}: key '#{key}' does not exist in #{path}" unless plain_item.key?(key)
    plain_item[key] = password
  end

  updated_item = Chef::EncryptedDataBagItem.encrypt_data_bag_item(plain_item, secret)

  puts "#{dry_run ? "Would update" : "Updating"} #{path}: #{updates.map(&:first).join(", ")}"

  next if dry_run

  backup = "#{path}.bak.#{timestamp}"
  FileUtils.cp(path, backup)
  File.write(path, JSON.pretty_generate(updated_item) + "\n")

  # Verify the rewritten item can be decrypted with the same secret.
  verify_item = JSON.parse(File.read(path))
  Chef::EncryptedDataBagItem.new(verify_item, secret).to_hash
  puts "Backup: #{backup}"
end
RUBY
