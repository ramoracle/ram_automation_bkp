throw "Disabled publication template: configure and review before execution."
param(
    [Parameter(Mandatory=$true)][string]$HostName,
    [Parameter(Mandatory=$true)][string]$User,
    [Parameter(Mandatory=$true)][string]$Domain,
    [Parameter(Mandatory=$true)]
    [ValidateSet("status","start_full","start_nodemanager","start_admin","start_managed","stop_admin","stop_managed","logs","fix_startup")]
    [string]$Action,
    [string]$ServerName = "",
    [string]$AdminUrl = "",
    [int]$TailLines = 120,
    [string]$SshOptions = "",
    [string]$KeyFile = "$env:USERPROFILE\.ssh\codex_ram_weblogic_ed25519",
    [switch]$AllowStop,
    [switch]$DryRun
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Convert-ToT3Url {
    param([string]$Url)
    if ([string]::IsNullOrWhiteSpace($Url)) {
        return ""
    }

    $clean = $Url.Trim()
    $clean = $clean -replace "/console/?$", ""
    $clean = $clean -replace "^http/PATH_TO_CONFIGURE", "t3/PATH_TO_CONFIGURE"
    $clean = $clean -replace "^htt/PATH_TO_CONFIGURE", "t3://"
    return $clean
}

function Quote-Sh {
    param([string]$Value)
    return "'" + ($Value -replace "'", "'\''") + "'"
}

if ($Action -eq "start_managed" -and [string]::IsNullOrWhiteSpace($ServerName)) {
    throw "ServerName is required for start_managed."
}

if ($Action -eq "start_full" -and [string]::IsNullOrWhiteSpace($ServerName)) {
    throw "ServerName is required for start_full."
}

if (($Action -eq "start_managed" -or $Action -eq "start_full" -or $Action -eq "stop_managed") -and [string]::IsNullOrWhiteSpace($AdminUrl)) {
    throw "AdminUrl is required for $Action. Example: t3://hostname:PORT"
}

if (($Action -eq "stop_admin" -or $Action -eq "stop_managed") -and -not $AllowStop) {
    throw "$Action requires -AllowStop because it stops a WebLogic server."
}

$target = "$User@$HostName"
$domainQ = Quote-Sh $Domain
$serverQ = Quote-Sh $ServerName
$adminQ = Quote-Sh (Convert-ToT3Url $AdminUrl)
$tailQ = $TailLines

$remoteScript = @"
set -u
DOMAIN=$domainQ
SERVER=$serverQ
ADMIN_URL=$adminQ
TAIL_LINES=$tailQ

echo "===== RAM WebLogic SSH Runner ====="
echo "Host        : `$(hostname -f 2>/dev/null || hostname)"
echo "User        : `$(whoami)"
echo "Domain      : `$DOMAIN"
echo "Action      : $Action"
echo "Server      : `$SERVER"
echo "Admin URL   : `$ADMIN_URL"
echo

if [ ! -d "`$DOMAIN" ]; then
  echo "ERROR: Domain path not found: `$DOMAIN"
  exit 2
fi

server_logs() {
  find "`$DOMAIN/servers" -path "*/logs/*.log" -type f \
    ! -name "access.log" \
    ! -name "*access*.log" \
    ! -name "*.out" 2>/dev/null
}

show_recent_states() {
  server_logs | xargs grep -iE "BEA-000365|Server state changed|RUNNING|ADMIN|FAILED|ModuleException|DeploymentException|Critical|Emergency|Caused By|Caused by|Exception|Error" 2>/dev/null | tail -"`$TAIL_LINES" || true
}

start_nodemanager() {
  if ps -ef | grep -v grep | grep -q "[w]eblogic.NodeManager.*`$DOMAIN"; then
    echo "NodeManager already appears to be running for `$DOMAIN."
    return 0
  fi
  cd "`$DOMAIN/bin"
  OUT="nodemanager_start_`$(date +%Y%m%d_%H%M%S).out"
  echo "Starting NodeManager. Output: `$DOMAIN/bin/`$OUT"
  nohup ./startNodeManager.sh > "`$OUT" 2>&1 &
  sleep 10
  tail -120 "`$DOMAIN/nodemanager/nodemanager.log" 2>/dev/null || tail -120 "`$OUT"
}

start_admin() {
  if ps -ef | grep -v grep | grep -q "[D]weblogic.Name=AdminServer"; then
    echo "AdminServer process already appears to be running."
    return 0
  fi
  cd "`$DOMAIN/bin"
  OUT="admin_start_`$(date +%Y%m%d_%H%M%S).out"
  echo "Starting AdminServer. Output: `$DOMAIN/bin/`$OUT"
  nohup ./startWebLogic.sh > "`$OUT" 2>&1 &
  sleep 15
  tail -160 "`$DOMAIN/servers/AdminServer/logs/AdminServer.log" 2>/dev/null || tail -160 "`$OUT"
}

start_managed() {
  if [ -z "`$SERVER" ]; then
    echo "ERROR: SERVER is required."
    exit 3
  fi
  if ps -ef | grep -v grep | grep -q "[D]weblogic.Name=`$SERVER"; then
    echo "`$SERVER process already appears to be running."
    return 0
  fi
  cd "`$DOMAIN/bin"
  OUT="`$SERVER`_start_`$(date +%Y%m%d_%H%M%S).out"
  echo "Starting managed server `$SERVER with `$ADMIN_URL. Output: `$DOMAIN/bin/`$OUT"
  nohup ./startManagedWebLogic.sh "`$SERVER" "`$ADMIN_URL" > "`$OUT" 2>&1 &
  sleep 15
  tail -160 "`$DOMAIN/servers/`$SERVER/logs/`$SERVER.log" 2>/dev/null || tail -160 "`$OUT"
}

case "$Action" in
  status)
    echo "===== Processes ====="
    ps -ef | egrep "weblogic.Server|NodeManager|httpd|ohs" | grep -v grep || true
    echo
    echo "===== Ports ====="
    netstat -tulnp 2>/dev/null | egrep "7001|7002|7301|7302|7601|7602|9001|9002|9901|9902|5556|5558" || true
    echo
    echo "===== Recent server states ====="
    server_logs | xargs grep -iE "Server state changed|RUNNING|ADMIN|FAILED|BEA-000365" 2>/dev/null | tail -80 || true
    ;;

  logs|fix_startup)
    echo "===== Domain checks ====="
    ls -ld "`$DOMAIN" "`$DOMAIN/bin" "`$DOMAIN/config" "`$DOMAIN/servers" 2>/dev/null || true
    ls -l "`$DOMAIN/config/config.xml" 2>/dev/null || true
    echo
    echo "===== Recent errors/states ====="
    show_recent_states
    if [ -n "`$SERVER" ] && [ -f "`$DOMAIN/servers/`$SERVER/logs/`$SERVER.log" ]; then
      echo
      echo "===== Tail `$SERVER.log ====="
      tail -`$TAIL_LINES "`$DOMAIN/servers/`$SERVER/logs/`$SERVER.log"
    fi
    ;;

  start_full)
    start_nodemanager
    start_admin
    start_managed
    echo
    echo "===== Final state summary ====="
    ps -ef | egrep "weblogic.Name=AdminServer|weblogic.Name=`$SERVER|NodeManager" | grep -v grep || true
    show_recent_states
    ;;

  start_nodemanager)
    start_nodemanager
    ;;

  start_admin)
    start_admin
    ;;

  start_managed)
    start_managed
    ;;

  stop_admin)
    cd "`$DOMAIN/bin"
    echo "Stopping AdminServer with stopWebLogic.sh"
    ./stopWebLogic.sh
    ;;

  stop_managed)
    if [ -z "`$SERVER" ]; then
      echo "ERROR: SERVER is required."
      exit 3
    fi
    cd "`$DOMAIN/bin"
    echo "Stopping managed server `$SERVER with stopManagedWebLogic.sh"
    ./stopManagedWebLogic.sh "`$SERVER" "`$ADMIN_URL"
    ;;
esac
"@

Write-Host "Target: $target"
Write-Host "Action: $Action"
Write-Host "Domain: $Domain"
if ($DryRun) {
    Write-Host "===== Remote script ====="
    Write-Output $remoteScript
    exit 0
}

$ssh = Get-Command ssh -ErrorAction SilentlyContinue
if (-not $ssh) {
    throw "ssh command not found on this Windows machine. Install/enable OpenSSH Client first."
}

$sshArgs = @(
    "-i", $KeyFile,
    "-o", "Ciphers=aes256-ctr,aes128-ctr",
    "-o", "MACs=hmac-sha2-256,hmac-sha2-512",
    "-o", "IPQoS=none",
    "-o", "ServerAliveInterval=30",
    "-o", "ServerAliveCountMax=3"
)

if (-not [string]::IsNullOrWhiteSpace($SshOptions)) {
    $sshArgs += $SshOptions.Split(" ", [System.StringSplitOptions]::RemoveEmptyEntries)
}

$sshArgs += @($target, "tr -d '\015' | bash -s")
$remoteScript | & $ssh.Source @sshArgs
exit $LASTEXITCODE
