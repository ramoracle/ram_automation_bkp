#!/usr/bin/env bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99

# Deploy the FCINT-3 Java EE libraries shown in the WebLogic Libraries console.
# Confirmed FCINT-3 settings: Admin URL t3://hostname:PORT and WL_HOME /PATH_TO_CONFIGURE
#
# Required:
#   export ADMIN_URL='t3://<admin-host>:<admin-port>'
# Optional credential methods:
#   export WL_USER='weblogic'; export WL_PASSWORD='SECRET_REMOVED'
#   or export WL_USERCONFIG='/secure/path/userconfig.secure'
#      and export WL_USERKEY='/secure/path/userkey.secure'
#
# The library archives must be placed in APP_DIR. Override APP_DIR when needed.

set -uo pipefail

DOMAIN_HOME="${DOMAIN_HOME:-/PATH_TO_CONFIGURE}"
JAVA_HOME="${JAVA_HOME:-/PATH_TO_CONFIGURE}"
WL_HOME="${WL_HOME:-/PATH_TO_CONFIGURE}"
APP_DIR="${APP_DIR:-${DOMAIN_HOME}/deployment-services/odt9}"
ADMIN_URL="${ADMIN_URL:-t3://hostname:PORT}"
WL_USER="${WL_USER:-weblogic}"
WL_PASSWORD="SECRET_REMOVED"
WL_USERCONFIG="${WL_USERCONFIG:-}"
WL_USERKEY="${WL_USERKEY:-}"
DEPLOY_MODE="${DEPLOY_MODE:-deploy}"
SLEEP_SECONDS="${SLEEP_SECONDS:-15}"
LOG_FILE="${LOG_FILE:-${DOMAIN_HOME}/deployment-services/logs/odt9-library-deploy-$(date +%Y%m%d-%H%M%S).log}"

export JAVA_HOME
export PATH="${JAVA_HOME}/bin:${PATH}"

if [[ -n "${WL_HOME}" ]]; then
  WEBLOGIC_JAR="${WL_HOME}/server/lib/weblogic.jar"
else
  WEBLOGIC_JAR="$(find /PATH_TO_CONFIGURE -type f -path '*/server/lib/weblogic.jar' -print -quit 2>/dev/null || true)"
fi

if [[ -z "${WEBLOGIC_JAR}" || ! -r "${WEBLOGIC_JAR}" ]]; then
  echo "ERROR: weblogic.jar was not found under /PATH_TO_CONFIGURE Set WL_HOME explicitly." >&2
  exit 2
fi

WL_HOME="${WEBLOGIC_JAR%/server/lib/weblogic.jar}"
export CLASSPATH="${WEBLOGIC_JAR}${CLASSPATH:+:${CLASSPATH}}"

if [[ ! -x "${JAVA_HOME}/bin/java" ]]; then
  echo "ERROR: Java executable not found: ${JAVA_HOME}/bin/java" >&2
  exit 2
fi

if [[ ! -d "${APP_DIR}" ]]; then
  echo "ERROR: Library artifact directory not found: ${APP_DIR}" >&2
  exit 2
fi

if [[ "${DEPLOY_MODE}" != "deploy" && "${DEPLOY_MODE}" != "redeploy" ]]; then
  echo "ERROR: DEPLOY_MODE must be deploy or redeploy" >&2
  exit 2
fi

mkdir -p "$(dirname "${LOG_FILE}")"
touch "${LOG_FILE}"
chmod 600 "${LOG_FILE}"

if [[ -n "${WL_USERCONFIG}" && -n "${WL_USERKEY}" ]]; then
  AUTH_ARGS=(-userconfig "${WL_USERCONFIG}" -userkey "${WL_USERKEY}")
else
  if [[ -z "${WL_PASSWORD}" ]]; then
    read -r -s -p "WebLogic password for ${WL_USER}: " WL_PASSWORD
    printf '\n'
  fi
  AUTH_ARGS=(-user "${WL_USER}" -password "${WL_PASSWORD}")
fi

log() {
  printf '%s | %s\n' "$(date '+%F %T')" "$*" | tee -a "${LOG_FILE}"
}

resolve_artifact() {
  local expected_name="$1"
  local candidate

  for candidate in \
    "${APP_DIR}/${expected_name}" \
    "${APP_DIR}/${expected_name}.jar" \
    "${APP_DIR}/${expected_name}.war" \
    "${APP_DIR}/${expected_name}.ear"; do
    if [[ -f "${candidate}" || -d "${candidate}" ]]; then
      printf '%s\n' "${candidate}"
      return 0
    fi
  done

  return 1
}

deploy_library() {
  local library_name="$1"
  local artifact_name="$2"
  local target="$3"
  local artifact deploy_log rc

  artifact="$(resolve_artifact "${artifact_name}")" || {
    log "MISSING: ${artifact_name}[.jar|.war|.ear] under ${APP_DIR}"
    return 1
  }

  deploy_log="$(mktemp /tmp/deploy_odt9_library.XXXXXX)"
  log "Deploying library ${library_name} from ${artifact} to ${target}"

  if [[ "${DEPLOY_MODE}" == "redeploy" ]]; then
    "${JAVA_HOME}/bin/java" weblogic.Deployer \
      -adminurl "${ADMIN_URL}" "${AUTH_ARGS[@]}" \
      -name "${library_name}" -targets "${target}" \
      -redeploy -source "${artifact}" -library -remote -upload >"${deploy_log}" 2>&1
  else
    "${JAVA_HOME}/bin/java" weblogic.Deployer \
      -adminurl "${ADMIN_URL}" "${AUTH_ARGS[@]}" \
      -name "${library_name}" -targets "${target}" \
      -deploy -source "${artifact}" -library -remote -upload >"${deploy_log}" 2>&1
  fi
  rc=$?
  sed 's/-password [^ ]*/-password ********/g' "${deploy_log}" >> "${LOG_FILE}"

  if [[ ${rc} -eq 0 ]]; then
    if grep -qi 'Deployment is deferred' "${deploy_log}"; then
      log "DEFERRED: ${library_name} to ${target}"
    else
      log "SUCCESS: ${library_name} to ${target}"
    fi
  else
    log "FAILED: ${library_name} to ${target}; rc=${rc}"
  fi

  rm -f "${deploy_log}"
  sleep "${SLEEP_SECONDS}"
  return "${rc}"
}

failures=0
log "STARTED ODT9 library deployment; domain=${DOMAIN_HOME}; app_dir=${APP_DIR}; mode=${DEPLOY_MODE}"

deploy_library "ExtAdapter#1.0@1.0" "ExtAdapter.ear" "FCServer_1,Plato" || failures=$((failures + 1))
deploy_library "FCJExtPricing" "FCJExtPricing.ear" "FCServer_1" || failures=$((failures + 1))
deploy_library "OBCLExtAdapter#1.0@1.0" "OBCLExtAdapter.ear" "FCServer_1" || failures=$((failures + 1))
deploy_library "OBTFExtAdapter" "OBTFExtAdapter.ear" "FCServer_1" || failures=$((failures + 1))
deploy_library "OBTFExtPricing" "OBTFExtPricing.ear" "FCServer_1" || failures=$((failures + 1))
deploy_library "OBTRExtAdapter" "OBTRExtAdapter.ear" "FCServer_1" || failures=$((failures + 1))
deploy_library "OBTRExtPricing" "OBTRExtPricing.ear" "FCServer_1" || failures=$((failures + 1))
deploy_library "jax-rs#2.0@2.29.0" "jax-rs-2.0" "FCServer_1,Plato,Plato_1" || failures=$((failures + 1))

log "COMPLETED ODT9 library deployment; failures=${failures}"
exit "${failures}"
