# SANITIZED PUBLICATION TEMPLATE. Not runtime-tested.
# WLST template for replacing WebLogic demo identity/trust with custom SSL.
# Edit all CHANGE_* values before running on the OAS/WebLogic server.

admin_url = 't3://hostname:PORT'
admin_user = 'CHANGE_WEBLOGIC_ADMIN_USER'
admin_password = 'SECRET_REMOVED'

identity_keystore = '/PATH_TO_CONFIGURE'
identity_keystore_type = 'JKS'
identity_keystore_passphrase = 'SECRET_REMOVED'

trust_keystore = '/PATH_TO_CONFIGURE'
trust_keystore_type = 'JKS'
trust_keystore_passphrase = 'SECRET_REMOVED'

private_key_alias = 'oasenv1_identity'
private_key_passphrase = 'SECRET_REMOVED'

# Add managed servers here if this domain has them and they also use SSL.
servers_to_update = [
    'AdminServer',
]

connect(admin_user, admin_password, admin_url)

edit()
startEdit()

for server_name in servers_to_update:
    cd('/Servers/' + server_name)
    cmo.setKeyStores('CustomIdentityAndCustomTrust')
    cmo.setCustomIdentityKeyStoreFileName(identity_keystore)
    cmo.setCustomIdentityKeyStoreType(identity_keystore_type)
    cmo.setCustomIdentityKeyStorePassPhrase(identity_keystore_passphrase)
    cmo.setCustomTrustKeyStoreFileName(trust_keystore)
    cmo.setCustomTrustKeyStoreType(trust_keystore_type)
    cmo.setCustomTrustKeyStorePassPhrase(trust_keystore_passphrase)

    cd('/Servers/' + server_name + '/SSL/' + server_name)
    cmo.setServerPrivateKeyAlias(private_key_alias)
    cmo.setServerPrivateKeyPassPhrase(private_key_passphrase)

save()
activate(block='true')
disconnect()

print('Configured custom identity and trust keystores. Restart affected servers.')
