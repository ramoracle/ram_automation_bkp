#!/usr/bin/env bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99


set -uo pipefail

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${BASE_DIR}/weblogic_easy_wizard.conf"
SCRIPT_ROOT="${BASE_DIR}"
LOG_DIR="${BASE_DIR}/logs"
SELF_NAME="$(basename "$0")"

if [[ -f "${CONFIG_FILE}" ]]; then
  # shellcheck disable=SC1090
  source "${CONFIG_FILE}"
fi

mkdir -p "${LOG_DIR}"

header() {
  clear
  echo "============================================================"
  echo "          WebLogic Easy Deployment Wizard"
  echo "============================================================"
  echo "Scripts : ${SCRIPT_ROOT}"
  echo "Logs    : ${LOG_DIR}"
  echo
}

pause() {
  echo
  read -r -p "Press Enter to continue..." _
}

is_domain_script() {
  local file lower
  file="$(basename "$1")"
  lower="$(echo "$file" | tr '[:upper:]' '[:lower:]')"

  [[ "$file" == "$SELF_NAME" ]] && return 1
  [[ "$lower" == "weblogic_menu.sh" ]] && return 1
  [[ "$lower" == "weblogic_ui_server.py" ]] && return 1
  [[ "$lower" == *"start"* ]] && return 1
  [[ "$lower" == *"stop"* ]] && return 1
  [[ "$lower" == *"undeploy"* ]] && return 1
  [[ "$lower" == *"wizard"* ]] && return 1
  return 0
}

collect_domain_scripts() {
  local file
  while IFS= read -r file; do
    is_domain_script "$file" || continue
    printf "%s\n" "$file"
  done < <(find "${SCRIPT_ROOT}" -maxdepth 1 -type f -name "*.sh" | sort)
}

choose_domain_script() {
  local selection idx
  local -a scripts=()

  mapfile -t scripts < <(collect_domain_scripts)
  if [[ "${#scripts[@]}" -eq 0 ]]; then
    echo "No domain deployment scripts found in ${SCRIPT_ROOT}" >&2
    return 1
  fi

  echo "Choose domain script" >&2
  echo "------------------------------------------------------------" >&2
  for idx in "${!scripts[@]}"; do
    printf "%2d. %s\n" "$((idx + 1))" "$(basename "${scripts[$idx]}")" >&2
  done
  echo " 0. Cancel" >&2
  echo >&2
  read -r -p "Enter number: " selection

  [[ "$selection" == "0" ]] && return 1

  if ! [[ "$selection" =~ ^[0-9]+$ ]] || (( selection < 1 || selection > ${#scripts[@]} )); then
    echo "Invalid selection." >&2
    return 1
  fi

  SELECTED_SCRIPT="${scripts[$((selection - 1))]}"
  return 0
}

show_versions() {
  local script_path="$1"

  header
  echo "Domain script : $(basename "$script_path")"
  echo "------------------------------------------------------------"
  python3 - "$script_path" <<'PY'
import re
import sys
from collections import Counter

path = sys.argv[1]
text = open(path, encoding="utf-8", errors="ignore").read()
versions = re.findall(r'-([0-9]+\.[0-9]+\.[0-9]+)(?:\.war)?', text)
counter = Counter(versions)

if not counter:
    print("No WAR versions detected.")
else:
    print("Detected versions:")
    for version, count in sorted(counter.items()):
        print("  {}  ({} references)".format(version, count))
PY
}

update_versions() {
  local script_path="$1"
  local new_version backup_path

  header
  echo "Update WAR version"
  echo "------------------------------------------------------------"
  echo "Script : ${script_path}"
  echo
  read -r -p "Enter new version (example 6.41.0): " new_version

  if ! [[ "$new_version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    echo "Invalid version format."
    pause
    return
  fi

  backup_path="${script_path}.bak_$(date +%Y%m%d_%H%M%S)"
  cp "$script_path" "$backup_path"

  python3 - "$script_path" "$new_version" <<'PY'
import re
import sys

path = sys.argv[1]
new_version = sys.argv[2]

with open(path, encoding="utf-8", errors="ignore") as fh:
    text = fh.read()

text = re.sub(
    r'(-name\s+\S*?)-[0-9]+\.[0-9]+\.[0-9]+(\.war)?',
    lambda m: "{}-{}{}".format(m.group(1), new_version, m.group(2) or ""),
    text,
)
text = re.sub(
    r'([A-Za-z0-9_.-]+)-[0-9]+\.[0-9]+\.[0-9]+\.war',
    lambda m: "{}-{}.war".format(m.group(1), new_version),
    text,
)

with open(path, "w", encoding="utf-8") as fh:
    fh.write(text)
PY

  echo
  echo "Updated version to ${new_version}"
  echo "Backup created: ${backup_path}"
  pause
}

run_deploy() {
  local script_path="$1"
  local log_file
  log_file="${LOG_DIR}/$(basename "${script_path%.sh}")_$(date +%Y%m%d_%H%M%S).log"

  header
  echo "Deploy domain"
  echo "------------------------------------------------------------"
  echo "Script : ${script_path}"
  echo "Log    : ${log_file}"
  echo
  read -r -p "Run this script now? (y/n): " answer
  [[ "${answer:-n}" =~ ^[Yy]$ ]] || return

  (
    cd "$(dirname "$script_path")" || exit 1
    bash "$script_path"
  ) 2>&1 | tee "$log_file"

  echo
  echo "Finished. Check log: ${log_file}"
  pause
}

view_script() {
  local script_path="$1"
  header
  echo "View script"
  echo "------------------------------------------------------------"
  sed -n '1,220p' "$script_path"
  pause
}

domain_actions() {
  local script_path="$1"
  local choice

  while true; do
    header
    echo "Selected domain script: $(basename "$script_path")"
    echo
    echo "1. Deploy this domain"
    echo "2. Show current WAR versions"
    echo "3. Update to new WAR version automatically"
    echo "4. View script"
    echo "0. Back"
    echo
    read -r -p "Enter choice: " choice

    case "$choice" in
      1) run_deploy "$script_path" ;;
      2) show_versions "$script_path"; pause ;;
      3) update_versions "$script_path" ;;
      4) view_script "$script_path" ;;
      0) return ;;
      *) echo "Invalid option."; pause ;;
    esac
  done
}

main() {
  local script_path choice

  while true; do
    header
    echo "1. Choose domain"
    echo "2. Exit"
    echo
    read -r -p "Enter choice: " choice

    case "$choice" in
      1)
        header
        SELECTED_SCRIPT=""
        choose_domain_script || { pause; continue; }
        script_path="${SELECTED_SCRIPT}"
        domain_actions "$script_path"
        ;;
      2)
        exit 0
        ;;
      *)
        echo "Invalid option."
        pause
        ;;
    esac
  done
}

main
