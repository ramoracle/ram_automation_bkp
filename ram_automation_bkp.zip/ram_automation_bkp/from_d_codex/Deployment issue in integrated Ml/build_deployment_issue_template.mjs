// SANITIZED PUBLICATION TEMPLATE. Not runtime-tested.
import fs from "node:fs/promises";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const outputDir = "/PATH_TO_CONFIGURE";
const outputPath = `${outputDir}/Deployment issue in integrated Ml populated.xlsx`;
const previewPath = `${outputDir}/Deployment issue in integrated Ml populated preview.png`;

await fs.mkdir(outputDir, { recursive: true });

const workbook = Workbook.create();
const sheet = workbook.worksheets.add("Deployment Issues");
const issueRows = [
  [
    "DEP-001",
    "DATABASE_NAME",
    "Open",
    "Demo identity/trust certificate warning; replace with CA-signed cert.",
    "Review if same certificate policy applies.",
    "Review if same certificate policy applies.",
    "Review if same certificate policy applies.",
  ],
  [
    "DEP-002",
    "DATABASE_NAME Node Manager",
    "In Progress",
    "Hostname verification failed; certificate SAN mismatch needs permanent fix.",
    "Validate Node Manager cert SAN.",
    "Validate Node Manager cert SAN.",
    "Validate Node Manager cert SAN.",
  ],
  [
    "DEP-003",
    "IPMENV1",
    "Open",
    "Java Standard Trust passphrase issue; set cacerts passphrase and restart.",
    "Check trust store setup.",
    "Check trust store setup.",
    "Check trust store setup.",
  ],
  [
    "DEP-004",
    "IPM Imaging",
    "Open",
    "Imaging start failed due missing keystore path; correct .jks reference.",
    "Verify imaging keystore path.",
    "Verify imaging keystore path.",
    "Verify imaging keystore path.",
  ],
  [
    "DEP-005",
    "UCM / DAV",
    "Fixed",
    "Use UCM port 16200 for DAV validation; avoid IBR port 16250.",
    "Use correct DAV endpoint.",
    "Use correct DAV endpoint.",
    "Use correct DAV endpoint.",
  ],
  [
    "DEP-006",
    "DATABASE_NAME",
    "Fixed",
    "ORA-12541 listener issue; start listener and register service.",
    "Confirm listener status.",
    "Confirm listener status.",
    "Confirm listener status.",
  ],
  [
    "DEP-007",
    "Oracle 19c Setup",
    "Fixed",
    "SP2-0734 occurs when sqlplus is run inside SQL prompt; exit to shell.",
    "Operator note.",
    "Operator note.",
    "Operator note.",
  ],
  [
    "DEP-008",
    "Oracle OPatch",
    "Fixed",
    "Run OPatch as Oracle owner USERNAME, not root.",
    "Patch process note.",
    "Patch process note.",
    "Patch process note.",
  ],
  [
    "DEP-009",
    "ramctl / OBCLPM",
    "Open",
    "Windows runner failed with WinError 193; invoke script through Bash/WSL/SSH.",
    "Runner execution check.",
    "Runner execution check.",
    "Runner execution check.",
  ],
  [
    "DEP-010",
    "OBDX May 2026",
    "Open",
    "Remove default WebLogic admin password from deployment script and rotate if real.",
    "Credential hygiene check.",
    "Credential hygiene check.",
    "Credential hygiene check.",
  ],
];

sheet.showGridLines = false;

sheet.getRange("A1:G1").merge();
sheet.getRange("A1").values = [["Integrated ML Deployment Issue Tracker"]];
sheet.getRange("A1:G1").format = {
  fill: "#1F4E79",
  font: { bold: true, color: "#FFFFFF", size: 16 },
  horizontalAlignment: "left",
  verticalAlignment: "middle",
};
sheet.getRange("A1:G1").format.rowHeight = 34;

sheet.getRange("A2:G2").merge();
sheet.getRange("A2").values = [[
  "Use one row per bug. Update Bug Status from the dropdown and add release-wise notes under each version.",
]];
sheet.getRange("A2:G2").format = {
  fill: "#F8FAFC",
  font: { color: "#475569", italic: true },
  horizontalAlignment: "left",
  verticalAlignment: "middle",
};
sheet.getRange("A2:G2").format.rowHeight = 24;

sheet.getRange("A4:G4").values = [[
  "Bug ID",
  "Product Name",
  "Bug Status",
  "14.8.0.2.0",
  "14.7.0.10.0",
  "14.6.0.12.0",
  "14.5.0.16.0",
]];

sheet.getRange("A5:G14").values = issueRows;

sheet.getRange("A4:G4").format = {
  fill: "#0F766E",
  font: { bold: true, color: "#FFFFFF" },
  horizontalAlignment: "center",
  verticalAlignment: "middle",
};
sheet.getRange("A4:G4").format.rowHeight = 26;

sheet.getRange("A4:G14").format.borders = {
  preset: "all",
  style: "thin",
  color: "#CBD5E1",
};

sheet.getRange("A5:G14").format = {
  fill: "#FFFFFF",
  font: { color: "#111827" },
  verticalAlignment: "middle",
  wrapText: true,
};

for (let row = 5; row <= 14; row += 1) {
  const fill = row % 2 === 0 ? "#F8FAFC" : "#FFFFFF";
  sheet.getRange(`A${row}:G${row}`).format.fill = fill;
}

sheet.getRange("D5:G14").format.fill = "#FBFDFF";
sheet.getRange("A:A").format.columnWidth = 18;
sheet.getRange("B:B").format.columnWidth = 28;
sheet.getRange("C:C").format.columnWidth = 18;
sheet.getRange("D:G").format.columnWidth = 34;
sheet.getRange("C5:C14").dataValidation = {
  rule: { type: "list", values: ["Open", "In Progress", "Fixed", "Retest", "Closed"] },
};
sheet.getRange("A5:G14").format.rowHeight = 46;
sheet.freezePanes.freezeRows(4);
sheet.freezePanes.freezeColumns(3);

sheet.getRange("C5:C14").conditionalFormats.add("containsText", {
  text: "Open",
  format: { fill: "#FEE2E2", font: { bold: true, color: "#B91C1C" } },
});
sheet.getRange("C5:C14").conditionalFormats.add("containsText", {
  text: "In Progress",
  format: { fill: "#DBEAFE", font: { bold: true, color: "#1D4ED8" } },
});
sheet.getRange("C5:C14").conditionalFormats.add("containsText", {
  text: "Fixed",
  format: { fill: "#DCFCE7", font: { bold: true, color: "#15803D" } },
});
sheet.getRange("C5:C14").conditionalFormats.add("containsText", {
  text: "Retest",
  format: { fill: "#FEF3C7", font: { bold: true, color: "#B45309" } },
});
sheet.getRange("C5:C14").conditionalFormats.add("containsText", {
  text: "Closed",
  format: { fill: "#E5E7EB", font: { bold: true, color: "#374151" } },
});

sheet.tables.add("A4:G14", true, "DeploymentIssueIntegratedMl");

const check = await workbook.inspect({
  kind: "table",
  range: "Deployment Issues!A1:G14",
  include: "values,formulas",
  tableMaxRows: 14,
  tableMaxCols: 7,
  maxChars: 3000,
});
console.log(check.ndjson);

const errors = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 50 },
  summary: "final formula error scan",
  maxChars: 1000,
});
console.log(errors.ndjson);

const preview = await workbook.render({
  sheetName: "Deployment Issues",
  autoCrop: "all",
  scale: 2,
  format: "png",
});
await fs.writeFile(previewPath, new Uint8Array(await preview.arrayBuffer()));

const xlsx = await SpreadsheetFile.exportXlsx(workbook);
await xlsx.save(outputPath);
console.log(outputPath);
