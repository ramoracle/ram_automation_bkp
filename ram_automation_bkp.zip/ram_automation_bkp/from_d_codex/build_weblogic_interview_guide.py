# SANITIZED PUBLICATION TEMPLATE. Not runtime-tested.
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT

OUT = r"/PATH_TO_CONFIGURE"
IMAGE = r"/PATH_TO_CONFIGURE"

qa = [
    ("What is WebLogic Server?", "A Java application server. It runs Java web applications.", None),
    ("What is a domain?", "A domain is the main WebLogic environment. It contains servers, applications, and settings.", None),
    ("What is AdminServer?", "AdminServer manages the WebLogic domain and Managed Servers.", None),
    ("What is a Managed Server?", "It runs deployed applications for users.", None),
    ("How do you start AdminServer?", "Run this command from the domain bin folder.", "cd $DOMAIN_HOME/bin\n./startWebLogic.sh"),
    ("How do you start a Managed Server?", "Use the Managed Server name and AdminServer URL.", "cd $DOMAIN_HOME/bin\n./startManagedWebLogic.sh Server1 htt/PATH_TO_CONFIGURE"),
    ("How do you stop WebLogic?", "Use the stop script or stop it from the Admin Console.", "./stopWebLogic.sh"),
    ("What is Node Manager?", "Node Manager starts, stops, and monitors WebLogic servers remotely.", None),
    ("How do you start Node Manager?", "Run the Node Manager start script.", "cd $WL_HOME/server/bin\n./startNodeManager.sh"),
    ("What is a cluster?", "A cluster is a group of Managed Servers. It gives high availability and load balancing.", None),
    ("What is a data source?", "A data source is a database connection pool used by an application.", None),
    ("How do you check server logs?", "Open the Managed Server log and watch new messages.", "cd $DOMAIN_HOME/servers/Server1/logs\ntail -f Server1.log"),
    ("How do you check whether WebLogic is running?", "Check the running Java processes.", "ps -ef | grep weblogic"),
    ("How do you check the WebLogic port?", "Check the listening port. Example: 7001.", "netstat -an | grep 7001"),
    ("What is deployment?", "Deployment means installing an application such as a .war or .ear file in WebLogic.", None),
    ("What is a WAR file?", "A WAR file contains a web application.", None),
    ("What is an EAR file?", "An EAR file contains a full enterprise Java application.", None),
    ("What do you do when a Managed Server is down?", "Check logs, disk space, memory, and Node Manager. Then restart the server safely.", None),
    ("How do you check disk space?", "Use this command.", "df -h"),
    ("How do you check memory?", "Use this command.", "free -m"),
]

def set_font(run, name="Aptos", size=11, bold=False, color=None):
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:ascii"), name)
    run._element.rPr.rFonts.set(qn("w:hAnsi"), name)
    run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)

def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)

def set_cell_margins(cell, top=100, start=120, bottom=100, end=120):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcMar = tcPr.first_child_found_in("w:tcMar")
    if tcMar is None:
        tcMar = OxmlElement("w:tcMar")
        tcPr.append(tcMar)
    for m, v in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tcMar.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            tcMar.append(node)
        node.set(qn("w:w"), str(v))
        node.set(qn("w:type"), "dxa")

doc = Document()
section = doc.sections[0]
section.top_margin = Inches(0.6)
section.bottom_margin = Inches(0.6)
section.left_margin = Inches(0.72)
section.right_margin = Inches(0.72)

styles = doc.styles
styles["Normal"].font.name = "Aptos"
styles["Normal"]._element.rPr.rFonts.set(qn("w:ascii"), "Aptos")
styles["Normal"]._element.rPr.rFonts.set(qn("w:hAnsi"), "Aptos")
styles["Normal"].font.size = Pt(10.5)
for sty in ("Title", "Heading 1", "Heading 2"):
    styles[sty].font.name = "Aptos Display"
    styles[sty]._element.rPr.rFonts.set(qn("w:ascii"), "Aptos Display")
    styles[sty]._element.rPr.rFonts.set(qn("w:hAnsi"), "Aptos Display")
    styles[sty].font.color.rgb = RGBColor(0, 0, 0)

title = doc.add_paragraph(style="Title")
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
set_font(title.add_run("WebLogic Interview Questions and Answers"), name="Aptos Display", size=24, bold=True)
sub = doc.add_paragraph()
sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
set_font(sub.add_run("Simple answers and useful Linux commands"), size=12, color=(50, 70, 90))
doc.add_paragraph().paragraph_format.space_after = Pt(2)
pic = doc.add_paragraph()
pic.alignment = WD_ALIGN_PARAGRAPH.CENTER
pic.add_run().add_picture(IMAGE, width=Inches(3.3))
note = doc.add_paragraph()
note.alignment = WD_ALIGN_PARAGRAPH.CENTER
set_font(note.add_run("For WebLogic Administrator interview preparation"), size=9, color=(85, 85, 85))

doc.add_heading("Interview Questions", level=1)
intro = doc.add_paragraph()
set_font(intro.add_run("Important: "), bold=True)
set_font(intro.add_run("Replace example values such as Server1, hostname, and port 7001 with your real environment values."))

for number, (question, answer, command) in enumerate(qa, 1):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(7)
    p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{number}. {question}"), size=11, bold=True, color=(20, 65, 110))
    a = doc.add_paragraph()
    a.paragraph_format.space_after = Pt(3)
    set_font(a.add_run("Answer: "), bold=True)
    set_font(a.add_run(answer))
    if command:
        table = doc.add_table(rows=1, cols=1)
        table.autofit = False
        cell = table.cell(0, 0)
        set_cell_shading(cell, "EEF3F8")
        set_cell_margins(cell)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        cp = cell.paragraphs[0]
        cp.paragraph_format.space_after = Pt(0)
        r = cp.add_run(command)
        set_font(r, name="Consolas", size=9.5, color=(30, 50, 70))

doc.add_heading("How to Answer in an Interview", level=1)
steps = [
    ("Give the meaning first", "Start with one short definition."),
    ("Say what you did", "Give one real task from your work."),
    ("Explain the result", "Say how you solved the issue or helped the team."),
    ("Keep it simple", "Use clear words. Do not give a long answer unless asked."),
]
for heading, text in steps:
    p = doc.add_paragraph(style=None)
    p.paragraph_format.space_after = Pt(4)
    set_font(p.add_run(heading + ": "), bold=True, color=(20, 65, 110))
    set_font(p.add_run(text))

doc.add_heading("Example Answer", level=1)
example = doc.add_paragraph()
example.paragraph_format.space_after = Pt(0)
set_font(example.add_run('“I used Node Manager to start and monitor Managed Servers. When a server failed, I checked the server logs, checked disk space and memory, and restarted the server safely.”'), size=11)

for paragraph in doc.paragraphs:
    paragraph.paragraph_format.line_spacing = 1.08

doc.save(OUT)
print(OUT)
