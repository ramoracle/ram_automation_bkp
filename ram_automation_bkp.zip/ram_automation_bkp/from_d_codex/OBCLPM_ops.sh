#!/usr/bin/env bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99


set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

export DOMAIN_NAME="${DOMAIN_NAME:-OBCLPM}"
export DOMAIN_BIN="${DOMAIN_BIN:-/PATH_TO_CONFIGURE}"
export WL_HOME="${WL_HOME:-/PATH_TO_CONFIGURE}"
export NODEMANAGER_BIN="${NODEMANAGER_BIN:-${WL_HOME%/}/server/bin}"
export ADMIN_SERVER="${ADMIN_SERVER:-AdminServer}"
export ADMIN_URL="${ADMIN_URL:-t3://hostname:PORT}"
export REMOTE_HOST="${REMOTE_HOST:-IP_ADDRESS}"
export REMOTE_USER="${REMOTE_USER:-USERNAME}"
export EXECUTION_MODE="${EXECUTION_MODE:-ssh}"
export MANAGED_SERVERS_CSV="${MANAGED_SERVERS_CSV:-new_ManagedServer_1}"
export DEPLOY_SCRIPT_DIR="${DEPLOY_SCRIPT_DIR:-/PATH_TO_CONFIGURE}"
export AUTOMATION_DIR="${AUTOMATION_DIR:-/PATH_TO_CONFIGURE}"
export START_STOP_HELPER="${START_STOP_HELPER:-/PATH_TO_CONFIGURE}"
export WLST_BIN="${WLST_BIN:-/PATH_TO_CONFIGURE}"
export START_STOP_SET_CWD="${START_STOP_SET_CWD:-/PATH_TO_CONFIGURE}"
export NODE_MANAGER_USER="${NODE_MANAGER_USER:-weblogic}"
export NODE_MANAGER_PASSWORD="SECRET_REMOVED"

exec "${SCRIPT_DIR}/weblogic_domain_ops.sh" "$@"
