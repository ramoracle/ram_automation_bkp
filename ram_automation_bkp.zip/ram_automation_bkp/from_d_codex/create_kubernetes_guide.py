# SANITIZED PUBLICATION TEMPLATE. Not runtime-tested.
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

OUT = r"/PATH_TO_CONFIGURE"

def shade(cell, color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), color)
    tcPr.append(shd)

def borders(cell, color='D9D9D9'):
    tcPr = cell._tc.get_or_add_tcPr()
    tcBorders = tcPr.first_child_found_in('w:tcBorders')
    if tcBorders is None:
        tcBorders = OxmlElement('w:tcBorders')
        tcPr.append(tcBorders)
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        tag = 'w:' + edge
        el = tcBorders.find(qn(tag))
        if el is None:
            el = OxmlElement(tag)
            tcBorders.append(el)
        el.set(qn('w:val'), 'single')
        el.set(qn('w:sz'), '6')
        el.set(qn('w:color'), color)

def set_cell_text(cell, text, bold=False, color=None):
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.space_before = Pt(2)
    r = p.add_run(text)
    r.bold = bold
    r.font.name = 'Aptos'
    r._element.rPr.rFonts.set(qn('w:ascii'), 'Aptos')
    r._element.rPr.rFonts.set(qn('w:hAnsi'), 'Aptos')
    r.font.size = Pt(9.5)
    if color:
        r.font.color.rgb = RGBColor(*color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    borders(cell)

doc = Document()
section = doc.sections[0]
section.top_margin = Inches(0.65)
section.bottom_margin = Inches(0.65)
section.left_margin = Inches(0.72)
section.right_margin = Inches(0.72)

styles = doc.styles
styles['Normal'].font.name = 'Aptos'
styles['Normal']._element.rPr.rFonts.set(qn('w:ascii'), 'Aptos')
styles['Normal']._element.rPr.rFonts.set(qn('w:hAnsi'), 'Aptos')
styles['Normal'].font.size = Pt(10.5)
styles['Normal'].paragraph_format.space_after = Pt(6)
for name, size in [('Title', 22), ('Heading 1', 15), ('Heading 2', 12)]:
    s = styles[name]
    s.font.name = 'Aptos Display' if name == 'Title' else 'Aptos'
    s._element.rPr.rFonts.set(qn('w:ascii'), s.font.name)
    s._element.rPr.rFonts.set(qn('w:hAnsi'), s.font.name)
    s.font.size = Pt(size)
    s.font.color.rgb = RGBColor(0, 0, 0)

title = doc.add_paragraph(style='Title')
title.alignment = WD_ALIGN_PARAGRAPH.LEFT
title.add_run('Kubernetes Command Guide')
intro = doc.add_paragraph()
intro.add_run('Purpose. ').bold = True
intro.add_run('A simple reference for checking the 26.1 Kubernetes cluster and investigating pods. These commands only read status; they do not change the environment.')

doc.add_heading('Before You Start', level=1)
p = doc.add_paragraph()
p.add_run('Set the cluster configuration and namespace once in your terminal:').bold = True
code = doc.add_paragraph()
code.paragraph_format.left_indent = Inches(0.2)
r = code.add_run('export KUBECONFIG="$(ocne cluster show --cluster-name iqa-cnf-cluster)"\nNS="obcnf-dev--foundation"')
r.font.name = 'Consolas'; r._element.rPr.rFonts.set(qn('w:ascii'), 'Consolas'); r.font.size = Pt(9.5)

doc.add_heading('Quick Health Check', level=1)
table = doc.add_table(rows=1, cols=3)
table.alignment = WD_TABLE_ALIGNMENT.CENTER
table.autofit = False
widths = [Inches(2.8), Inches(2.45), Inches(1.2)]
headers = ['Command', 'What it shows', 'Use when']
for i, h in enumerate(headers):
    table.columns[i].width = widths[i]
    shade(table.rows[0].cells[i], '1F4E78')
    set_cell_text(table.rows[0].cells[i], h, True, (255,255,255))
rows = [
('kubectl get nodes', 'Every cluster node and its status. Ready means Kubernetes can schedule workloads on that node.', 'Check cluster health'),
('kubectl get pods -A', 'All pods in all namespaces. Look for Running, Pending, CrashLoopBackOff, ImagePullBackOff, or CreateContainerConfigError.', 'Find problems anywhere'),
('kubectl get pods -n "$NS" -o wide', 'Pods in the selected application namespace, plus pod IP and the node hosting each pod.', 'Check application pods'),
('kubectl get deploy,statefulset,daemonset -n "$NS"', 'The workloads that manage pods and their desired versus ready replica count.', 'Check service availability'),
('kubectl get events -n "$NS" --sort-by=.lastTimestamp', 'Recent Kubernetes messages in chronological order. These often explain why a pod cannot start.', 'Investigate a failure'),
]
for idx, row in enumerate(rows):
    cells = table.add_row().cells
    if idx % 2 == 1:
        for c in cells: shade(c, 'EEF4F8')
    for i, val in enumerate(row):
        set_cell_text(cells[i], val, i == 0)

doc.add_heading('How to Read Pod Status', level=1)
statuses = [
('Running', 'The container is running. Confirm READY shows the expected count, such as 2/2.'),
('Pending', 'The pod is waiting for a node, storage, image, or another requirement.'),
('CrashLoopBackOff', 'A container starts, exits with an error, and Kubernetes retries it. Check the previous logs.'),
('ImagePullBackOff', 'Kubernetes cannot download the container image. Check image name, registry access, and image pull secrets.'),
('CreateContainerConfigError', 'A required Secret, ConfigMap, volume, or container configuration is missing or invalid.'),
('Completed', 'The pod finished successfully. This is normal for a one-time Job or migration.'),
]
for status, meaning in statuses:
    p = doc.add_paragraph(style='Normal')
    p.paragraph_format.left_indent = Inches(0.15)
    p.add_run(status + ': ').bold = True
    p.add_run(meaning)

doc.add_heading('When a Pod Is Not Healthy', level=1)
doc.add_paragraph('First identify the exact pod name, then use these read-only commands. Replace <pod-name> and <container-name> with actual values.')
for cmd, desc in [
('kubectl describe pod <pod-name> -n "$NS"', 'Shows pod configuration, events, volume mounts, image details, and the failure reason.'),
('kubectl logs <pod-name> -n "$NS" --all-containers=true --tail=200', 'Shows the most recent log lines from every container.'),
('kubectl logs <pod-name> -n "$NS" -c <container-name> --previous --tail=200', 'Shows logs from the previous failed container instance. Use this for CrashLoopBackOff.'),
('kubectl get pods -n "$NS" -w', 'Watches pod status live. Press Ctrl+C to stop watching.'),
]:
    p = doc.add_paragraph(style='Normal')
    p.add_run(cmd + '\n').bold = True
    p.add_run(desc)

doc.add_heading('Important Safety Note', level=1)
doc.add_paragraph('Commands such as rollout restart and kubectl scale change live workloads. Check status and logs first, then use those commands only when a restart, scale change, or planned stop is required.')

doc.save(OUT)
print(OUT)
