# SANITIZED PUBLICATION TEMPLATE. Not runtime-tested.
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle

OUT = r'/PATH_TO_CONFIGURE'
styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name='T', parent=styles['Title'], fontName='Helvetica-Bold', fontSize=23, leading=28, textColor=colors.black, spaceAfter=12))
styles.add(ParagraphStyle(name='H', parent=styles['Heading1'], fontName='Helvetica-Bold', fontSize=14, leading=18, textColor=colors.black, spaceBefore=8, spaceAfter=5))
styles.add(ParagraphStyle(name='B', parent=styles['BodyText'], fontName='Helvetica', fontSize=10.5, leading=14, spaceAfter=5))
styles.add(ParagraphStyle(name='C', parent=styles['Code'], fontName='Courier', fontSize=9, leading=12, leftIndent=8, textColor=colors.HexColor('#222222')))

def P(s, sty='B'): return Paragraph(s, styles[sty])

doc = SimpleDocTemplate(OUT, pagesize=A4, leftMargin=.78*inch, rightMargin=.78*inch, topMargin=.65*inch, bottomMargin=.65*inch)
story = [
    P('Kubernetes Simple Steps', 'T'),
    P('Use these steps to check whether the 26.1 cluster and application pods are healthy. All commands below are safe to run because they only show information.'),
    P('Step 1 Set the cluster and namespace', 'H'),
    P('Run this once after login:', 'B'),
    P('export KUBECONFIG="$(ocne cluster show --cluster-name iqa-cnf-cluster)"<br/>NS="obcnf-dev--foundation"', 'C'),
    P('Step 2 Check the cluster nodes', 'H'),
    P('Run: <b>kubectl get nodes</b><br/>Expected result: every node should show <b>Ready</b>.', 'B'),
    P('Step 3 Check application pods', 'H'),
    P('Run: <b>kubectl get pods -n "$NS"</b><br/>Expected result: pods should show <b>Running</b> and the READY column should match, for example 2/2.', 'B'),
    P('Step 4 If a pod has an error', 'H'),
    P('Common error states: <b>CrashLoopBackOff</b>, <b>ImagePullBackOff</b>, <b>Pending</b>, or <b>CreateContainerConfigError</b>. First copy the failing pod name, then run:', 'B'),
    P('kubectl describe pod &lt;pod-name&gt; -n "$NS"<br/>kubectl logs &lt;pod-name&gt; -n "$NS" --all-containers=true --tail=200', 'C'),
    P('Step 5 Check recent error messages', 'H'),
    P('Run: <b>kubectl get events -n "$NS" --sort-by=.lastTimestamp</b><br/>Look at the latest events. They normally state why the pod cannot start.', 'B'),
    P('Step 6 Send the output for help', 'H'),
    P('Send me the output of the describe command, logs command, and recent events. I will explain the error and give the next safe command.', 'B'),
]
doc.build(story)
print(OUT)
