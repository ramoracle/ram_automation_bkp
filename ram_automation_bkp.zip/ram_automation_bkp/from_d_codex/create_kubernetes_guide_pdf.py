# SANITIZED PUBLICATION TEMPLATE. Not runtime-tested.
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether

OUT = r'/PATH_TO_CONFIGURE'
PAGE_W, PAGE_H = A4

styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name='GuideTitle', parent=styles['Title'], fontName='Helvetica-Bold', fontSize=22, leading=27, textColor=colors.black, spaceAfter=12, alignment=TA_LEFT))
styles.add(ParagraphStyle(name='GuideHeading', parent=styles['Heading1'], fontName='Helvetica-Bold', fontSize=14, leading=18, textColor=colors.black, spaceBefore=13, spaceAfter=7))
styles.add(ParagraphStyle(name='GuideBody', parent=styles['BodyText'], fontName='Helvetica', fontSize=10, leading=14, textColor=colors.black, spaceAfter=6))
styles.add(ParagraphStyle(name='GuideCode', parent=styles['Code'], fontName='Courier', fontSize=8.5, leading=12, leftIndent=12, textColor=colors.HexColor('#1F1F1F'), spaceBefore=3, spaceAfter=8))
styles.add(ParagraphStyle(name='SmallCell', parent=styles['BodyText'], fontName='Helvetica', fontSize=8.5, leading=11, textColor=colors.black))
styles.add(ParagraphStyle(name='SmallCellBold', parent=styles['SmallCell'], fontName='Helvetica-Bold'))

def p(text, style='GuideBody'):
    return Paragraph(text, styles[style])

def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont('Helvetica', 8)
    canvas.setFillColor(colors.HexColor('#666666'))
    canvas.drawString(0.72*inch, 0.42*inch, 'Kubernetes Command Guide 26.1')
    canvas.drawRightString(PAGE_W - 0.72*inch, 0.42*inch, f'Page {doc.page}')
    canvas.restoreState()

doc = SimpleDocTemplate(OUT, pagesize=A4, rightMargin=0.72*inch, leftMargin=0.72*inch, topMargin=0.65*inch, bottomMargin=0.7*inch)
story = []
story += [p('Kubernetes Command Guide', 'GuideTitle'), p('<b>Purpose.</b> A simple reference for checking the 26.1 Kubernetes cluster and investigating pods. The commands in the health-check and troubleshooting sections are read-only; they do not change the environment.'), p('Before You Start', 'GuideHeading'), p('Set the cluster configuration and application namespace once in your terminal.'), p('export KUBECONFIG="$(ocne cluster show --cluster-name iqa-cnf-cluster)"<br/>NS="obcnf-dev--foundation"', 'GuideCode')]

story += [p('Quick Health Check', 'GuideHeading')]
data = [[p('<b>Command</b>', 'SmallCell'), p('<b>What it shows</b>', 'SmallCell'), p('<b>Use when</b>', 'SmallCell')]]
rows = [
('kubectl get nodes', 'Every cluster node and its status. <b>Ready</b> means Kubernetes can schedule workloads on that node.', 'Check cluster health'),
('kubectl get pods -A', 'All pods in all namespaces. Look for Running, Pending, CrashLoopBackOff, ImagePullBackOff, or CreateContainerConfigError.', 'Find problems anywhere'),
('kubectl get pods -n "$NS" -o wide', 'Pods in the selected application namespace, plus pod IP and the node hosting each pod.', 'Check application pods'),
('kubectl get deploy,statefulset,daemonset -n "$NS"', 'Workloads that manage pods and their desired versus ready replica count.', 'Check service availability'),
('kubectl get events -n "$NS" --sort-by=.lastTimestamp', 'Recent Kubernetes messages in chronological order. These often explain why a pod cannot start.', 'Investigate a failure'),
]
for cmd, show, use in rows:
    data.append([p(cmd, 'SmallCellBold'), p(show, 'SmallCell'), p(use, 'SmallCell')])
t = Table(data, colWidths=[2.43*inch, 2.75*inch, 1.25*inch], repeatRows=1, hAlign='LEFT')
t.setStyle(TableStyle([
('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1F4E78')), ('TEXTCOLOR',(0,0),(-1,0),colors.white),
('GRID',(0,0),(-1,-1),0.4,colors.HexColor('#D9D9D9')), ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),
('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#EEF4F8')])
]))
story += [t, Spacer(1, 10), p('How to Read Pod Status', 'GuideHeading')]
status_rows = [
('<b>Running</b>', 'The container is running. Confirm READY shows the expected count, such as 2/2.'),
('<b>Pending</b>', 'The pod is waiting for a node, storage, image, or another requirement.'),
('<b>CrashLoopBackOff</b>', 'A container starts, exits with an error, and Kubernetes retries it. Check the previous logs.'),
('<b>ImagePullBackOff</b>', 'Kubernetes cannot download the image. Check image name, registry access, and image pull secrets.'),
('<b>CreateContainerConfigError</b>', 'A required Secret, ConfigMap, volume, or container configuration is missing or invalid.'),
('<b>Completed</b>', 'The pod finished successfully. This is normal for a one-time Job or migration.'),
]
for state, explanation in status_rows:
    story.append(p(f'{state}: {explanation}'))

story += [p('When a Pod Is Not Healthy', 'GuideHeading'), p('First identify the exact pod name, then run the commands below. Replace &lt;pod-name&gt; and &lt;container-name&gt; with the actual values.')]
troubleshooting = [
('kubectl describe pod &lt;pod-name&gt; -n "$NS"', 'Shows pod configuration, events, volume mounts, image details, and the failure reason.'),
('kubectl logs &lt;pod-name&gt; -n "$NS" --all-containers=true --tail=200', 'Shows the latest 200 log lines from every container.'),
('kubectl logs &lt;pod-name&gt; -n "$NS" -c &lt;container-name&gt; --previous --tail=200', 'Shows logs from the previously failed container instance. Use this for CrashLoopBackOff.'),
('kubectl get pods -n "$NS" -w', 'Watches pod status live. Press Ctrl+C to stop watching.'),
]
for cmd, desc in troubleshooting:
    story.append(KeepTogether([p(cmd, 'GuideCode'), p(desc)]))
story += [p('Safety Note', 'GuideHeading'), p('Commands such as <b>kubectl rollout restart</b> and <b>kubectl scale</b> change live workloads. Check status and logs first, then use those commands only when a restart, scaling change, or planned stop is required.')]
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print(OUT)
