// SANITIZED PUBLICATION TEMPLATE. Not runtime-tested.
import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const inputPath = "/PATH_TO_CONFIGURE";
const input = await FileBlob.load(inputPath);
const workbook = await SpreadsheetFile.importXlsx(input);

const summary = await workbook.inspect({
  kind: "region",
  sheetId: "Today_Update_2026-07-06",
  range: "A1:D10",
  maxChars: 5000,
});
console.log(summary.ndjson);

const errors = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 50 },
  summary: "formula error scan",
});
console.log(errors.ndjson);

const preview = await workbook.render({
  sheetName: "Today_Update_2026-07-06",
  range: "A1:D10",
  scale: 1,
  format: "png",
});
await fs.writeFile("/PATH_TO_CONFIGURE", new Uint8Array(await preview.arrayBuffer()));
