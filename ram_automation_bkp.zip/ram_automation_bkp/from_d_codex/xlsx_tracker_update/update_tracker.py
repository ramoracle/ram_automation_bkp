# SANITIZED PUBLICATION TEMPLATE. Not runtime-tested.
from datetime import datetime, date
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.utils import get_column_letter

src = Path(r"/PATH_TO_CONFIGURE")
out = Path(r"/PATH_TO_CONFIGURE")

today = date(2026, 7, 6)
patch_date = date(2026, 7, 3)

wb = load_workbook(src)
ws = wb["Remediation_Tracker"]
headers = [cell.value for cell in ws[1]]
h = {name: idx + 1 for idx, name in enumerate(headers)}

def set_cell(row, col_name, value):
    ws.cell(row=row, column=h[col_name]).value = value

def update_row(row, *, current_status, fix_status, action, evidence, remarks,
               fixed_date=None, validation_date=None, assigned="USERNAME"):
    set_cell(row, "Current Status", current_status)
    set_cell(row, "Assigned To", assigned)
    set_cell(row, "Action Taken", action)
    set_cell(row, "Fix Status", fix_status)
    set_cell(row, "Fixed Date", fixed_date)
    set_cell(row, "Validated By", assigned)
    set_cell(row, "Validation Date", validation_date)
    set_cell(row, "Validation Evidence", evidence)
    set_cell(row, "Remarks", remarks)

updated_rows = []
for row in range(2, ws.max_row + 1):
    server = str(ws.cell(row, h["Server"]).value or "")
    summary = str(ws.cell(row, h["Finding Summary"]).value or "")

    if server == "hostname_6" and "Oracle WebLogic Server Multiple Vulnerabilities (CPUAPR2026)" in summary:
        update_row(
            row,
            current_status="Closed",
            fix_status="Fixed",
            action="Applied WLS PSU patch 39164443 on /PATH_TO_CONFIGURE",
            evidence="opatch lspatches: 39164443; WLS PATCH SET UPDATE 14.1.1.0.260403. opatch lsinventory shows patch applied on Fri Jul 03 07:50:42 GMT 2026.",
            remarks="Patch 37732915 became inactive because it is superseded by 39164443. Rescan requested to clear stale evidence.",
            fixed_date=patch_date,
            validation_date=patch_date,
        )
        updated_rows.append(row)

    if server == "hostname_6" and "Oracle Coherence July 2021 Critical Patch Update" in summary:
        update_row(
            row,
            current_status="Closed",
            fix_status="Fixed",
            action="Validated installed Coherence patch level.",
            evidence="opatch lspatches: 35778900; Coherence Feature Pack Cumulative Patch 14.1.1.2206.6.",
            remarks="Installed Coherence patch level is newer than July 2021 CPU. Rescan requested to clear stale plugin evidence.",
            fixed_date=patch_date,
            validation_date=today,
        )
        updated_rows.append(row)

    if server == "hostname_6" and "Oracle Coherence July 2025 Security Patch Update" in summary:
        update_row(
            row,
            current_status="Closed",
            fix_status="Fixed",
            action="Applied/validated WLS PSU patch 39164443 and existing Coherence patch 35778900.",
            evidence="opatch lspatches: 39164443; WLS PATCH SET UPDATE 14.1.1.0.260403. Also installed: 35778900; Coherence Feature Pack Cumulative Patch 14.1.1.2206.6.",
            remarks="Patch level is newer than CPUJUL2025 WLS PSU. Rescan requested; do not use 38417899 because p38417899_141200_Generic.zip is for 14.1.2.0.0.",
            fixed_date=patch_date,
            validation_date=today,
        )
        updated_rows.append(row)

    if server == "hostname_7" and "Apache Log4j 1.2 Remote Code Execution Vulnerability" in summary:
        update_row(
            row,
            current_status="In Progress",
            fix_status="Partial Fix",
            action="Deleted old conductor temp/cache deployment folder. Confirmed active WebLogic config points to deployment-services/may2026/conductor-server-v3.5.2_19.war; this WAR did not contain WEB-INF/lib/log4j-1.2.17-18.jar at tested path.",
            evidence="config.xml source-path: deployment-services/may2026/conductor-server-v3.5.2_19.war. Old temp path now returns No such file or directory after cleanup.",
            remarks="Pending final verification/fix for loose PLATOINFRA log4j-1.2.17-18.jar and Zookeeper log4j-1.2.17-18.jar by removing org/apache/log4j/net/JMSAppender.class.",
            fixed_date=None,
            validation_date=today,
        )
        updated_rows.append(row)

for col_name in ["Fixed Date", "Validation Date"]:
    col = h[col_name]
    for row in range(2, ws.max_row + 1):
        ws.cell(row, col).number_format = "yyyy-mm-dd"

if "Today_Update_2026-07-06" in wb.sheetnames:
    del wb["Today_Update_2026-07-06"]
summary_ws = wb.create_sheet("Today_Update_2026-07-06", 1)

summary_rows = [
    ["Today Update", "2026-07-06", "", ""],
    ["Prepared For", "Vulnerability remediation status report", "", ""],
    ["", "", "", ""],
    ["Server", "Issue", "Status", "Evidence / Next Action"],
    [
        "hostname_6",
        "Oracle WebLogic Server Multiple Vulnerabilities (CPUAPR2026)",
        "Fixed",
        "Patch 39164443 applied and verified with OPatch.",
    ],
    [
        "hostname_6",
        "Oracle Coherence July 2021 Critical Patch Update",
        "Fixed / Rescan Required",
        "Coherence patch 35778900 is installed and newer than July 2021 CPU.",
    ],
    [
        "hostname_6",
        "Oracle Coherence July 2025 Security Patch Update (CPUJUL2025)",
        "Fixed / Rescan Required",
        "WLS PSU 39164443 installed. 38417899 skipped because it is 14.1.2.0.0 patch, not 14.1.1.0.0.",
    ],
    [
        "hostname_7",
        "Apache Log4j 1.2 JMSAppender / RCE",
        "Partial Fix",
        "Old conductor temp folder removed; active WAR checked. Pending loose domain jar and Zookeeper jar JMSAppender removal/verification.",
    ],
    ["", "", "", ""],
    ["Updated Rows", ", ".join(map(str, updated_rows)), "", ""],
]

for r_idx, row in enumerate(summary_rows, 1):
    for c_idx, value in enumerate(row, 1):
        summary_ws.cell(r_idx, c_idx).value = value

title_fill = PatternFill("solid", fgColor="1F4E78")
header_fill = PatternFill("solid", fgColor="D9EAF7")
fixed_fill = PatternFill("solid", fgColor="D9EAD3")
partial_fill = PatternFill("solid", fgColor="FFF2CC")
border = Border(bottom=Side(style="thin", color="BFBFBF"))

summary_ws["A1"].font = Font(bold=True, color="FFFFFF", size=14)
summary_ws["B1"].font = Font(bold=True, color="FFFFFF", size=14)
summary_ws["A1"].fill = title_fill
summary_ws["B1"].fill = title_fill
summary_ws.merge_cells("B1:D1")

for cell in summary_ws[4]:
    cell.font = Font(bold=True)
    cell.fill = header_fill
    cell.border = border

for row in range(5, 9):
    status = str(summary_ws.cell(row, 3).value or "")
    fill = partial_fill if "Partial" in status else fixed_fill
    for col in range(1, 5):
        cell = summary_ws.cell(row, col)
        cell.fill = fill
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        cell.border = border

for col, width in {"A": 18, "B": 54, "C": 22, "D": 90}.items():
    summary_ws.column_dimensions[col].width = width
summary_ws.freeze_panes = "A5"
summary_ws.sheet_view.showGridLines = False

for sheet in ["Tracker"]:
    if sheet in wb.sheetnames:
        tws = wb[sheet]
        next_col = tws.max_column + 1
        tws.cell(1, next_col).value = today
        tws.cell(1, next_col).number_format = "yyyy-mm-dd"
        severities = {"CRITICAL": 2, "HIGH": 3, "MEDIUM": 4, "LOW": 5}
        for sev, r in severities.items():
            count = 0
            for rr in range(2, ws.max_row + 1):
                if str(ws.cell(rr, h["Severity"]).value or "") == sev and str(ws.cell(rr, h["Fix Status"]).value or "") not in {"Fixed", "Closed"}:
                    count += 1
            tws.cell(r, next_col).value = count
        tws.cell(6, next_col).value = f"=SUM({get_column_letter(next_col)}2:{get_column_letter(next_col)}5)"

wb.save(out)
print(out)
print(f"Updated rows: {updated_rows}")
