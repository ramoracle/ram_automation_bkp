# SANITIZED PUBLICATION TEMPLATE. Not runtime-tested.
from openpyxl import load_workbook

p = r"/PATH_TO_CONFIGURE"
wb = load_workbook(p)
ws = wb["Remediation_Tracker"]
headers = [c.value for c in ws[1]]
print(headers)

terms = [
    "CPUAPR2026",
    "Coherence July 2021",
    "Coherence July 2025",
    "JMSAppender",
    "Log4j",
    "SSL Certificate - Expired",
    "39164443",
    "CPUJUL2025",
]

for term in terms:
    print(f"\nTERM {term}")
    cnt = 0
    for row in ws.iter_rows(min_row=2):
        vals = [str(c.value or "") for c in row]
        if any(term.lower() in v.lower() for v in vals):
            print(row[0].row, vals[:12])
            cnt += 1
            if cnt >= 15:
                break
    print("count sample", cnt)
