# SANITIZED PUBLICATION TEMPLATE. Not runtime-tested.
from pathlib import Path
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment

src = Path(r"/PATH_TO_CONFIGURE")
out = Path(r"/PATH_TO_CONFIGURE")

wb = load_workbook(src)

sheet_name = "Manager_Email_Update"
if sheet_name in wb.sheetnames:
    del wb[sheet_name]
ws = wb.create_sheet(sheet_name, 0)

rows = [
    ["Subject", "Vulnerability Remediation Update - 06 Jul 2026", "", ""],
    ["", "", "", ""],
    ["Email Body", "", "", ""],
    ["Hi Sir,", "", "", ""],
    ["", "", "", ""],
    ["Please find the latest vulnerability remediation update below.", "", "", ""],
    ["", "", "", ""],
    ["Server", "Issue", "Current Status", "Update"],
    [
        "hostname_6",
        "Oracle WebLogic Server Multiple Vulnerabilities (CPUAPR2026)",
        "Fixed",
        "WLS PSU patch 39164443 applied and verified through OPatch.",
    ],
    [
        "hostname_6",
        "Oracle Coherence July 2021 CPU",
        "Fixed / Rescan Required",
        "Coherence patch 35778900 is installed and newer than July 2021 CPU. Rescan requested to clear stale evidence.",
    ],
    [
        "hostname_6",
        "Oracle Coherence July 2025 CPU",
        "Fixed / Rescan Required",
        "WLS PSU 39164443 is installed. Patch 38417899 was not applied because it is for 14.1.2.0.0, while current home is 14.1.1.0.0.",
    ],
    [
        "hostname_7",
        "Apache Log4j 1.2 JMSAppender / RCE",
        "Partial Fix",
        "Old conductor temp folder removed and active WAR checked. Pending final validation/fix for loose PLATOINFRA and Zookeeper Log4j jars.",
    ],
    ["", "", "", ""],
    ["Attached is the updated tracker sheet for reference.", "", "", ""],
    ["", "", "", ""],
    ["Regards,", "", "", ""],
    ["USERNAME", "", "", ""],
]

for r, row in enumerate(rows, 1):
    for c, value in enumerate(row, 1):
        ws.cell(r, c).value = value

title_fill = PatternFill("solid", fgColor="1F4E78")
section_fill = PatternFill("solid", fgColor="D9EAF7")
fixed_fill = PatternFill("solid", fgColor="D9EAD3")
partial_fill = PatternFill("solid", fgColor="FFF2CC")
thin = Side(style="thin", color="BFBFBF")

ws["A1"].font = Font(bold=True, color="FFFFFF")
ws["B1"].font = Font(bold=True, color="FFFFFF", size=13)
ws["A1"].fill = title_fill
ws["B1"].fill = title_fill
ws.merge_cells("B1:D1")

ws["A3"].font = Font(bold=True)
ws["A3"].fill = section_fill
ws.merge_cells("A3:D3")

for cell in ws[8]:
    cell.font = Font(bold=True)
    cell.fill = section_fill
    cell.border = Border(top=thin, bottom=thin)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

for row in range(9, 13):
    fill = partial_fill if "Partial" in str(ws.cell(row, 3).value or "") else fixed_fill
    for col in range(1, 5):
        cell = ws.cell(row, col)
        cell.fill = fill
        cell.border = Border(bottom=thin)
        cell.alignment = Alignment(vertical="top", wrap_text=True)

for row in [4, 6, 14, 16, 17]:
    for col in range(1, 5):
        ws.cell(row, col).alignment = Alignment(wrap_text=True, vertical="top")

ws.column_dimensions["A"].width = 18
ws.column_dimensions["B"].width = 48
ws.column_dimensions["C"].width = 24
ws.column_dimensions["D"].width = 90
for row in range(1, 18):
    ws.row_dimensions[row].height = 24
for row in range(9, 13):
    ws.row_dimensions[row].height = 60

ws.freeze_panes = "A8"
ws.sheet_view.showGridLines = False

wb.save(out)
print(out)
