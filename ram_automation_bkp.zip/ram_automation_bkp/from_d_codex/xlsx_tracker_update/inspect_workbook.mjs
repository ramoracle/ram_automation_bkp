// SANITIZED PUBLICATION TEMPLATE. Not runtime-tested.
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const inputPath = "/PATH_TO_CONFIGURE";
const input = await FileBlob.load(inputPath);
const workbook = await SpreadsheetFile.importXlsx(input);

const summary = await workbook.inspect({
  kind: "workbook,sheet,table",
  maxChars: 12000,
  tableMaxRows: 8,
  tableMaxCols: 12,
  tableMaxCellChars: 100,
});
console.log(summary.ndjson);

for (const name of ["Tracker", "Track", "Tracker Sheet", "Tracking"]) {
  try {
    const sheet = workbook.worksheets.getItem(name);
    const region = await workbook.inspect({
      kind: "region",
      sheetId: name,
      range: "A1:Z20",
      maxChars: 8000,
    });
    console.log(`\n--- ${name} ---`);
    console.log(region.ndjson);
  } catch {}
}
