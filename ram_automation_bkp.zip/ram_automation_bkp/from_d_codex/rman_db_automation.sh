#!/bin/bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99


set -u

SCRIPT_NAME="$(basename "$0")"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG_FILE="${CONFIG_FILE:-$SCRIPT_DIR/rman_db_automation.conf}"

if [[ ! -f "$CONFIG_FILE" ]]; then
  echo "Config file not found: $CONFIG_FILE"
  exit 1
fi

# shellcheck source=/dev/null
. "$CONFIG_FILE"

export ORACLE_SID ORACLE_HOME ORACLE_BASE
export PATH="$ORACLE_HOME/bin:$PATH"

TIMESTAMP="$(date '+%Y%m%d_%H%M%S')"
HOST_NAME="$(hostname)"
ACTION="${1:-}"
ARG1="${2:-}"
ARG2="${3:-}"
RUN_LOG=""
RMAN_CONNECT_ARGS="target /"

usage() {
  cat <<EOF
Usage: $SCRIPT_NAME {backup|restore|start|stop|status|enable_archivelog|list_backups|validate_restore}

Commands:
  backup   Take RMAN full backup
  restore  Restore and recover database
  start    Start database in configured mode
  stop     Stop database in configured mode
  status   Show database and listener status
  enable_archivelog  Enable ARCHIVELOG mode for the database
  list_backups  Show RMAN backup summary and controlfile backups
  validate_restore  Validate restore readiness without restoring files

Restore usage:
  $SCRIPT_NAME restore <catalog_dir> <controlfile_backup>

Validate usage:
  $SCRIPT_NAME validate_restore [catalog_dir|latest]

Example:
  $SCRIPT_NAME backup
  $SCRIPT_NAME status
  $SCRIPT_NAME enable_archivelog
  $SCRIPT_NAME list_backups
  $SCRIPT_NAME validate_restore
  $SCRIPT_NAME validate_restore latest
  $SCRIPT_NAME validate_restore /PATH_TO_CONFIGURE
  $SCRIPT_NAME restore /PATH_TO_CONFIGURE /PATH_TO_CONFIGURE
EOF
}

ensure_directories() {
  mkdir -p "$BACKUP_DIR" "$LOG_DIR"
}

set_log_file() {
  local action_name="$1"
  RUN_LOG="$LOG_DIR/${action_name}_${ORACLE_SID}_${TIMESTAMP}.log"
  touch "$RUN_LOG" || {
    echo "Unable to create log file: $RUN_LOG"
    exit 1
  }
}

log() {
  local message="$1"
  local now
  now="$(date '+%Y-%m-%d %H:%M:%S')"
  echo "[$now] $message" | tee -a "$RUN_LOG"
}

run_and_log() {
  local cmd="$1"
  log "Running: $cmd"
  eval "$cmd" >>"$RUN_LOG" 2>&1
  return $?
}

send_mail() {
  local subject="$1"
  local body="$2"
  local mailer=""

  if [[ "${EMAIL_NOTIFICATIONS}" != "yes" ]]; then
    return 0
  fi

  if command -v "$MAIL_COMMAND" >/dev/null 2>&1; then
    mailer="$MAIL_COMMAND"
  elif command -v "$MAIL_FALLBACK_COMMAND" >/dev/null 2>&1; then
    mailer="$MAIL_FALLBACK_COMMAND"
  fi

  if [[ -n "$mailer" ]]; then
    printf '%s\n\nLog file: %s\nHost: %s\nDatabase: %s\n' \
      "$body" "$RUN_LOG" "$HOST_NAME" "$ORACLE_SID" | \
      "$mailer" -s "$subject" "$EMAIL_TO" >>"$RUN_LOG" 2>&1
  else
    log "No supported mail command found. Skipping email notification."
  fi
}

notify_and_exit() {
  local rc="$1"
  local success_subject="SUCCESS [$HOST_NAME] $ACTION for $ORACLE_SID"
  local failure_subject="FAILED [$HOST_NAME] $ACTION for $ORACLE_SID"

  if [[ "$rc" -eq 0 ]]; then
    log "$ACTION completed successfully."
    send_mail "$success_subject" "$ACTION completed successfully."
  else
    log "$ACTION failed with exit code $rc."
    send_mail "$failure_subject" "$ACTION failed with exit code $rc."
  fi

  exit "$rc"
}

require_binary() {
  local binary="$1"
  if ! command -v "$binary" >/dev/null 2>&1; then
    log "Required binary not found: $binary"
    notify_and_exit 1
  fi
}

check_environment() {
  require_binary sqlplus
  require_binary rman

  if [[ ! -x "$ORACLE_HOME/bin/sqlplus" ]]; then
    log "sqlplus is not executable under ORACLE_HOME: $ORACLE_HOME/bin/sqlplus"
    notify_and_exit 1
  fi

  if [[ ! -x "$ORACLE_HOME/bin/rman" ]]; then
    log "rman is not executable under ORACLE_HOME: $ORACLE_HOME/bin/rman"
    notify_and_exit 1
  fi

  if [[ "$USE_RMAN_CATALOG" = "yes" ]]; then
    if [[ -z "${RMAN_CATALOG_CONNECT:-}" ]]; then
      log "USE_RMAN_CATALOG is yes but RMAN_CATALOG_CONNECT is empty."
      notify_and_exit 1
    fi
    RMAN_CONNECT_ARGS="target / catalog $RMAN_CATALOG_CONNECT"
  fi
}

manage_listener() {
  local mode="$1"
  local listener_arg=""

  if [[ "$MANAGE_LISTENER" != "yes" ]]; then
    log "Listener management disabled."
    return 0
  fi

  if [[ -z "${LISTENER_NAME:-}" ]]; then
    log "LISTENER_NAME is empty; skipping listener $mode."
    return 0
  fi

  if [[ "$LISTENER_NAME" =~ ^[0-9]+$ ]]; then
    log "LISTENER_NAME='$LISTENER_NAME' looks like a port. Using default listener alias with lsnrctl."
  else
    listener_arg=" $LISTENER_NAME"
  fi

  if ! command -v lsnrctl >/dev/null 2>&1; then
    log "lsnrctl not found; skipping listener $mode."
    return 0
  fi

  run_and_log "lsnrctl $mode$listener_arg"
  return $?
}

run_sqlplus_block() {
  local sql_block="$1"

  "$ORACLE_HOME/bin/sqlplus" -s / as sysdba >>"$RUN_LOG" 2>&1 <<EOF
whenever sqlerror exit failure
set echo on
set pages 100
set lines 200
$sql_block
exit
EOF
}

run_rman_block() {
  local rman_block="$1"

  "$ORACLE_HOME/bin/rman" $RMAN_CONNECT_ARGS log="$RUN_LOG" append <<EOF
$rman_block
exit
EOF
}

get_log_mode() {
  "$ORACLE_HOME/bin/sqlplus" -s / as sysdba <<'EOF'
set heading off
set feedback off
set pages 0
set verify off
set echo off
select log_mode from v$database;
exit
EOF
}

find_latest_backup_dir() {
  local base_dir="${1:-$BACKUP_DIR}"

  if [[ ! -d "$base_dir" ]]; then
    return 1
  fi

  find "$base_dir" -mindepth 1 -maxdepth 1 -type d -printf '%T@ %p\n' 2>/dev/null | \
    sort -nr | awk 'NR==1 {print $2}'
}

confirm_restore() {
  if [[ "$ASK_CONFIRM_BEFORE_RESTORE" != "yes" ]]; then
    return 0
  fi

  echo
  echo "Restore confirmation"
  echo "Host          : $HOST_NAME"
  echo "ORACLE_SID    : $ORACLE_SID"
  echo "DB_NAME       : $DB_NAME"
  echo "This action will overwrite database files on the same server."
  read -r -p "Type YES to continue: " reply

  if [[ "$reply" != "YES" ]]; then
    log "Restore cancelled by user."
    notify_and_exit 1
  fi
}

database_status() {
  run_sqlplus_block '
prompt === DATABASE STATUS ===
select instance_name, host_name, version, status from v$instance;
prompt === DATABASE ROLE ===
select name, db_unique_name, open_mode, database_role, cdb from v$database;
prompt === PDB STATUS ===
select con_id, name, open_mode from v$pdbs order by con_id;
'
}

listener_status() {
  if [[ "$MANAGE_LISTENER" = "yes" ]] && command -v lsnrctl >/dev/null 2>&1; then
    if [[ "$LISTENER_NAME" =~ ^[0-9]+$ ]]; then
      run_and_log "lsnrctl status"
    else
      run_and_log "lsnrctl status $LISTENER_NAME"
    fi
  fi
}

backup_database() {
  local backup_tag="BKP_${TIMESTAMP}"
  local arch_tag="${backup_tag}_ARC"
  local ctl_tag="${backup_tag}_CTL"
  local backup_piece_format="$BACKUP_DIR/${DB_NAME}_%d_%T_%U.bkp"
  local arch_piece_format="$BACKUP_DIR/${DB_NAME}_ARCH_%d_%T_%U.arc"
  local rc=0

  log "Starting RMAN full backup for $ORACLE_SID"

  if [[ "$COMPRESSED_BACKUPSETS" = "yes" ]]; then
    run_rman_block "
run {
  configure retention policy to recovery window of ${RETENTION_DAYS} days;
  configure controlfile autobackup on;
  backup as compressed backupset database tag '$backup_tag' format '$backup_piece_format';
  sql 'alter system archive log current';
  backup as compressed backupset archivelog all tag '$arch_tag' format '$arch_piece_format';
  backup current controlfile tag '$ctl_tag' format '$backup_piece_format';
}
list backup summary;
"
  else
    run_rman_block "
run {
  configure retention policy to recovery window of ${RETENTION_DAYS} days;
  configure controlfile autobackup on;
  backup database tag '$backup_tag' format '$backup_piece_format';
  sql 'alter system archive log current';
  backup archivelog all tag '$arch_tag' format '$arch_piece_format';
  backup current controlfile tag '$ctl_tag' format '$backup_piece_format';
}
list backup summary;
"
  fi
  rc=$?
  if [[ "$rc" -ne 0 ]]; then
    return "$rc"
  fi

  if [[ "$DELETE_ARCHIVELOGS_AFTER_BACKUP" = "yes" ]]; then
    run_rman_block "
delete noprompt archivelog all backed up 1 times to device type disk;
"
    rc=$?
    if [[ "$rc" -ne 0 ]]; then
      return "$rc"
    fi
  fi

  if [[ "$DELETE_OBSOLETE" = "yes" ]]; then
    run_rman_block "
crosscheck backup;
delete noprompt obsolete;
"
    rc=$?
    if [[ "$rc" -ne 0 ]]; then
      return "$rc"
    fi
  fi

  return 0
}

list_backups() {
  log "Listing RMAN backups for $ORACLE_SID"
  run_rman_block "
list backup summary;
list backup of database summary;
list backup of archivelog all summary;
list backup of controlfile summary;
"
}

stop_database() {
  log "Stopping database using shutdown $STOP_MODE"
  run_sqlplus_block "
shutdown $STOP_MODE;
"
  return $?
}

open_pdbs_if_needed() {
  if [[ "${IS_CDB:-no}" != "yes" ]]; then
    return 0
  fi

  if [[ "${OPEN_PDBS_ON_START:-no}" != "yes" ]]; then
    log "PDB open on start is disabled."
    return 0
  fi

  log "Opening pluggable databases: ${PDB_OPEN_TARGET:-all}"
  run_sqlplus_block "
alter pluggable database ${PDB_OPEN_TARGET:-all} open;
show pdbs;
"
}

start_database() {
  log "Starting database in $START_MODE mode"
  local rc=0

  case "$START_MODE" in
    nomount)
      run_sqlplus_block "startup nomount;"
      rc=$?
      ;;
    mount)
      run_sqlplus_block "startup mount;"
      rc=$?
      ;;
    open)
      run_sqlplus_block "startup;"
      rc=$?
      if [[ "$rc" -eq 0 ]]; then
        open_pdbs_if_needed
        rc=$?
      fi
      ;;
    *)
      log "Unsupported START_MODE: $START_MODE"
      return 1
      ;;
  esac

  return "$rc"
}

enable_archivelog() {
  local current_mode=""

  current_mode="$(get_log_mode | tr -d '[:space:]')"
  if [[ -z "$current_mode" ]]; then
    log "Unable to determine current log mode."
    return 1
  fi

  log "Current log mode: $current_mode"

  if [[ "$current_mode" == "ARCHIVELOG" ]]; then
    log "Database is already in ARCHIVELOG mode."
    run_sqlplus_block '
archive log list;
select log_mode from v$database;
show pdbs;
'
    return $?
  fi

  log "Enabling ARCHIVELOG mode. This will restart the database."
  run_sqlplus_block '
archive log list;
shutdown immediate;
startup mount;
alter database archivelog;
alter database open;
alter pluggable database all open;
archive log list;
select log_mode from v$database;
show pdbs;
'
}

validate_restore() {
  local validate_catalog_dir="$ARG1"
  local rc=0

  if [[ -z "$validate_catalog_dir" || "$validate_catalog_dir" == "latest" ]]; then
    validate_catalog_dir="$(find_latest_backup_dir "$BACKUP_DIR")"
    if [[ -z "$validate_catalog_dir" ]]; then
      log "No backup directories found under $BACKUP_DIR"
      return 1
    fi
    log "Using latest backup directory for validation: $validate_catalog_dir"
  fi

  if [[ -z "$validate_catalog_dir" ]]; then
    validate_catalog_dir="${RESTORE_CATALOG_DIR:-}"
  fi

  log "Validating restore readiness for $ORACLE_SID"

  if [[ -n "$validate_catalog_dir" ]]; then
    if [[ ! -d "$validate_catalog_dir" ]]; then
      log "Validation catalog directory does not exist: $validate_catalog_dir"
      return 1
    fi

    log "Cataloging backup pieces from: $validate_catalog_dir"
    run_rman_block "
catalog start with '$validate_catalog_dir/' noprompt;
"
    rc=$?
    if [[ "$rc" -ne 0 ]]; then
      return "$rc"
    fi
  fi

  run_rman_block "
restore database validate;
"
}

restore_database() {
  local restore_catalog_dir="$ARG1"
  local restore_controlfile_path="$ARG2"
  local rc=0

  if [[ -z "$restore_catalog_dir" ]]; then
    restore_catalog_dir="${RESTORE_CATALOG_DIR:-}"
  fi

  if [[ -z "$restore_controlfile_path" ]]; then
    restore_controlfile_path="${RESTORE_CONTROLFILE_PATH:-}"
  fi

  if [[ -z "$restore_catalog_dir" ]]; then
    log "Restore catalog directory is required."
    log "Usage: $SCRIPT_NAME restore <catalog_dir> <controlfile_backup>"
    return 1
  fi

  if [[ -z "$restore_controlfile_path" ]]; then
    log "Controlfile backup path is required."
    log "Usage: $SCRIPT_NAME restore <catalog_dir> <controlfile_backup>"
    return 1
  fi

  if [[ ! -d "$restore_catalog_dir" ]]; then
    log "Restore catalog directory does not exist: $restore_catalog_dir"
    return 1
  fi

  if [[ ! -f "$restore_controlfile_path" ]]; then
    log "Controlfile backup file does not exist: $restore_controlfile_path"
    return 1
  fi

  confirm_restore
  log "Preparing restore from $restore_catalog_dir"
  log "Using controlfile backup: $restore_controlfile_path"

  stop_database || return $?

  run_rman_block "
run {
  startup nomount;
  restore controlfile from '$restore_controlfile_path';
  sql 'alter database mount';
}
catalog start with '$restore_catalog_dir/' noprompt;
run {
  restore database;
  recover database;
}
"
  rc=$?
  if [[ "$rc" -ne 0 ]]; then
    return "$rc"
  fi

  if [[ "$RESTORE_OPEN_RESETLOGS" = "yes" ]]; then
    run_sqlplus_block "
alter database open resetlogs;
"
    rc=$?
    if [[ "$rc" -ne 0 ]]; then
      return "$rc"
    fi
  fi

  return 0
}

show_status() {
  log "Collecting database status"
  database_status
  local rc=$?
  if [[ "$rc" -ne 0 ]]; then
    return "$rc"
  fi
  listener_status
}

main() {
  case "$ACTION" in
    backup|restore|start|stop|status|enable_archivelog|list_backups|validate_restore)
      ensure_directories
      set_log_file "$ACTION"
      check_environment
      ;;
    *)
      usage
      exit 1
      ;;
  esac

  log "Host               : $HOST_NAME"
  log "Configured Host    : ${SERVER_HOSTNAME:-N/A}"
  log "Configured IP      : ${SERVER_IP:-N/A}"
  log "Oracle SID         : $ORACLE_SID"
  log "Oracle Home        : $ORACLE_HOME"
  log "Backup Directory   : $BACKUP_DIR"
  log "Log File           : $RUN_LOG"

  case "$ACTION" in
    backup)
      manage_listener start || notify_and_exit $?
      backup_database
      notify_and_exit $?
      ;;
    restore)
      manage_listener start || notify_and_exit $?
      restore_database
      notify_and_exit $?
      ;;
    start)
      manage_listener start || notify_and_exit $?
      start_database
      notify_and_exit $?
      ;;
    stop)
      stop_database
      local rc=$?
      if [[ "$rc" -eq 0 ]]; then
        manage_listener stop || notify_and_exit $?
      fi
      notify_and_exit "$rc"
      ;;
    status)
      show_status
      notify_and_exit $?
      ;;
    enable_archivelog)
      manage_listener start || notify_and_exit $?
      enable_archivelog
      notify_and_exit $?
      ;;
    list_backups)
      list_backups
      notify_and_exit $?
      ;;
    validate_restore)
      validate_restore
      notify_and_exit $?
      ;;
  esac
}

main
