#!/bin/bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99


# Deploy Java IC services for FCINT-8 / May 2026 PS.
# Usage:
#   chmod +x deploy_java_ic_services_from_list.sh
#   ./deploy_java_ic_services_from_list.sh
#
# Override defaults if needed:
#   ADMIN_URL=t3://hostname:PORT WL_USER=weblogic WL_PASSWORD='SECRET_REMOVED' ./deploy_java_ic_services_from_list.sh

export CLASSPATH="${CLASSPATH:-/PATH_TO_CONFIGURE}"

ADMIN_URL="${ADMIN_URL:-t3://hostname:PORT}"
WL_USER="${WL_USER:-weblogic}"
WL_PASSWORD="SECRET_REMOVED"
APP_DIR="${APP_DIR:-/PATH_TO_CONFIGURE}"
LOG_FILE="${LOG_FILE:-/PATH_TO_CONFIGURE}"
SLEEP_SECONDS="${SLEEP_SECONDS:-15}"
DEPLOY_MODE="${DEPLOY_MODE:-deploy}"

mkdir -p "$(dirname "$LOG_FILE")"

echo "STARTED Java IC deployments at $(date)" > "$LOG_FILE"
echo "ADMIN_URL=$ADMIN_URL" | tee -a "$LOG_FILE"
echo "APP_DIR=$APP_DIR" | tee -a "$LOG_FILE"
echo "DEPLOY_MODE=$DEPLOY_MODE" | tee -a "$LOG_FILE"

resolve_file() {
  file_name="$1"

  if [ -f "$APP_DIR/$file_name" ]; then
    printf '%s\n' "$file_name"
    return 0
  fi

  case "$file_name" in
    *[\*\?]*)
      old_nullglob="$(shopt -p nullglob 2>/dev/null || true)"
      shopt -s nullglob
      matches=( "$APP_DIR"/$file_name )
      if [ -n "$old_nullglob" ]; then
        eval "$old_nullglob"
      else
        shopt -u nullglob
      fi

      if [ ${#matches[@]} -eq 1 ]; then
        basename "${matches[0]}"
        return 0
      fi

      if [ ${#matches[@]} -gt 1 ]; then
        echo "MULTIPLE MATCHES for $file_name. Use exact WAR name:" | tee -a "$LOG_FILE" >&2
        printf '  %s\n' "${matches[@]}" | tee -a "$LOG_FILE" >&2
        return 1
      fi
      ;;
  esac

  echo "MISSING: $APP_DIR/$file_name" | tee -a "$LOG_FILE" >&2
  return 1
}

deploy_app() {
  file_name="$1"
  target="$2"
  app_name="${file_name%.war}"
  app_file="$(resolve_file "$file_name")" || return 1
  app_path="$APP_DIR/$app_file"
  deploy_log="$(mktemp /tmp/deploy_javaic.XXXXXX)"

  if [ ! -r "$app_path" ]; then
    echo "MISSING/NOT READABLE: $app_path" | tee -a "$LOG_FILE"
    rm -f "$deploy_log"
    return 1
  fi

  echo "Deploying $app_name from $app_file to $target" | tee -a "$LOG_FILE"

  if [ "$DEPLOY_MODE" = "redeploy" ]; then
    java weblogic.Deployer \
      -adminurl "$ADMIN_URL" \
      -user "$WL_USER" \
      -password "$WL_PASSWORD" \
      -name "$app_name" \
      -targets "$target" \
      -redeploy \
      -source "$app_path" \
      -remote \
      -upload > "$deploy_log" 2>&1
  else
    java weblogic.Deployer \
      -adminurl "$ADMIN_URL" \
      -user "$WL_USER" \
      -password "$WL_PASSWORD" \
      -name "$app_name" \
      -targets "$target" \
      -deploy "$app_path" \
      -remote \
      -upload > "$deploy_log" 2>&1
  fi

  rc=$?
  cat "$deploy_log" >> "$LOG_FILE"

  if [ $rc -eq 0 ]; then
    if grep -qi "Deployment is deferred" "$deploy_log"; then
      echo "DEFERRED: $app_name deployment to $target queued because target is unavailable" | tee -a "$LOG_FILE"
    else
      echo "SUCCESS: $app_name deployed to $target" | tee -a "$LOG_FILE"
    fi
  else
    echo "FAILED : $app_name deployment to $target failed, rc=$rc" | tee -a "$LOG_FILE"
  fi

  rm -f "$deploy_log"
  sleep "$SLEEP_SECONDS"
  return $rc
}

failures=0

deploy_app "cmc-comp*.war" "Plato" || failures=$((failures + 1))
deploy_app "fcubs-audit-service-8.24.0.war" "Plato_1" || failures=$((failures + 1))
deploy_app "fcubs-charge-calc-services-8.24.0.war" "Plato_1" || failures=$((failures + 1))
deploy_app "fcubs-co-batch-services-8.24.0.war" "Plato_1" || failures=$((failures + 1))
deploy_app "fcubs-co-mo-lov-service-8.24.0.war" "Plato" || failures=$((failures + 1))
deploy_app "fcubs-customer-acc-service-8.24.0.war" "Plato_1" || failures=$((failures + 1))
deploy_app "fcubs-eca-services-8.24.0.war" "Plato" || failures=$((failures + 1))
deploy_app "fcubs-ext-accounting-services-8.24.0.war" "Plato" || failures=$((failures + 1))
deploy_app "fcubs-intchg-accting-services-8.24.0.war" "Plato_1" || failures=$((failures + 1))
deploy_app "fcubs-interest-accrual-services-8.24.0.war" "Plato_1" || failures=$((failures + 1))
deploy_app "fcubs-interest-allocate-services-8.24.0.war" "Plato_1" || failures=$((failures + 1))
deploy_app "fcubs-interest-batch-services-8.24.0.war" "Plato_1" || failures=$((failures + 1))
deploy_app "fcubs-interest-calc-services-8.24.0.war" "Plato_1" || failures=$((failures + 1))
deploy_app "fcubs-interest-extrp-service-8.24.0.war" "Plato_1" || failures=$((failures + 1))
deploy_app "fcubs-interest-liquidation-services-8.24.0.war" "Plato_1" || failures=$((failures + 1))
deploy_app "fcubs-interest-resolve-services-8.24.0.war" "Plato" || failures=$((failures + 1))
deploy_app "fcubs-ln-mo-dashboard-service-8.24.0.war" "Plato" || failures=$((failures + 1))
deploy_app "fcubs-online-liquidation-services-8.24.0.war" "Plato" || failures=$((failures + 1))
deploy_app "fcubs-signature-service-8.24.0.war" "Plato" || failures=$((failures + 1))
deploy_app "fcubs-smsvalidation-service-8.24.0.war" "Plato_1" || failures=$((failures + 1))
deploy_app "fcubs-td-alloc-services-8.24.0.war" "Plato" || failures=$((failures + 1))
deploy_app "fcubs-td-deposit-services-8.24.0.war" "Plato" || failures=$((failures + 1))
deploy_app "fcubs-td-maturity-services-8.24.0.war" "Plato" || failures=$((failures + 1))
deploy_app "fcubs-td-mo-adapter-service-8.24.0.war" "Plato" || failures=$((failures + 1))
deploy_app "fcubs-td-mo-dashboard-service-8.24.0.war" "Plato_1" || failures=$((failures + 1))
deploy_app "fcubs-td-mo-operations-services-8.24.0.war" "Plato" || failures=$((failures + 1))
deploy_app "obbrn-casacustomeraccount-services-8.24.0.war" "Plato_1" || failures=$((failures + 1))
deploy_app "obic-intch*.war" "Plato" || failures=$((failures + 1))
deploy_app "obic-inter*.war" "Plato" || failures=$((failures + 1))
deploy_app "obpy-com*.war" "Plato" || failures=$((failures + 1))
deploy_app "obpy-cust*.war" "Plato" || failures=$((failures + 1))
deploy_app "obremo-srv-acc-credit-card-details-service-8.24.0.war" "Plato" || failures=$((failures + 1))
deploy_app "obremo-srv-acc-safe-Banking-details-service-8.24.0.war" "Plato" || failures=$((failures + 1))
deploy_app "obremo-srv-acc-signature-details-service-8.24.0.war" "Plato" || failures=$((failures + 1))
deploy_app "obremo-srv-customer-query-service-8.24.0.war" "Plato" || failures=$((failures + 1))
deploy_app "plato-config-service-8.24.0.war" "Plato" || failures=$((failures + 1))
deploy_app "plato-discovery-service-8.24.0.war" "Plato" || failures=$((failures + 1))
deploy_app "sms-comp*.war" "Plato_1" || failures=$((failures + 1))

echo "COMPLETED Java IC deployments at $(date). failures=$failures" | tee -a "$LOG_FILE"

exit $failures
