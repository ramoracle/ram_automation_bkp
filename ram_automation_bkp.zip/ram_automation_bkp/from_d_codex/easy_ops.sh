#!/usr/bin/env bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99


set -euo pipefail

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_REMOTE_USER="${REMOTE_USER:-USERNAME}"

pause() {
  echo
  read -r -p "Press Enter to continue..." _
}

header() {
  clear
  echo "============================================================"
  echo "               Easy WebLogic Operations"
  echo "============================================================"
  echo "Folder : ${BASE_DIR}"
  echo
}

choose_domain() {
  local choice
  header
  echo "Choose domain"
  echo "1. PLATOCOMMON"
  echo "2. OBREMO"
  echo "0. Exit"
  echo
  read -r -p "Enter choice: " choice

  case "${choice}" in
    1)
      DOMAIN_NAME="PLATOCOMMON"
      OPS_SCRIPT="./PLATOCOMMON_ops.sh"
      SCRIPT_PATTERN="Platocommon*.sh"
      ;;
    2)
      DOMAIN_NAME="OBREMO"
      OPS_SCRIPT="./OBREMO_ops.sh"
      SCRIPT_PATTERN="OBREMO*.sh"
      ;;
    0)
      exit 0
      ;;
    *)
      echo "Invalid choice."
      pause
      choose_domain
      ;;
  esac
}

choose_script() {
  local choice idx
  local -a scripts=()

  while IFS= read -r file; do
    scripts+=("$file")
  done < <(find "${BASE_DIR}" -maxdepth 1 -type f -name "${SCRIPT_PATTERN}" ! -name "*undeploy*" | sort)

  if [[ "${#scripts[@]}" -eq 0 ]]; then
    echo "No deploy scripts found for ${DOMAIN_NAME}."
    return 1
  fi

  echo
  echo "Choose deploy script"
  echo "------------------------------------------------------------"
  for idx in "${!scripts[@]}"; do
    printf "%2d. %s\n" "$((idx + 1))" "$(basename "${scripts[$idx]}")"
  done
  echo " 0. Back"
  echo
  read -r -p "Enter choice: " choice

  [[ "${choice}" == "0" ]] && return 1
  if ! [[ "${choice}" =~ ^[0-9]+$ ]] || (( choice < 1 || choice > ${#scripts[@]} )); then
    echo "Invalid choice."
    return 1
  fi

  SELECTED_SCRIPT="$(basename "${scripts[$((choice - 1))]}")"
  return 0
}

choose_managed_server() {
  local choice
  echo
  echo "Choose managed server"
  if [[ "${DOMAIN_NAME}" == "PLATOCOMMON" ]]; then
    echo "1. plato_core"
    echo "2. plato_moc"
    echo "3. plato_sms"
    read -r -p "Enter choice: " choice
    case "${choice}" in
      1) SELECTED_MANAGED="plato_core" ;;
      2) SELECTED_MANAGED="plato_moc" ;;
      3) SELECTED_MANAGED="plato_sms" ;;
      *) echo "Invalid choice."; return 1 ;;
    esac
  else
    echo "1. new_ManagedServer_1"
    echo "2. new_ManagedServer_2"
    echo "3. new_ManagedServer_3"
    read -r -p "Enter choice: " choice
    case "${choice}" in
      1) SELECTED_MANAGED="new_ManagedServer_1" ;;
      2) SELECTED_MANAGED="new_ManagedServer_2" ;;
      3) SELECTED_MANAGED="new_ManagedServer_3" ;;
      *) echo "Invalid choice."; return 1 ;;
    esac
  fi
}

run_with_remote_user() {
  local action="$1"
  shift
  local remote_user
  read -r -p "Remote SSH user [${DEFAULT_REMOTE_USER}]: " remote_user
  remote_user="${remote_user:-${DEFAULT_REMOTE_USER}}"
  REMOTE_USER="${remote_user}" "${OPS_SCRIPT}" "${action}" "$@"
}

domain_menu() {
  local action version undeploy_name

  while true; do
    header
    echo "Domain : ${DOMAIN_NAME}"
    echo "Script : ${SELECTED_SCRIPT:-Not selected}"
    echo
    echo "1. Show current WAR versions"
    echo "2. Update WAR version"
    echo "3. Deploy"
    echo "4. Build undeploy script"
    echo "5. Start Admin Server"
    echo "6. Stop Admin Server"
    echo "7. Start Node Manager"
    echo "8. Stop Node Manager"
    echo "9. Start one Managed Server"
    echo "10. Stop one Managed Server"
    echo "11. Start All"
    echo "12. Stop All"
    echo "13. Change domain"
    echo "0. Exit"
    echo
    read -r -p "Enter choice: " action

    case "${action}" in
      1)
        choose_script || { pause; continue; }
        "${OPS_SCRIPT}" show_versions "${SELECTED_SCRIPT}"
        pause
        ;;
      2)
        choose_script || { pause; continue; }
        read -r -p "Enter new WAR version (example 6.35.0): " version
        "${OPS_SCRIPT}" update_version "${SELECTED_SCRIPT}" "${version}"
        pause
        ;;
      3)
        choose_script || { pause; continue; }
        "${OPS_SCRIPT}" deploy "${SELECTED_SCRIPT}"
        pause
        ;;
      4)
        choose_script || { pause; continue; }
        undeploy_name="${SELECTED_SCRIPT%.sh}_undeploy.sh"
        read -r -p "Undeploy output file [${undeploy_name}]: " custom_name
        undeploy_name="${custom_name:-${undeploy_name}}"
        "${OPS_SCRIPT}" build_undeploy "${SELECTED_SCRIPT}" "${undeploy_name}"
        pause
        ;;
      5)
        run_with_remote_user start_admin
        pause
        ;;
      6)
        run_with_remote_user stop_admin
        pause
        ;;
      7)
        run_with_remote_user start_nodemanager
        pause
        ;;
      8)
        run_with_remote_user stop_nodemanager
        pause
        ;;
      9)
        choose_managed_server || { pause; continue; }
        run_with_remote_user start_managed "${SELECTED_MANAGED}"
        pause
        ;;
      10)
        choose_managed_server || { pause; continue; }
        run_with_remote_user stop_managed "${SELECTED_MANAGED}"
        pause
        ;;
      11)
        run_with_remote_user start_all
        pause
        ;;
      12)
        run_with_remote_user stop_all
        pause
        ;;
      13)
        return
        ;;
      0)
        exit 0
        ;;
      *)
        echo "Invalid choice."
        pause
        ;;
    esac
  done
}

main() {
  cd "${BASE_DIR}"
  while true; do
    choose_domain
    domain_menu
  done
}

main "$@"
