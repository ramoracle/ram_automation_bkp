# SANITIZED PUBLICATION TEMPLATE. Not runtime-tested.
import argparse
import os
import re
import subprocess
import sys
import time


DEPLOYER_RE = re.compile(r"\bjava\s+weblogic\.Deployer\b", re.IGNORECASE)
PATTERNS = {
    "adminurl": re.compile(r"-adminurl\s+(\S+)", re.IGNORECASE),
    "user": re.compile(r"-user\s+(\S+)", re.IGNORECASE),
    "password": re.compile(r"-password\s+(\S+)", re.IGNORECASE),
    "name": re.compile(r"-name\s+(\S+)", re.IGNORECASE),
    "targets": re.compile(r"-targets\s+(\S+)", re.IGNORECASE),
}


def parse_commands(path):
    commands = []
    with open(path, "r", encoding="utf-8", errors="ignore") as handle:
        for raw in handle:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if not DEPLOYER_RE.search(line):
                continue

            values = {}
            for key, pattern in PATTERNS.items():
                match = pattern.search(line)
                values[key] = match.group(1) if match else ""

            if not values.get("name"):
                continue

            command = "java weblogic.Deployer -adminurl {adminurl} -user {user} -password {password} -name {name}".format(**values)
            if values.get("targets"):
                command += " -targets {}".format(values["targets"])
            command += " -undeploy"
            commands.append(command)
    return commands


def build_script(deploy_script, commands):
    base = os.path.splitext(os.path.basename(deploy_script))[0]
    log_file = "{}_undeploy_{}.log".format(base, time.strftime("%Y%m%d_%H%M%S"))
    lines = [
        "#!/bin/bash",
        "set -euo pipefail",
        'echo "Started undeploy for {}" > "{}"'.format(base, log_file),
        "{",
    ]
    lines.extend(commands)
    lines.append('} >> "{}" 2>&1'.format(log_file))
    lines.append("")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Create or run undeploy commands from an existing deploy script")
    parser.add_argument("deploy_script", help="Existing deploy shell script")
    parser.add_argument("--write-script", help="Write an undeploy .sh file instead of running")
    parser.add_argument("--run", action="store_true", help="Run undeploy commands directly")
    args = parser.parse_args()

    if not os.path.exists(args.deploy_script):
        print("Deploy script not found: {}".format(args.deploy_script))
        sys.exit(1)

    commands = parse_commands(args.deploy_script)
    if not commands:
        print("No deployer commands found in {}".format(args.deploy_script))
        sys.exit(1)

    if args.write_script:
        content = build_script(args.deploy_script, commands)
        with open(args.write_script, "w", encoding="utf-8") as handle:
            handle.write(content)
        print("Undeploy script written to {}".format(args.write_script))
        return

    if args.run:
        for command in commands:
            print(command)
            subprocess.check_call(command, shell=True)
        return

    for command in commands:
        print(command)


if __name__ == "__main__":
    main()
