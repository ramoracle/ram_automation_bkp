# SANITIZED PUBLICATION TEMPLATE. Not runtime-tested.
import argparse
import hashlib
import hmac
import json
import mimetypes
import os
import re
import secrets
import subprocess
import time
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from socketserver import ThreadingMixIn
from typing import Any, Dict, List, Optional
from urllib.parse import unquote, urlparse


DEFAULT_SCRIPT_DIR = Path(
    r"/PATH_TO_CONFIGURE"
)
UI_DIR = Path(__file__).with_name("ui")
DOMAIN_CONFIG_FILE = "weblogic_ui_domains.json"
AUTH_CONFIG_FILE = "weblogic_ui_auth.json"
SESSION_COOKIE_NAME = "weblogic_ui_session"
DEFAULT_SESSION_HOURS = 12
PASSWORD_ITERATIONS = 200000
DEFAULT_ACTION_TIMEOUT_SECONDS = int(os.environ.get("WEBLOGIC_UI_ACTION_TIMEOUT", "300"))
DEFAULT_DOMAIN_CONFIGS = {
    "PLATOCOMMON": {
        "label": "PLATOCOMMON",
        "ops_script": "PLATOCOMMON_ops.sh",
        "remote_host": "IP_ADDRESS",
        "admin_url": "t3://hostname:PORT",
        "managed_servers": ["plato_core", "plato_moc", "plato_sms"],
        "script_keywords": ["plato", "platocommon"],
    },
    "OBTFPM": {
        "label": "OBTFPM",
        "ops_script": "OBTFPM_ops.sh",
        "remote_host": "",
        "admin_url": "t3://hostname:PORT",
        "managed_servers": [],
        "script_keywords": ["obtfpm", "fpm"],
        "execution_mode": "local",
        "domain_bin": "/PATH_TO_CONFIGURE",
        "wl_home": "/PATH_TO_CONFIGURE",
        "admin_server": "AdminServer",
    },
    "OBREMO": {
        "label": "OBREMO",
        "ops_script": "OBREMO_ops.sh",
        "remote_host": "IP_ADDRESS",
        "admin_url": "t3://hostname:PORT",
        "managed_servers": ["new_ManagedServer_1", "new_ManagedServer_2", "new_ManagedServer_3"],
        "script_keywords": ["obremo"],
    },
}

DEFAULT_AUTH_CONFIG = {
    "session_hours": DEFAULT_SESSION_HOURS,
    "users": [
        {
            "username": "USERNAME",
            "role": "admin",
            "password": {
                "algorithm": "pbkdf2_sha256",
                "iterations": PASSWORD_ITERATIONS,
                "salt": "a8b36ffdc2c2931bd6a918b6f90a078b",
                "hash": "849f55e8b41e7dfe5cc6f8cf0ed32dc099fd496060ab0a32238f1115874ee4cc",
            },
        },
        {
            "username": "deployer",
            "role": "operator",
            "password": {
                "algorithm": "pbkdf2_sha256",
                "iterations": PASSWORD_ITERATIONS,
                "salt": "d5247f669271ab733ae0cbf70f9f4c33",
                "hash": "e88c541ccae1ae1636f45b7dee674c9acb3bfb6dd27c4f6f750796bf19851fad",
            },
        },
    ],
}


def hash_password(password, salt, iterations):
    return hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        bytes.fromhex(salt),
        iterations,
    ).hex()


def make_password_record(password):
    salt = secrets.token_hex(16)
    return {
        "algorithm": "pbkdf2_sha256",
        "iterations": PASSWORD_ITERATIONS,
        "salt": salt,
        "hash": hash_password(password, salt, PASSWORD_ITERATIONS),
    }


def verify_password(password, password_record):
    if not password_record:
        return False
    if password_record.get("algorithm") != "pbkdf2_sha256":
        return False
    salt = password_record.get("salt", "")
    stored_hash = password_record.get("hash", "")
    iterations = int(password_record.get("iterations", PASSWORD_ITERATIONS))
    if not salt or not stored_hash:
        return False
    candidate = hash_password(password, salt, iterations)
    return hmac.compare_digest(candidate, stored_hash)


def normalize_auth_user(user):
    normalized = {
        "username": str(user.get("username", "")).strip(),
        "role": str(user.get("role", "monitor")).strip().lower() or "monitor",
        "password": dict(user.get("password", {})),
    }
    if normalized["role"] not in {"admin", "operator", "monitor"}:
        normalized["role"] = "monitor"
    return normalized


def load_auth_config(script_dir):
    config_path = script_dir / AUTH_CONFIG_FILE
    if not config_path.exists():
        return {
            "session_hours": DEFAULT_AUTH_CONFIG["session_hours"],
            "users": [normalize_auth_user(user) for user in DEFAULT_AUTH_CONFIG["users"]],
        }

    try:
        loaded = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise ValueError("Failed to read {}: {}".format(config_path.name, exc))

    if not isinstance(loaded, dict):
        raise ValueError("{} must contain a JSON object.".format(config_path.name))

    users = loaded.get("users", [])
    if not isinstance(users, list):
        raise ValueError("{} must contain a users array.".format(config_path.name))

    return {
        "session_hours": int(loaded.get("session_hours", DEFAULT_SESSION_HOURS)),
        "users": [normalize_auth_user(user) for user in users if isinstance(user, dict)],
    }


def save_auth_config(path, auth_config):
    payload = {
        "session_hours": int(auth_config.get("session_hours", DEFAULT_SESSION_HOURS)),
        "users": auth_config.get("users", []),
    }
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def normalize_domain_config(name, config):
    base = DEFAULT_DOMAIN_CONFIGS.get(name, {})
    merged = dict(base)
    merged.update(config or {})
    merged["label"] = merged.get("label") or name
    merged["ops_script"] = merged.get("ops_script") or "{}_ops.sh".format(name)
    merged["remote_host"] = merged.get("remote_host", "")
    merged["admin_url"] = merged.get("admin_url", "")
    merged["managed_servers"] = [str(item) for item in merged.get("managed_servers", []) if str(item).strip()]
    merged["script_keywords"] = [
        str(item).lower() for item in merged.get("script_keywords", []) if str(item).strip()
    ] or [name.lower()]
    merged["ssh_user"] = str(merged.get("ssh_user", "")).strip()
    merged["ssh_opts"] = str(merged.get("ssh_opts", "")).strip()
    merged["execution_mode"] = str(merged.get("execution_mode", "auto")).strip() or "auto"
    merged["deploy_script_name"] = str(merged.get("deploy_script_name", "")).strip()
    merged["deploy_script_dir"] = str(merged.get("deploy_script_dir", "")).strip()
    merged["automation_dir"] = str(
        merged.get("automation_dir") or merged.get("deploy_script_dir") or ""
    ).strip()
    merged["war_root_dir"] = str(merged.get("war_root_dir", "")).strip()
    merged["start_stop_helper"] = str(merged.get("start_stop_helper", "")).strip()
    merged["wlst_bin"] = str(merged.get("wlst_bin", "")).strip()
    merged["start_stop_set_cwd"] = str(
        merged.get("start_stop_set_cwd") or merged.get("automation_dir") or ""
    ).strip()
    merged["node_manager_user"] = str(merged.get("node_manager_user", "")).strip()
    merged["node_manager_password"] = str(merged.get("node_manager_password", "")).strip()
    merged["domain_bin"] = str(merged.get("domain_bin", "")).strip()
    merged["domain_home"] = str(merged.get("domain_home", "")).strip()
    merged["wl_home"] = str(merged.get("wl_home", "")).strip()
    merged["nodemanager_bin"] = str(merged.get("nodemanager_bin", "")).strip()
    merged["admin_server"] = str(merged.get("admin_server", "AdminServer")).strip() or "AdminServer"
    merged["python_bin"] = str(merged.get("python_bin", "python3")).strip() or "python3"
    return merged


def load_domain_configs(script_dir):
    configs = {
        name: normalize_domain_config(name, config)
        for name, config in DEFAULT_DOMAIN_CONFIGS.items()
    }
    config_path = script_dir / DOMAIN_CONFIG_FILE
    if not config_path.exists():
        return configs

    try:
        loaded = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise ValueError(
            "Failed to read {}: {}".format(config_path.name, exc)
        )

    if not isinstance(loaded, dict):
        raise ValueError("{} must contain a JSON object.".format(config_path.name))

    configs = {}
    for name, config in loaded.items():
        if not isinstance(config, dict):
            raise ValueError("Domain {} in {} must be a JSON object.".format(name, config_path.name))
        configs[name] = normalize_domain_config(name, config)

    return configs

DEPLOYER_RE = re.compile(r"\bjava\s+weblogic\.Deployer\b", re.IGNORECASE)
FLAG_PATTERNS = {
    "admin_url": re.compile(r"-adminurl\s+(\S+)", re.IGNORECASE),
    "user": re.compile(r"-user\s+(\S+)", re.IGNORECASE),
    "password": re.compile(r"-password\s+(\S+)", re.IGNORECASE),
    "name": re.compile(r"-name\s+(\S+)", re.IGNORECASE),
    "targets": re.compile(r"-targets\s+(\S+)", re.IGNORECASE),
}
ACTION_PATTERNS = {
    "deploy": re.compile(r"-deploy\s+(\S+)", re.IGNORECASE),
    "undeploy": re.compile(r"\b-undeploy\b", re.IGNORECASE),
    "redeploy": re.compile(r"-redeploy\s+(\S+)", re.IGNORECASE),
}
LOG_RE = re.compile(r">\s*(\S+\.log)\s*$", re.IGNORECASE)
CLASSPATH_RE = re.compile(r"export\s+CLASSPATH=(.+)")


class DeploymentEntry:
    def __init__(
        self,
        line_number,
        action,
        admin_url,
        user,
        password,
        name,
        target,
        artifact_path,
        raw_command,
    ):
        self.line_number = line_number
        self.action = action
        self.admin_url = admin_url
        self.user = user
        self.password = password
        self.name = name
        self.target = target
        self.artifact_path = artifact_path
        self.raw_command = raw_command

    def to_dict(self):
        return {
            "line_number": self.line_number,
            "action": self.action,
            "admin_url": self.admin_url,
            "user": self.user,
            "password": self.password,
            "name": self.name,
            "target": self.target,
            "artifact_path": self.artifact_path,
            "raw_command": self.raw_command,
        }


class ScriptModel:
    def __init__(
        self,
        file_name,
        full_path,
        script_name,
        log_path,
        classpath,
        admin_urls,
        users,
        targets,
        entries,
    ):
        self.file_name = file_name
        self.full_path = full_path
        self.script_name = script_name
        self.log_path = log_path
        self.classpath = classpath
        self.admin_urls = admin_urls
        self.users = users
        self.targets = targets
        self.entries = entries


def shell_quote(value):
    return "'" + value.replace("'", "'\"'\"'") + "'"


def parse_script(script_path):
    log_path = None
    classpath = None
    admin_urls = []
    users = []
    targets = []
    entries = []

    lines = script_path.read_text(encoding="utf-8", errors="ignore").splitlines()
    for line_number, raw_line in enumerate(lines, start=1):
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("#"):
            continue

        if classpath is None:
            classpath_match = CLASSPATH_RE.search(stripped)
            if classpath_match:
                classpath = classpath_match.group(1).strip()

        if log_path is None:
            log_match = LOG_RE.search(stripped)
            if log_match:
                log_path = log_match.group(1)

        if not DEPLOYER_RE.search(stripped):
            continue

        values = {}
        for key, pattern in FLAG_PATTERNS.items():
            match = pattern.search(stripped)
            values[key] = match.group(1) if match else ""

        action = "deploy"
        artifact_path = None
        for candidate, pattern in ACTION_PATTERNS.items():
            match = pattern.search(stripped)
            if match:
                action = candidate
                if match.groups():
                    artifact_path = match.group(1)
                break

        entry = DeploymentEntry(
            line_number=line_number,
            action=action,
            admin_url=values["admin_url"],
            user=values["user"],
            password=values["password"],
            name=values["name"],
            target=values["targets"],
            artifact_path=artifact_path,
            raw_command=stripped,
        )
        entries.append(entry)

        if entry.admin_url and entry.admin_url not in admin_urls:
            admin_urls.append(entry.admin_url)
        if entry.user and entry.user not in users:
            users.append(entry.user)
        if entry.target and entry.target not in targets:
            targets.append(entry.target)

    return ScriptModel(
        file_name=script_path.name,
        full_path=str(script_path),
        script_name=script_path.stem,
        log_path=log_path,
        classpath=classpath,
        admin_urls=admin_urls,
        users=users,
        targets=targets,
        entries=entries,
    )


def load_catalog(script_dir):
    if not script_dir.exists():
        return {}
    catalog = {}
    for script_path in sorted(script_dir.glob("*.sh")):
        model = parse_script(script_path)
        catalog[model.file_name] = model
    return catalog


def summarize_script(model):
    passwords = [entry.password for entry in model.entries if entry.password]
    return {
        "file_name": model.file_name,
        "full_path": model.full_path,
        "script_name": model.script_name,
        "log_path": model.log_path,
        "classpath": model.classpath,
        "admin_urls": model.admin_urls,
        "users": model.users,
        "password": passwords[0] if passwords else "",
        "targets": model.targets,
        "service_count": len(model.entries),
    }


def resolve_artifact_path(entry, artifact_root):
    if not entry.artifact_path:
        return None
    root = artifact_root.strip()
    if not root:
        return entry.artifact_path
    return str(Path(root) / Path(entry.artifact_path).name).replace("\\", "/")


def generate_deploy_script(
    model,
    action,
    admin_url,
    user,
    password,
    target_override,
    artifact_root,
    classpath,
    log_dir,
):
    script_action = action.lower()
    if script_action not in {"deploy", "undeploy", "redeploy"}:
        raise ValueError("Unsupported action.")

    log_file = f"{model.script_name}_{script_action}.log"
    log_path = str(Path(log_dir) / log_file).replace("\\", "/") if log_dir.strip() else log_file
    output_name = f"{model.script_name}_{script_action}.sh"

    lines = [
        "#!/bin/bash",
        "set -euo pipefail",
    ]
    if classpath.strip():
        lines.append(f"export CLASSPATH={classpath.strip()}")
    lines.extend(
        [
            f'echo "Started {script_action} for {model.script_name}" > {shell_quote(log_path)}',
            "{",
        ]
    )

    for entry in model.entries:
        target = target_override.strip() or entry.target
        cmd_parts = [
            "java weblogic.Deployer",
            f"-adminurl {admin_url}",
            f"-user {user}",
            f"-password {password}",
            f"-name {entry.name}",
        ]
        if target:
            cmd_parts.append(f"-targets {target}")

        if script_action == "deploy":
            artifact_path = resolve_artifact_path(entry, artifact_root)
            if not artifact_path:
                continue
            cmd_parts.append(f"-deploy {artifact_path}")
            cmd_parts.append("-remote -upload")
        elif script_action == "redeploy":
            artifact_path = resolve_artifact_path(entry, artifact_root)
            if not artifact_path:
                continue
            cmd_parts.append(f"-redeploy {artifact_path}")
            cmd_parts.append("-remote -upload")
        else:
            cmd_parts.append("-undeploy")

        lines.append(" ".join(cmd_parts))

    lines.append(f"}} >> {shell_quote(log_path)} 2>&1")
    lines.append("")
    return {output_name: "\n".join(lines)}


def generate_lifecycle_scripts(
    domain_home,
    wl_home,
    admin_url,
    admin_server_name,
    managed_servers,
    log_dir,
):
    domain_home = domain_home.rstrip("/\\")
    wl_home = wl_home.rstrip("/\\")
    admin_server_name = admin_server_name.strip() or "AdminServer"
    log_dir = log_dir.rstrip("/\\") or "$HOME/weblogic_logs"
    managed_servers = [server.strip() for server in managed_servers if server.strip()]

    start_admin = f"""#!/bin/bash
set -euo pipefail
DOMAIN_HOME={shell_quote(domain_home)}
LOG_DIR={shell_quote(log_dir)}
mkdir -p "$LOG_DIR"
nohup "$DOMAIN_HOME/startWebLogic.sh" > "$LOG_DIR/{admin_server_name}.out" 2>&1 &
echo "Admin Server start triggered."
"""

    stop_admin = f"""#!/bin/bash
set -euo pipefail
DOMAIN_HOME={shell_quote(domain_home)}
LOG_DIR={shell_quote(log_dir)}
mkdir -p "$LOG_DIR"
"$DOMAIN_HOME/bin/stopWebLogic.sh" > "$LOG_DIR/{admin_server_name}-stop.out" 2>&1
echo "Admin Server stop triggered."
"""

    start_nodemanager = f"""#!/bin/bash
set -euo pipefail
WL_HOME={shell_quote(wl_home)}
LOG_DIR={shell_quote(log_dir)}
mkdir -p "$LOG_DIR"
nohup "$WL_HOME/server/bin/startNodeManager.sh" > "$LOG_DIR/nodemanager.out" 2>&1 &
echo "Node Manager start triggered."
"""

    stop_nodemanager = f"""#!/bin/bash
set -euo pipefail
WL_HOME={shell_quote(wl_home)}
LOG_DIR={shell_quote(log_dir)}
mkdir -p "$LOG_DIR"
if [ -x "$WL_HOME/server/bin/stopNodeManager.sh" ]; then
  "$WL_HOME/server/bin/stopNodeManager.sh" > "$LOG_DIR/nodemanager-stop.out" 2>&1
else
  pkill -f 'weblogic.NodeManager' || true
fi
echo "Node Manager stop triggered."
"""

    files = {
        "start_admin.sh": start_admin,
        "stop_admin.sh": stop_admin,
        "start_nodemanager.sh": start_nodemanager,
        "stop_nodemanager.sh": stop_nodemanager,
    }

    start_all_lines = [
        "#!/bin/bash",
        "set -euo pipefail",
        "./start_nodemanager.sh",
        "sleep 10",
        "./start_admin.sh",
        "sleep 20",
    ]
    stop_all_lines = [
        "#!/bin/bash",
        "set -euo pipefail",
    ]

    for server_name in managed_servers:
        safe_name = server_name.replace(" ", "_")
        start_managed = f"""#!/bin/bash
set -euo pipefail
DOMAIN_HOME={shell_quote(domain_home)}
ADMIN_URL={shell_quote(admin_url)}
LOG_DIR={shell_quote(log_dir)}
mkdir -p "$LOG_DIR"
nohup "$DOMAIN_HOME/bin/startManagedWebLogic.sh" {shell_quote(server_name)} "$ADMIN_URL" > "$LOG_DIR/{safe_name}.out" 2>&1 &
echo "Managed Server {server_name} start triggered."
"""
        stop_managed = f"""#!/bin/bash
set -euo pipefail
DOMAIN_HOME={shell_quote(domain_home)}
ADMIN_URL={shell_quote(admin_url)}
LOG_DIR={shell_quote(log_dir)}
mkdir -p "$LOG_DIR"
"$DOMAIN_HOME/bin/stopManagedWebLogic.sh" {shell_quote(server_name)} "$ADMIN_URL" > "$LOG_DIR/{safe_name}-stop.out" 2>&1
echo "Managed Server {server_name} stop triggered."
"""
        files[f"start_{safe_name}.sh"] = start_managed
        files[f"stop_{safe_name}.sh"] = stop_managed
        start_all_lines.append(f"./start_{safe_name}.sh")
        start_all_lines.append("sleep 5")
        stop_all_lines.append(f"./stop_{safe_name}.sh")

    stop_all_lines.extend(
        [
            "./stop_admin.sh",
            "./stop_nodemanager.sh",
        ]
    )
    files["start_all.sh"] = "\n".join(start_all_lines) + "\n"
    files["stop_all.sh"] = "\n".join(stop_all_lines) + "\n"
    return files


def list_domain_scripts(catalog, domain_configs):
    result = {}
    for domain_name, config in domain_configs.items():
        keywords = config["script_keywords"]
        matches = []
        for model in catalog.values():
            script_name = model.file_name.lower()
            if any(keyword in script_name for keyword in keywords):
                matches.append(
                    {
                        "file_name": model.file_name,
                        "script_name": model.script_name,
                        "service_count": len(model.entries),
                        "targets": model.targets,
                    }
                )
        configured_script = config.get("deploy_script_name", "")
        if configured_script and all(match["file_name"] != configured_script for match in matches):
            matches.insert(
                0,
                {
                    "file_name": configured_script,
                    "script_name": Path(configured_script).stem,
                    "service_count": 0,
                    "targets": config.get("managed_servers", []),
                },
            )
        result[domain_name] = matches
    return result


def domain_payload(catalog, domain_configs):
    scripts = list_domain_scripts(catalog, domain_configs)
    payload = []
    for domain_name, config in domain_configs.items():
        payload.append(
            {
                "name": domain_name,
                "label": config["label"],
                "remote_host": config["remote_host"],
                "ssh_user": config.get("ssh_user", ""),
                "admin_url": config["admin_url"],
                "managed_servers": config["managed_servers"],
                "ops_script": config["ops_script"],
                "execution_mode": config.get("execution_mode", "auto"),
                "deploy_script_dir": config.get("deploy_script_dir", ""),
                "deploy_script_name": config.get("deploy_script_name", ""),
                "scripts": scripts.get(domain_name, []),
            }
        )
    return payload


def build_domain_command(script_dir, domain_configs, domain_name, action, body):
    config = domain_configs.get(domain_name)
    if not config:
        raise ValueError("Unknown domain.")

    ops_script = script_dir / config["ops_script"]
    if not ops_script.exists():
        raise ValueError("Operations script not found: {}".format(ops_script.name))

    command = ["bash", str(ops_script), action]
    if action in {"deploy", "show_versions"}:
        command.append(body.get("script_name", ""))
    elif action == "update_version":
        command.append(body.get("script_name", ""))
        command.append(body.get("version", ""))
    elif action == "build_undeploy":
        command.append(body.get("script_name", ""))
        command.append(body.get("output_script", ""))
    elif action in {"start_managed", "stop_managed"}:
        command.append(body.get("managed_server", ""))

    return command, config


def validate_domain_command(action, command):
    if action in {"deploy", "show_versions"} and not command[-1]:
        raise ValueError("Choose a deploy script first.")
    if action == "update_version":
        if not command[-2]:
            raise ValueError("Choose a deploy script first.")
        if not command[-1]:
            raise ValueError("Enter a new version first.")
    if action == "build_undeploy":
        if not command[-2]:
            raise ValueError("Choose a deploy script first.")
        if not command[-1]:
            raise ValueError("Enter an output undeploy file name.")
    if action in {"start_managed", "stop_managed"} and not command[-1]:
        raise ValueError("Choose a managed server first.")


def run_domain_action(script_dir, domain_configs, domain_name, action, body):
    command, config = build_domain_command(script_dir, domain_configs, domain_name, action, body)
    validate_domain_command(action, command)
    command_text = " ".join(command)

    env = os.environ.copy()
    env["DOMAIN_NAME"] = domain_name
    env["ADMIN_URL"] = config.get("admin_url", "")
    env["MANAGED_SERVERS_CSV"] = ",".join(config.get("managed_servers", []))
    if config.get("execution_mode"):
        env["EXECUTION_MODE"] = config["execution_mode"]
    if config.get("deploy_script_dir"):
        env["DEPLOY_SCRIPT_DIR"] = config["deploy_script_dir"]
    if config.get("automation_dir"):
        env["AUTOMATION_DIR"] = config["automation_dir"]
    if config.get("admin_server"):
        env["ADMIN_SERVER"] = config["admin_server"]
    if config.get("domain_bin"):
        env["DOMAIN_BIN"] = config["domain_bin"]
    if config.get("domain_home"):
        env["DOMAIN_HOME"] = config["domain_home"]
    if config.get("wl_home"):
        env["WL_HOME"] = config["wl_home"]
    if config.get("nodemanager_bin"):
        env["NODEMANAGER_BIN"] = config["nodemanager_bin"]
    if config.get("cluster_name"):
        env["CLUSTER_NAME"] = config["cluster_name"]
    if config.get("start_stop_helper"):
        env["START_STOP_HELPER"] = config["start_stop_helper"]
    if config.get("wlst_bin"):
        env["WLST_BIN"] = config["wlst_bin"]
    if config.get("start_stop_set_cwd"):
        env["START_STOP_SET_CWD"] = config["start_stop_set_cwd"]
    if config.get("node_manager_user"):
        env["NODE_MANAGER_USER"] = config["node_manager_user"]
    if config.get("node_manager_password"):
        env["NODE_MANAGER_PASSWORD"] = config["node_manager_password"]
    if config.get("python_bin"):
        env["PYTHON_BIN"] = config["python_bin"]

    remote_host = body.get("remote_host", "").strip() or config.get("remote_host", "").strip()
    if remote_host:
        env["REMOTE_HOST"] = remote_host

    remote_user = body.get("remote_user", "").strip() or config.get("ssh_user", "").strip()
    ssh_opts = body.get("ssh_opts", "").strip() or config.get("ssh_opts", "").strip()
    if remote_user:
        env["REMOTE_USER"] = remote_user
    if ssh_opts:
        env["SSH_OPTS"] = ssh_opts

    try:
        completed = subprocess.run(
            command,
            cwd=str(script_dir),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            shell=False,
            timeout=DEFAULT_ACTION_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired as exc:
        timeout_output = exc.stdout or ""
        if isinstance(timeout_output, bytes):
            timeout_output = timeout_output.decode("utf-8", errors="replace")
        timeout_message = "Action timed out after {} seconds.\n{}".format(
            DEFAULT_ACTION_TIMEOUT_SECONDS,
            timeout_output,
        ).rstrip()
        return {
            "command": command_text,
            "returncode": 124,
            "output": timeout_message,
            "success": False,
        }
    except OSError as exc:
        return {
            "command": command_text,
            "returncode": 1,
            "output": "Failed to start command: {}".format(exc),
            "success": False,
        }
    return {
        "command": command_text,
        "returncode": completed.returncode,
        "output": completed.stdout,
        "success": completed.returncode == 0,
    }


class WebLogicRequestHandler(BaseHTTPRequestHandler):
    server_version = "WebLogicDeploymentUI/1.0"

    @property
    def app(self):
        return self.server

    def get_session_token(self):
        cookie_header = self.headers.get("Cookie", "")
        if not cookie_header:
            return ""
        for part in cookie_header.split(";"):
            key, _, value = part.strip().partition("=")
            if key == SESSION_COOKIE_NAME:
                return value
        return ""

    def current_session(self):
        return self.app.get_session(self.get_session_token())

    def require_auth(self, roles=None):
        session = self.current_session()
        if not session:
            self.send_json(
                {"error": "Login required.", "auth_required": True},
                status=HTTPStatus.UNAUTHORIZED,
            )
            return None
        if roles and session["role"] not in roles:
            self.send_json(
                {"error": "You do not have permission for this action."},
                status=HTTPStatus.FORBIDDEN,
            )
            return None
        return session

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/api/session":
            session = self.current_session()
            if not session:
                self.send_json(
                    {"authenticated": False},
                    status=HTTPStatus.UNAUTHORIZED,
                )
                return
            self.send_json(
                {
                    "authenticated": True,
                    "user": {
                        "username": session["username"],
                        "role": session["role"],
                    },
                }
            )
            return

        if path == "/api/users":
            if not self.require_auth({"admin"}):
                return
            self.send_json({"users": self.app.list_users()})
            return

        if path == "/api/scripts":
            if not self.require_auth():
                return
            self.send_json(self.app.script_summaries())
            return

        if path == "/api/config":
            session = self.require_auth()
            if not session:
                return
            self.send_json(
                {
                    "script_directory": str(self.app.script_dir),
                    "ui_directory": str(UI_DIR),
                    "domain_config_file": str(self.app.domain_config_path),
                    "auth_config_file": str(self.app.auth_config_path),
                    "user": {
                        "username": session["username"],
                        "role": session["role"],
                    },
                    "domains": domain_payload(self.app.catalog, self.app.domain_configs),
                }
            )
            return

        if path == "/api/domains":
            if not self.require_auth():
                return
            self.send_json({"domains": domain_payload(self.app.catalog, self.app.domain_configs)})
            return

        if path.startswith("/api/scripts/"):
            if not self.require_auth():
                return
            script_name = unquote(path.split("/api/scripts/", 1)[1])
            model = self.app.catalog.get(script_name)
            if not model:
                self.send_error(HTTPStatus.NOT_FOUND, "Script not found.")
                return
            payload = summarize_script(model)
            payload["entries"] = [entry.to_dict() for entry in model.entries]
            self.send_json(payload)
            return

        if path in {"/", "/index.html"}:
            self.serve_static("index.html")
            return

        if path.startswith("/ui/"):
            self.serve_static(path[len("/ui/"):])
            return

        self.send_error(HTTPStatus.NOT_FOUND, "Route not found.")

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/login":
            body = self.read_json_body()
            session = self.app.authenticate(
                body.get("username", ""),
                body.get("password", ""),
            )
            if not session:
                self.send_json(
                    {"error": "Invalid username or password."},
                    status=HTTPStatus.UNAUTHORIZED,
                )
                return
            self.send_json(
                {
                    "authenticated": True,
                    "user": {
                        "username": session["username"],
                        "role": session["role"],
                    },
                },
                headers={
                    "Set-Cookie": self.app.build_session_cookie(session["token"])
                },
            )
            return

        if parsed.path == "/api/logout":
            token = self.get_session_token()
            if token:
                self.app.invalidate_session(token)
            self.send_json(
                {"authenticated": False},
                headers={
                    "Set-Cookie": self.app.build_expired_session_cookie()
                },
            )
            return

        if parsed.path == "/api/users":
            if not self.require_auth({"admin"}):
                return
            body = self.read_json_body()
            try:
                self.app.create_user(
                    body.get("username", ""),
                    body.get("password", ""),
                    body.get("role", "monitor"),
                )
            except ValueError as exc:
                self.send_json({"error": str(exc)}, status=HTTPStatus.BAD_REQUEST)
                return
            self.send_json({"users": self.app.list_users()}, status=HTTPStatus.CREATED)
            return

        if parsed.path == "/api/generate/deploy":
            if not self.require_auth({"admin", "operator"}):
                return
            body = self.read_json_body()
            script_name = body.get("script_name", "")
            model = self.app.catalog.get(script_name)
            if not model:
                self.send_error(HTTPStatus.NOT_FOUND, "Script not found.")
                return

            summary = summarize_script(model)
            admin_url = body.get("admin_url") or (summary["admin_urls"][0] if summary["admin_urls"] else "")
            user = body.get("user") or (summary["users"][0] if summary["users"] else "")
            password = body.get("password") or summary["password"]
            files = generate_deploy_script(
                model=model,
                action=body.get("action", "deploy"),
                admin_url=admin_url,
                user=user,
                password=password,
                target_override=body.get("target_override", ""),
                artifact_root=body.get("artifact_root", ""),
                classpath=body.get("classpath") or (model.classpath or ""),
                log_dir=body.get("log_dir") or os.path.dirname(model.log_path or ""),
            )
            self.send_json({"files": files})
            return

        if parsed.path == "/api/generate/lifecycle":
            if not self.require_auth({"admin", "operator"}):
                return
            body = self.read_json_body()
            files = generate_lifecycle_scripts(
                domain_home=body.get("domain_home", ""),
                wl_home=body.get("wl_home", ""),
                admin_url=body.get("admin_url", ""),
                admin_server_name=body.get("admin_server_name", "AdminServer"),
                managed_servers=split_csv(body.get("managed_servers", "")),
                log_dir=body.get("log_dir", ""),
            )
            self.send_json({"files": files})
            return

        if parsed.path == "/api/refresh":
            if not self.require_auth():
                return
            self.app.refresh_catalog()
            self.send_json(
                {
                    "refreshed": True,
                    "scripts": self.app.script_summaries(),
                    "domains": domain_payload(self.app.catalog, self.app.domain_configs),
                }
            )
            return

        if parsed.path == "/api/domain-action":
            if not self.require_auth({"admin", "operator"}):
                return
            body = self.read_json_body()
            try:
                result = run_domain_action(
                    self.app.script_dir,
                    self.app.domain_configs,
                    body.get("domain", ""),
                    body.get("action", ""),
                    body,
                )
            except ValueError as exc:
                self.send_json({"success": False, "error": str(exc)}, status=HTTPStatus.BAD_REQUEST)
                return
            self.send_json(result, status=HTTPStatus.OK if result["success"] else HTTPStatus.BAD_REQUEST)
            return

        self.send_error(HTTPStatus.NOT_FOUND, "Route not found.")

    def read_json_body(self):
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw.decode("utf-8"))

    def serve_static(self, relative_path):
        ui_root = UI_DIR.resolve()
        target = (ui_root / relative_path).resolve()
        if target != ui_root and ui_root not in target.parents:
            self.send_error(HTTPStatus.FORBIDDEN, "Invalid path.")
            return
        if not target.exists() or not target.is_file():
            self.send_error(HTTPStatus.NOT_FOUND, "Static file not found.")
            return

        content_type, _ = mimetypes.guess_type(target.name)
        content = target.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type or "application/octet-stream")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def send_json(self, payload, status=HTTPStatus.OK, headers=None):
        data = json.dumps(payload, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        if headers:
            for key, value in headers.items():
                self.send_header(key, value)
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, format, *args):
        return


class ThreadingSimpleServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True


class WebLogicHttpServer(ThreadingSimpleServer):
    def __init__(self, server_address, script_dir):
        super().__init__(server_address, WebLogicRequestHandler)
        self.script_dir = script_dir
        self.domain_config_path = script_dir / DOMAIN_CONFIG_FILE
        self.auth_config_path = script_dir / AUTH_CONFIG_FILE
        self.domain_configs = load_domain_configs(script_dir)
        self.auth_config = load_auth_config(script_dir)
        self.sessions = {}
        self.catalog = load_catalog(script_dir)

    def refresh_catalog(self):
        self.domain_configs = load_domain_configs(self.script_dir)
        self.auth_config = load_auth_config(self.script_dir)
        self.catalog = load_catalog(self.script_dir)

    def script_summaries(self):
        return [summarize_script(model) for model in self.catalog.values()]

    def get_session(self, token):
        if not token:
            return None
        session = self.sessions.get(token)
        if not session:
            return None
        if session["expires_at"] <= time.time():
            self.sessions.pop(token, None)
            return None
        return session

    def create_session(self, username, role):
        token = secrets.token_urlsafe(32)
        session = {
            "token": token,
            "username": username,
            "role": role,
            "expires_at": time.time() + (3600 * int(self.auth_config.get("session_hours", DEFAULT_SESSION_HOURS))),
        }
        self.sessions[token] = session
        return session

    def invalidate_session(self, token):
        self.sessions.pop(token, None)

    def authenticate(self, username, password):
        username = str(username).strip()
        for user in self.auth_config.get("users", []):
            if user.get("username") != username:
                continue
            if verify_password(password, user.get("password")):
                return self.create_session(user["username"], user["role"])
        return None

    def build_session_cookie(self, token):
        max_age = 3600 * int(self.auth_config.get("session_hours", DEFAULT_SESSION_HOURS))
        return "{}={}; Path=/; HttpOnly; SameSite=Lax; Max-Age={}".format(
            SESSION_COOKIE_NAME,
            token,
            max_age,
        )

    def build_expired_session_cookie(self):
        return "{}=deleted; Path=/; HttpOnly; SameSite=Lax; Max-Age=0".format(
            SESSION_COOKIE_NAME
        )

    def list_users(self):
        return [
            {
                "username": user["username"],
                "role": user["role"],
            }
            for user in sorted(self.auth_config.get("users", []), key=lambda item: item["username"].lower())
        ]

    def create_user(self, username, password, role):
        username = str(username).strip()
        password = str(password)
        role = str(role).strip().lower() or "monitor"
        if not username:
            raise ValueError("Enter a username.")
        if len(password) < 6:
            raise ValueError("Password must be at least 6 characters.")
        if role not in {"admin", "operator", "monitor"}:
            raise ValueError("Role must be admin, operator, or monitor.")
        if any(user["username"].lower() == username.lower() for user in self.auth_config.get("users", [])):
            raise ValueError("Username already exists.")

        self.auth_config.setdefault("users", []).append(
            {
                "username": username,
                "role": role,
                "password": make_password_record(password),
            }
        )
        save_auth_config(self.auth_config_path, self.auth_config)


def split_csv(raw_value):
    return [item.strip() for item in raw_value.split(",") if item.strip()]


def main():
    parser = argparse.ArgumentParser(description="Local WebLogic deployment UI server")
    parser.add_argument("--host", default="IP_ADDRESS", help="Host to bind")
    parser.add_argument("--port", type=int, default=8787, help="Port to listen on")
    parser.add_argument(
        "--script-dir",
        default=str(DEFAULT_SCRIPT_DIR),
        help="Directory containing existing .sh deployment files",
    )
    args = parser.parse_args()

    script_dir = Path(args.script_dir)
    server = WebLogicHttpServer((args.host, args.port), script_dir)
    print(f"WebLogic deployment UI running on htt/PATH_TO_CONFIGURE")
    print(f"Using deployment scripts from: {script_dir}")
    server.serve_forever()


if __name__ == "__main__":
    main()
