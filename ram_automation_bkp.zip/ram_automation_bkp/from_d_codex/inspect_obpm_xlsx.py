# SANITIZED PUBLICATION TEMPLATE. Not runtime-tested.
import json
import re
import sys
import zipfile
import xml.etree.ElementTree as ET


NS = {
    "a": "htt/PATH_TO_CONFIGURE",
    "r": "htt/PATH_TO_CONFIGURE",
}


def col_to_idx(cell_ref):
    letters = re.match(r"([A-Z]+)", cell_ref).group(1)
    idx = 0
    for char in letters:
        idx = idx * 26 + (ord(char) - ord("A") + 1)
    return idx - 1


def read_shared_strings(zf):
    if "xl/sharedStrings.xml" not in zf.namelist():
        return []
    root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
    values = []
    for si in root.findall("a:si", NS):
        parts = []
        for t in si.findall(".//a:t", NS):
            parts.append(t.text or "")
        values.append("".join(parts))
    return values


def read_workbook_sheets(zf):
    workbook = ET.fromstring(zf.read("xl/workbook.xml"))
    rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
    rid_to_target = {}
    for rel in rels:
        rid_to_target[rel.attrib["Id"]] = rel.attrib["Target"]

    sheets = []
    for sheet in workbook.findall("a:sheets/a:sheet", NS):
        rid = sheet.attrib["{%s}id" % NS["r"]]
        target = rid_to_target[rid]
        if not target.startswith("xl/"):
            target = "xl/" + target
        sheets.append((sheet.attrib["name"], target))
    return sheets


def cell_value(cell, shared):
    typ = cell.attrib.get("t")
    value = cell.find("a:v", NS)
    if value is None:
        inline = cell.find("a:is", NS)
        if inline is None:
            return ""
        return "".join(t.text or "" for t in inline.findall(".//a:t", NS))
    raw = value.text or ""
    if typ == "s":
        return shared[int(raw)]
    if typ == "b":
        return raw == "1"
    return raw


def read_sheet(zf, path, shared):
    root = ET.fromstring(zf.read(path))
    rows = []
    for row in root.findall("a:sheetData/a:row", NS):
        values = []
        for cell in row.findall("a:c", NS):
            idx = col_to_idx(cell.attrib["r"])
            while len(values) <= idx:
                values.append("")
            values[idx] = cell_value(cell, shared)
        rows.append(values)
    return rows


def compact_rows(rows, limit=80):
    max_cols = max((len(r) for r in rows), default=0)
    normalized = [r + [""] * (max_cols - len(r)) for r in rows]
    non_empty = [r for r in normalized if any(str(v).strip() for v in r)]
    return non_empty[:limit]


def main():
    path = sys.argv[1]
    output = {}
    with zipfile.ZipFile(path) as zf:
        shared = read_shared_strings(zf)
        for name, target in read_workbook_sheets(zf):
            output[name] = compact_rows(read_sheet(zf, target, shared))
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
