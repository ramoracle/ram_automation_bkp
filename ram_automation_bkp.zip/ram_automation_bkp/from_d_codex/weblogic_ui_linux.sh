#!/usr/bin/env bash
# SANITIZED TEMPLATE: review placeholders and destructive operations before use.
echo "Disabled publication template: configure and review before execution." >&2
exit 99


set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOST="${WEBLOGIC_UI_HOST:-IP_ADDRESS}"
PORT="${WEBLOGIC_UI_PORT:-8787}"
DEPLOY_SCRIPT_DIR="${WEBLOGIC_SCRIPT_DIR:-${SCRIPT_DIR}}"
PYTHON_BIN="${PYTHON_BIN:-python3}"

exec "${PYTHON_BIN}" "${SCRIPT_DIR}/weblogic_ui_server.py" \
  --host "${HOST}" \
  --port "${PORT}" \
  --script-dir "${DEPLOY_SCRIPT_DIR}"
