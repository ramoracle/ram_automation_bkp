# SANITIZED PUBLICATION TEMPLATE. Not runtime-tested.
import argparse
import os
import re
import shutil
import sys
import time


def read_text(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as handle:
        return handle.read()


def write_text(path, text):
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)


def show_versions(path):
    text = read_text(path)
    versions = sorted(set(re.findall(r"-([0-9]+\.[0-9]+\.[0-9]+)(?:\.war)?", text)))
    if not versions:
        print("No versions found in {}".format(path))
        return
    print("Versions in {}:".format(path))
    for version in versions:
        print("  {}".format(version))


def bump_version(path, new_version):
    if not re.match(r"^[0-9]+\.[0-9]+\.[0-9]+$", new_version):
        raise ValueError("Version must look like 6.41.0")

    original = read_text(path)
    updated = re.sub(
        r"(-name\s+\S*?)-[0-9]+\.[0-9]+\.[0-9]+(\.war)?",
        lambda m: "{}-{}{}".format(m.group(1), new_version, m.group(2) or ""),
        original,
    )
    updated = re.sub(
        r"([A-Za-z0-9_.-]+)-[0-9]+\.[0-9]+\.[0-9]+\.war",
        lambda m: "{}-{}.war".format(m.group(1), new_version),
        updated,
    )

    backup = "{}.bak_{}".format(path, time.strftime("%Y%m%d_%H%M%S"))
    shutil.copy2(path, backup)
    write_text(path, updated)
    print("Updated {} to version {}".format(path, new_version))
    print("Backup created at {}".format(backup))


def main():
    parser = argparse.ArgumentParser(description="Update WAR versions inside a deploy shell script")
    parser.add_argument("script", help="Deploy shell script path")
    parser.add_argument("version", nargs="?", help="New version, example 6.41.0")
    parser.add_argument("--show", action="store_true", help="Only show versions")
    args = parser.parse_args()

    if not os.path.exists(args.script):
        print("Script not found: {}".format(args.script))
        sys.exit(1)

    if args.show or not args.version:
        show_versions(args.script)
        return

    bump_version(args.script, args.version)


if __name__ == "__main__":
    main()
