// SANITIZED TEMPLATE: configure placeholders and review before use.
import fs from "node:fs/promises";
import path from "node:path";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const inputPath = "/PATH_TO_CONFIGURE";
const outputPath = "/PATH_TO_CONFIGURE";

function decodeBuffer(buffer) {
  if (buffer.length >= 2 && buffer[0] === 0xff && buffer[1] === 0xfe) {
    return buffer.subarray(2).toString("utf16le");
  }
  if (buffer.length >= 3 && buffer[0] === 0xef && buffer[1] === 0xbb && buffer[2] === 0xbf) {
    return buffer.subarray(3).toString("utf8");
  }
  return buffer.toString("utf8").replace(/^\uFEFF/, "");
}

const text = decodeBuffer(await fs.readFile(inputPath));
const schemaNames = text
  .replace(/\r\n/g, "\n")
  .replace(/\r/g, "\n")
  .split("\n")
  .map((line) => line.trim())
  .filter(Boolean)
  .filter((line) => /_username\s*=/i.test(line))
  .map((line) => line.slice(line.indexOf("=") + 1).trim())
  .filter(Boolean);

const uniqueSchemaNames = [];
const seen = new Set();
for (const name of schemaNames) {
  const key = name.toUpperCase();
  if (!seen.has(key)) {
    seen.add(key);
    uniqueSchemaNames.push(name);
  }
}

const rows = [["product team schema name"], ...uniqueSchemaNames.map((name) => [name])];

const workbook = Workbook.create();
const sheet = workbook.worksheets.add("Product Team Schemas");
sheet.getRangeByIndexes(0, 0, rows.length, 1).values = rows;
sheet.getRange("A1").format = {
  fill: "#1F4E78",
  font: { name: "Arial", bold: true, color: "#FFFFFF", size: 11 },
};
sheet.getRangeByIndexes(0, 0, rows.length, 1).format.font = { name: "Arial", size: 10 };
sheet.getRangeByIndexes(0, 0, rows.length, 1).format.borders = {
  preset: "all",
  style: "thin",
  color: "#D9D9D9",
};
sheet.getRange("A:A").format.numberFormat = "@";
sheet.getRange("A:A").format.autofitColumns();
sheet.freezePanes.freezeRows(1);
sheet.tables.add(`A1:A${rows.length}`, true, "ProductTeamSchemas");

await fs.mkdir(path.dirname(outputPath), { recursive: true });
const output = await SpreadsheetFile.exportXlsx(workbook);
await output.save(outputPath);

console.log(JSON.stringify({
  outputPath,
  inputRows: schemaNames.length,
  uniqueProductSchemaNames: uniqueSchemaNames.length,
}, null, 2));
