// SANITIZED TEMPLATE: configure placeholders and review before use.
import fs from "node:fs/promises";
import path from "node:path";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const inputPath = "/PATH_TO_CONFIGURE";
const outputPath = "/PATH_TO_CONFIGURE";

function decodeBuffer(buffer) {
  if (buffer.length >= 2 && buffer[0] === 0xff && buffer[1] === 0xfe) {
    return buffer.subarray(2).toString("utf16le");
  }
  if (buffer.length >= 3 && buffer[0] === 0xef && buffer[1] === 0xbb && buffer[2] === 0xbf) {
    return buffer.subarray(3).toString("utf8");
  }
  return buffer.toString("utf8").replace(/^\uFEFF/, "");
}

const text = decodeBuffer(await fs.readFile(inputPath));
const schemaNames = text
  .replace(/\r\n/g, "\n")
  .replace(/\r/g, "\n")
  .split("\n")
  .map((line) => line.trim())
  .filter(Boolean)
  .filter((line) => /_username\s*=/i.test(line))
  .map((line) => line.slice(line.indexOf("=") + 1).trim())
  .filter(Boolean);

const workbook = Workbook.create();
const sheet = workbook.worksheets.add("Schema Mapping");

const tableRows = [
  ["Schema Name", "IQA Schema Name", "Password"],
  ...schemaNames.map((name) => [name, "", ""]),
];

sheet.getRangeByIndexes(0, 6, tableRows.length, 3).values = tableRows;
sheet.getRange(`G1:I${tableRows.length}`).format.font = { name: "Arial", size: 10 };
sheet.getRange("G1:I1").format = {
  fill: "#D9EAF7",
  font: { name: "Arial", bold: true, color: "#000000", size: 10 },
};
if (tableRows.length > 1) {
  sheet.getRange(`G2:I${tableRows.length}`).format.fill = "#D9D9D9";
}
sheet.getRange(`G1:I${tableRows.length}`).format.borders = {
  preset: "all",
  style: "thin",
  color: "#000000",
};
sheet.getRange("G:I").format.numberFormat = "@";
sheet.getRange("G:G").format.columnWidth = 28;
sheet.getRange("H:H").format.columnWidth = 28;
sheet.getRange("I:I").format.columnWidth = 18;
sheet.freezePanes.freezeRows(1);

const check = await workbook.inspect({
  kind: "table",
  range: "Schema Mapping!G1:I6",
  include: "values",
  tableMaxRows: 6,
  tableMaxCols: 3,
  tableMaxCellChars: 40,
  maxChars: 2000,
});

await fs.mkdir(path.dirname(outputPath), { recursive: true });
const output = await SpreadsheetFile.exportXlsx(workbook);
await output.save(outputPath);

console.log(JSON.stringify({
  outputPath,
  schemaNameEntries: schemaNames.length,
  preview: check.ndjson,
}, null, 2));
